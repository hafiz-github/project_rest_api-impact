var dateLowerlimit = "";
var tokenArray = ["start", "init"];
var tokenIndex = 1;

function getDateLowerLimit() {
    var todayDate;
    if (dateLowerlimit == "") {
        todayDate = new Date();
        dateLowerlimit = todayDate.getFullYear() + "-" + (todayDate.getMonth() < 10 ? '0' : '') + (todayDate.getMonth() + 1) + "-" + (todayDate.getDate() < 10 ? '0' : '') + todayDate.getDate() + "T00:00:00+00:00"
    } else {
        todayDate = new Date(dateLowerlimit)
    }
}

function getFormattedDate(dateTime, withZone) {
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var dd = new Date(dateTime);
    timeZone = (dateTime.indexOf("+") != -1) ? "[GMT" + dateTime.substring(dateTime.indexOf("+")) + "]" : "";
    if (withZone) return "<span class='gcal-datetime'>" + dd.getDate() + " " + monthNames[dd.getMonth()] + " " + dd.getHours() + ":" + (dd.getMinutes() < 10 ? '0' : '') + dd.getMinutes() + "</span><br/><span class='gcal-tzone'>" + timeZone + "</span>";
    return dd.getDate() + " " + monthNames[dd.getMonth()] + " " + dd.getHours() + ":" + (dd.getMinutes() < 10 ? '0' : '') + dd.getMinutes()
}
if (null == colorBox || colorBox == "" || colorBox == "undefined") var colorBox = ['rgb(242,227,242)', 'rgb(217,231,255)', 'rgb(240,240,240)', 'rgb(232,246,189)', 'rgb(206,235,202)'];
$(window).load(function() {
    var style = '<style>::-webkit-scrollbar {width: 10px;}::-webkit-scrollbar-button {display:none;}::-webkit-scrollbar-track-piece {background: #888}::-webkit-scrollbar-thumb {background: #eee}</style>';
    $('html > head').append(style);
    style = '<style>#gcal-table{margin:0px auto;}.event-header {width:150px;height: 54px;background-color:rgb(48,128,221);color:white;padding:3px;}.gcal-tzone{color:rgb(202,211,236);font-size:12px;}.gcal-datetime {font-weight:bold}.event-body {width:150px;height: 90px;padding:3px;color:black;overflow:hidden;text-decoration:none;}	  .event-desc {font-size:11px;text-decoration:none;}#gcal {font-family: Calibri;font-size: 15px;	  text-align:left;display: inline-block;position:relative;overflow:hidden;min-height:140px;min-width:150px;}a:link,a:visited,a:hover,a:active {text-decoration:none;}.gcal-rpointer {position: absolute;right: -15px;top: 90px;font-size: 30px;font-weight: bold;color: rgb(213,63,53);width: 35px;height: 35px;padding-bottom: 7px;padding-left: 5px;cursor:pointer;cursor:mouse;border-radius: 35px;}.gcal-lpointer {position: absolute;left: -15px;top: 90px;font-size: 30px;font-weight: bold;color: rgb(213,63,53);width: 35px;height: 35px;padding-bottom: 7px;padding-left: 5px;cursor:pointer;cursor:mouse;border-radius: 35px;}</style>';
    $('html > head').append(style);
    $('#gcal').empty().append('<table id="gcal-table"></table>');
    $('#gcal').append('<div class="gcal-rpointer">></div>');
    $('.gcal-rpointer').mouseenter(function() {
        $(this).css('background-color', 'rgb(255,207,19)')
    });
    $('.gcal-rpointer').mouseleave(function() {
        $(this).css('background-color', 'transparent')
    });
    $('.gcal-rpointer').click(function() {
        (tokenIndex >= (tokenArray.length - 1)) ? (tokenIndex = (tokenArray.length - 1)) : tokenIndex++;
        loadTumbo()
    });
    $('#gcal').append('<div class="gcal-lpointer">&nbsp;&nbsp;<</div>');
    $('.gcal-lpointer').mouseenter(function() {
        $(this).css('background-color', 'rgb(255,207,19)')
    });
    $('.gcal-lpointer').mouseleave(function() {
        $(this).css('background-color', 'transparent')
    });
    $('.gcal-lpointer').click(function() {
        (tokenIndex <= 0) ? tokenIndex = 0: tokenIndex--;
        loadTumbo()
    });
    loadTumbo()
});

function loadTumbo() {
    var apiPostURL = "https://www.googleapis.com/calendar/v3/calendars/" + googleCalendarId + "/events";
    $('#gcal-table').empty().append('<tr id="gcal-row"><td>loading ...</td></tr>');
    getDateLowerLimit();
    var dataBox = {
        orderBy: "startTime",
        singleEvents: "true",
        timeMin: dateLowerlimit,
        fields: "items,nextPageToken",
        key: googleCalendarApiKey,
        maxResults: maxGcalEvents
    };
    pageToken = tokenArray[tokenIndex];
    if (null == pageToken || pageToken == "undefined" || pageToken == "") {
        $('#gcal-table').empty().append('<tr id="gcal-row"><td><div class="event-header">Error .. Reload page!</div></td></tr>');
        return
    }
    if (pageToken == "init") {
        callAPI(apiPostURL, dataBox)
    } else if (pageToken == "start") {
        $('#gcal-table').empty().append('<tr id="gcal-row"><td><div class="event-header">Previous events are completed!</div></td></tr>')
    } else if (pageToken == "end") {
        $('#gcal-table').empty().append('<tr id="gcal-row"><td><div class="event-header">No more events found!</div></td></tr>')
    } else {
        dataBox['pageToken'] = pageToken;
        callAPI(apiPostURL, dataBox)
    }
}

function callAPI(apiPostURL, dataBox) {
    $.ajax({
        url: apiPostURL,
        type: "GET",
        data: dataBox,
        async: true,
        cache: true,
        dataType: "jsonp",
        success: function(data) {
            showTumbo(data)
        },
        error: function(html) {
            alert(html)
        },
        beforeSend: setHeader
    })
}

function showTumbo(data) {
    $('#gcal-table').empty().append('<tr id="gcal-row"></tr>');
    var eventArray = data.items;
    if (tokenIndex == (tokenArray.length - 1)) {
        tokenArray.push((null == data.nextPageToken) ? "end" : data.nextPageToken)
    }
    eventHTML = "";
    var c = 0;
    for (var i = 0; i < eventArray.length; i++) {
        startDate = eventArray[i].start.date || eventArray[i].start.dateTime;
        endDate = eventArray[i].end.date || eventArray[i].end.dateTime;
        summary = eventArray[i].summary;
        description = eventArray[i].description;
        htmlLink = eventArray[i].htmlLink;
        event_location = eventArray[i].location;
        eventHTML += '<td><a href="' + htmlLink + '"><div class="event-header">';
        if (null != startDate && startDate != "undefined" && startDate != "") {
            eventHTML += getFormattedDate(startDate, true)
        }
        if (null != event_location && event_location != "undefined" && event_location != "") {
            eventHTML += "<br/>@ " + event_location
        }
        eventHTML += "</div>";
        if (null != summary && summary != "undefined" && summary != "") {
            eventHTML += "<div class='event-body' style='background-color:" + colorBox[c] + "'>" + summary
        }
        if (null != description && description != "undefined" && description != "") {
            eventHTML += "<span class='event-desc'>  &nbsp;&nbsp;[" + description + "] </span>"
        }
        eventHTML += "</div></a>";
        c = (++c > (colorBox.length - 1)) ? 0 : c++;
        eventHTML += '</td>'
    }
    $('#gcal-row').append(eventHTML)
}

function setHeader(xhr) {
    if (xhr && xhr.overrideMimeType) {
        xhr.overrideMimeType("application/j-son;charset=UTF-8")
    }
}