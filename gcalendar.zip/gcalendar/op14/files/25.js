/*!
 * FullCalendar v3.6.2 Google Calendar Plugin
 * Docs & License: https://fullcalendar.io/
 * (c) 2017 Adam Shaw
 */
!function (e) {
    "function" == typeof define && define.amd ? define(["jquery"], e) : "object" == typeof exports ? module.exports = e(require("jquery")) : e(jQuery)
}(function (e) {
    function a(e) {
        var a;
        return /^[^\/]+@([^\/\.]+\.)*(google|googlemail|gmail)\.com$/.test(e) ? e : (a = /^https:\/\/www.googleapis.com\/calendar\/v3\/calendars\/([^\/]*)/.exec(e)) || (a = /^https?:\/\/www.google.com\/calendar\/feeds\/([^\/]*)/.exec(e)) ? decodeURIComponent(a[1]) : void 0
    }

    function r(e, a) {
        return e.replace(/(\?.*?)?(#|$)/, function (e, r, t) {
            return (r ? r + "&" : "?") + a + t
        })
    }

    var t = e.fullCalendar, n = t.Promise, o = t.EventSource, l = t.JsonFeedEventSource, i = t.EventSourceParser,
        s = t.applyAll, c = o.extend({
            googleCalendarApiKey: null,
            googleCalendarId: null,
            googleCalendarError: null,
            ajaxSettings: null,
            constructor: function () {
                o.apply(this, arguments), this.ajaxSettings = {}
            },
            fetch: function (a, r, t) {
                var o = this, i = this.buildUrl(), c = this.buildRequestParams(a, r, t), d = this.ajaxSettings,
                    u = d.success;
                return c ? (this.calendar.pushLoading(), n.construct(function (a, r) {
                    e.ajax(e.extend({}, l.AJAX_DEFAULTS, d, {
                        url: i, data: c, success: function (t) {
                            var n, l;
                            o.calendar.popLoading(), t.error ? (o.reportError("Google Calendar API: " + t.error.message, t.error.errors), r()) : t.items && (n = o.gcalItemsToRawEventDefs(t.items, c.timeZone), l = s(u, this, [n].concat(Array.prototype.slice.call(arguments, 1))), e.isArray(l) && (n = l), a(o.parseEventDefs(n)))
                        }
                    }))
                })) : n.reject()
            },
            gcalItemsToRawEventDefs: function (e, a) {
                var r = this;
                return e.map(function (e) {
                    return r.gcalItemToRawEventDef(e, a)
                })
            },
            gcalItemToRawEventDef: function (e, a) {
                var t = e.htmlLink || null;
                return t && a && (t = r(t, "ctz=" + a)), {
                    id: e.id,
                    title: e.summary,
                    start: e.start.dateTime || e.start.date,
                    end: e.end.dateTime || e.end.date,
                    url: t,
                    location: e.location,
                    description: e.description
                }
            },
            buildUrl: function () {
                return c.API_BASE + "/" + encodeURIComponent(this.googleCalendarId) + "/events?callback=?"
            },
            buildRequestParams: function (a, r, t) {
                var n, o = this.googleCalendarApiKey || this.calendar.opt("googleCalendarApiKey");
                return o ? (a.hasZone() || (a = a.clone().utc().add(-1, "day")), r.hasZone() || (r = r.clone().utc().add(1, "day")), n = e.extend(this.ajaxSettings.data || {}, {
                    key: o,
                    timeMin: a.format(),
                    timeMax: r.format(),
                    singleEvents: !0,
                    maxResults: 9999
                }), t && "local" !== t && (n.timeZone = t.replace(" ", "_")), n) : (this.reportError("Specify a googleCalendarApiKey. See http://fullcalendar.io/docs/google_calendar/"), null)
            },
            reportError: function (e, a) {
                var r = this.calendar, n = r.opt("googleCalendarError"), o = a || [{message: e}];
                this.googleCalendarError && this.googleCalendarError.apply(r, o), n && n.apply(r, o), t.warn.apply(null, [e].concat(a || []))
            },
            getPrimitive: function () {
                return this.googleCalendarId
            },
            applyManualStandardProps: function (e) {
                var r = o.prototype.applyManualStandardProps.apply(this, arguments), t = e.googleCalendarId;
                return null == t && e.url && (t = a(e.url)), null != t && (this.googleCalendarId = t, r)
            },
            applyMiscProps: function (a) {
                e.extend(this.ajaxSettings, a)
            }
        });
    c.API_BASE = "https://www.googleapis.com/calendar/v3/calendars", c.defineStandardProps({
        url: !1,
        googleCalendarId: !1,
        googleCalendarApiKey: !0,
        googleCalendarError: !0
    }), c.parse = function (e, a) {
        var r;
        return "object" == typeof e ? r = e : "string" == typeof e && (r = {url: e}), !!r && o.parse.call(this, r, a)
    }, i.registerClass(c), t.GcalEventSource = c
});