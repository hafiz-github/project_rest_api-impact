var SWIFT = SWIFT || {};
(function () {
    SWIFT.page = {
        init: function () {
            SWIFT.page.browserCheck();
            if (D.hasClass("header-below-slider") && jQuery(".home-slider-wrap").length > 0) {
                SWIFT.page.headerSlider()
            }
            if (jQuery("#one-page-nav").length > 0) {
                SWIFT.page.onePageNav()
            }
            if (jQuery("#back-to-top").length > 0) {
                ag.scroll(function () {
                    SWIFT.page.backToTop()
                })
            }
            if (D.hasClass("hero-content-split")) {
                SWIFT.page.heroContentSplit()
            }
            if (jQuery("#sf-newsletter-bar").length > 0) {
                SWIFT.page.newsletterSubBar()
            }
            if (jQuery("#wpadminbar").length > 0) {
                D.addClass("has-wpadminbar")
            }
            if (jQuery(".recent-posts").length > 0) {
                SWIFT.recentPosts.init()
            }
            SWIFT.page.moveModals();
            jQuery('a[data-toggle="modal"]').on("click", function () {
                setTimeout(function () {
                    SWIFT.map.init()
                }, 300);
                return true
            });
            SWIFT.page.modalClose();
            if (D.hasClass("single-post")) {
                var an = jQuery("#respond").find("h3");
                var ao = jQuery("#respond").find("h3").html();
                an.addClass("spb-heading");
                an.html("<span>" + ao + "</span>")
            }
            SWIFT.page.smoothScrollLinks();
            SWIFT.page.expandingAssets();
            if (!I && jQuery("article.type-portfolio").hasClass("single-portfolio-split")) {
            }
            jQuery(".activity-time-since,.bp-secondary-action").on("click", function (ap) {
                ap.preventDefault();
                jQuery(".viewer").css("display", "none");
                window.location = jQuery(this).attr("href")
            });
            jQuery(".love-it").on("click", function () {
                SWIFT.page.loveIt(jQuery(this));
                return false
            });
            if (D.hasClass("article-swipe") && D.hasClass("single-post") && jQuery(".post-pagination-wrap").length > 0) {
                SWIFT.page.articleNavigation()
            }
            if (jQuery("article").hasClass("single-post-fw-media-title")) {
                SWIFT.page.postMediaTitle()
            }
            if (jQuery(".related-items").length > 0) {
                SWIFT.relatedPosts.init()
            }
            SWIFT.page.lightbox();
            if (I && D.hasClass("mobile-two-click")) {
                SWIFT.page.mobileThumbLinkClick()
            }
            if (D.hasClass("page-transitions")) {
                SWIFT.page.pageTransitions()
            }
            SWIFT.page.directorySubmit()
        }, homePreloader: function () {
            D.addClass("sf-preloader-done");
            setTimeout(function () {
                jQuery("#sf-home-preloader").fadeOut(300)
            }, 300)
        }, load: function () {
            if (ag.width() > 767) {
                SWIFT.page.fwRowContent()
            }
            ag.smartresize(function () {
                if (ag.width() > 767) {
                    SWIFT.page.fwRowContent()
                }
            });
            if (jQuery(".fancy-heading").length > 0) {
                SWIFT.page.fancyHeading()
            }
            if (jQuery(".recent-posts").length > 0) {
                SWIFT.recentPosts.load()
            }
            if (jQuery("#prev-article-pagination") || jQuery("#next-article-pagination")) {
                if ((D.hasClass("single-portfolio") && jQuery("article.portfolio").hasClass("single-portfolio-fw-media")) || (D.hasClass("single-post") && (jQuery("article.type-post").hasClass("single-post-fw-media-title") || jQuery("article.type-post").hasClass("single-post-fw-media")))) {
                    setTimeout(function () {
                        SWIFT.page.fwMediaNextPrevAdjust()
                    }, 500);
                    ag.smartresize(function () {
                        SWIFT.page.fwMediaNextPrevAdjust()
                    })
                }
                SWIFT.page.fsNextPrev();
                ag.scroll(function () {
                    SWIFT.page.fsNextPrev()
                })
            }
            setTimeout(function () {
                var an = document.location.toString();
                if (an.match("#")) {
                    var ao = an.split("#")[1];
                    if (jQuery("#" + ao).length > 0) {
                        SWIFT.page.onePageNavGoTo("#" + ao)
                    }
                }
            }, 1000)
        }, browserCheck: function () {
            jQuery.browser = {};
            jQuery.browser.mozilla = /mozilla/.test(navigator.userAgent.toLowerCase()) && !/webkit/.test(navigator.userAgent.toLowerCase());
            jQuery.browser.webkit = /webkit/.test(navigator.userAgent.toLowerCase());
            jQuery.browser.opera = /opera/.test(navigator.userAgent.toLowerCase());
            jQuery.browser.msie = /msie/.test(navigator.userAgent.toLowerCase());
            jQuery.browser.msieMobile10 = /iemobile\/10\.0/.test(navigator.userAgent.toLowerCase());
            if (I) {
                D.addClass("mobile-browser")
            } else {
                D.addClass("standard-browser")
            }
            if (aa) {
                D.addClass("ie-mobile")
            }
            if (am) {
                D.addClass("apple-mobile-browser")
            }
            if (D.hasClass("woocommerce-page") && !D.hasClass("woocommerce")) {
                D.addClass("woocommerce")
            }
            if (u && u < 9) {
                D.addClass("browser-ie")
            }
            var ap = /MSIE\s([\d]+)/, ao = navigator.userAgent, an = ao.match(ap);
            if (an) {
                D.addClass("browser-ie10")
            }
            if (jQuery.browser.mozilla) {
                D.addClass("browser-ff")
            }
            if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
                D.addClass("browser-safari")
            }
        }, resizeHeadings: function () {
            var ao = jQuery("h1:not(.logo-h1)").css("font-size"), an = jQuery("h2:not(.caption-title)").css("font-size");
            SWIFT.page.resizeHeadingsResize(ao, an);
            ag.smartresize(function () {
                SWIFT.page.resizeHeadingsResize(ao, an)
            })
        }, resizeHeadingsResize: function (ao, an) {
            if (ag.width() <= 768) {
                if (ao) {
                    ao = ao.replace("px", "");
                    var ap = Math.floor(ao * 0.6);
                    jQuery("h1:not(.logo-h1)").fitText(1, {
                        minFontSize: ap + "px",
                        maxFontSize: ao + "px"
                    }).css("line-height", "120%")
                }
                if (an) {
                    an = an.replace("px", "");
                    var aq = Math.floor(an * 0.6);
                    jQuery("h2:not(.caption-title)").fitText(1, {
                        minFontSize: aq + "px",
                        maxFontSize: an + "px"
                    }).css("line-height", "120%")
                }
            } else {
                jQuery("h1:not(.logo-h1)").css("font-size", "").css("line-height", "");
                jQuery("h2:not(.caption-title)").css("font-size", "").css("line-height", "")
            }
        }, loveIt: function (at) {
            var an = jQuery("#loveit-locale"), ap = at.data("post-id"), ao = at.data("user-id"), ar = "love_it";
            if (at.hasClass("loved")) {
                ar = "unlove_it"
            }
            if (an.data("loggedin") == "false" && jQuery.cookie("loved-" + ap)) {
                ar = "unlove_it"
            }
            var aq = {action: ar, item_id: ap, user_id: ao, love_it_nonce: an.data("nonce")};
            jQuery.post(an.data("ajaxurl"), aq, function (au) {
                var aw = jQuery.trim(au), ax, av;
                if (aw == "loved") {
                    at.addClass("loved");
                    ax = at.find("data.count");
                    av = ax.text();
                    ax.text(parseInt(av) + 1);
                    if (an.data("loggedin") == "false") {
                        jQuery.cookie("loved-" + ap, "yes", {expires: 1})
                    }
                } else {
                    if (aw == "unloved") {
                        at.removeClass("loved");
                        ax = at.find("data.count");
                        av = ax.text();
                        ax.text(parseInt(av) - 1);
                        if (an.data("loggedin") == "false") {
                            jQuery.cookie("loved-" + ap, "no", {expires: 1})
                        }
                    } else {
                        alert(an.data("error"))
                    }
                }
            })
        }, stickyWidget: function () {
            var ao = jQuery(".sticky-widget"), an = ao.parent(), ap = 24;
            if (jQuery(".sticky-header").length > 0) {
                ap = ap + jQuery(".sticky-header").height() > 0 ? jQuery(".sticky-header").height() : jQuery("#header-section").height()
            }
            if (jQuery("#wpadminbar").length > 0) {
                ap = ap + 32
            }
            if (jQuery(".sticky-top-bar").length > 0) {
                ap = ap + jQuery(".sticky-top-bar").height() > 0 ? jQuery(".sticky-top-bar").height() : jQuery("#top-bar").height()
            }
            SWIFT.page.initStickyWidget(ao, an, ap);
            ag.smartresize(function () {
                jQuery(".inner-page-wrap").stickem().destroy();
                SWIFT.page.resizeStickyWidget(ao, an);
                SWIFT.page.initStickyWidget(ao, an, ap)
            })
        }, initStickyWidget: function (ap, ao, aq) {
            var an = ".page-content";
            if (D.hasClass("page") || D.hasClass("archive") || D.hasClass("home") || D.hasClass("search-results")) {
                an = ".inner-page-wrap"
            }
            jQuery(".inner-page-wrap").stickem({
                item: ".sticky-widget",
                container: an,
                offset: aq + 24,
                onStick: function () {
                    SWIFT.page.resizeStickyWidget(ap, ao)
                }
            })
        }, resizeStickyWidget: function (at, ar) {
            var an = 0, aq = jQuery(".content-wrap"), ao = ar.find(".sidebar-widget-wrap").height();
            if (D.hasClass("page")) {
                aq = jQuery(".page-content")
            }
            if (jQuery(".sticky-header").length > 0) {
                an = jQuery(".sticky-header").height() > 0 ? jQuery(".sticky-header").height() : jQuery("#header-section").height()
            }
            if (jQuery("#wpadminbar").length > 0) {
                an = an + 32
            }
            if (jQuery(".sticky-top-bar").length > 0) {
                an = an + jQuery(".sticky-top-bar").height() > 0 ? jQuery(".sticky-top-bar").height() : jQuery("#top-bar").height()
            }
            at.css("width", ar.width()).css("top", an + 30);
            var ap = aq.height();
            if (ap > ao) {
                ar.css("height", ap)
            } else {
                ar.css("height", ao)
            }
        }, expandingAssets: function () {
            jQuery(".spb-row-expand-text").on("click", "", function (ap) {
                ap.preventDefault();
                var ao = jQuery(this), an = ao.next();
                if (an.hasClass("spb-row-expanding-open") && !an.hasClass("spb-row-expanding-active")) {
                    an.addClass("spb-row-expanding-open").addClass("spb-row-expanding-active").slideUp(800);
                    setTimeout(function () {
                        ao.removeClass("row-open").find("span").text(ao.data("closed-text"));
                        an.css("display", "block").removeClass("spb-row-expanding-open").removeClass("spb-row-expanding-active")
                    }, 800)
                } else {
                    if (!an.hasClass("spb-row-expanding-active")) {
                        ao.addClass("row-open").find("span").text(ao.data("open-text"));
                        an.css("display", "none").addClass("spb-row-expanding-open").addClass("spb-row-expanding-active").slideDown(800);
                        setTimeout(function () {
                            an.removeClass("spb-row-expanding-active")
                        }, 800)
                    }
                }
            })
        }, fwRowContent: function () {
            jQuery('.spb-row-container[data-v-center="true"]').each(function () {
                if (jQuery(this).find(".row").length > 0) {
                    jQuery(this).find(".row").each(function () {
                        var an = 0, ao = jQuery(this).parents(".spb-row-container");
                        if (ao.hasClass("parallax-window-height")) {
                            ao.find("> .spb_content_element").vCenterTop()
                        }
                        if (jQuery(this).find("> div").length > 1) {
                            jQuery(this).addClass("multi-column-row");
                            jQuery(this).find("> div").each(function () {
                                var aq = parseInt(jQuery(this).css("padding-top")) + parseInt(jQuery(this).css("padding-bottom")), ap = jQuery(this).find(".spb-asset-content").first().innerHeight() + aq;
                                if (ap > an) {
                                    an = ap
                                }
                            });
                            jQuery(this).css("min-height", an);
                            jQuery(this).find("> div").css("min-height", an);
                            jQuery(this).find("> div").each(function () {
                                var ar = jQuery(this).find(".spb-asset-content").first(), at = parseInt(jQuery(this).css("padding-top")) + parseInt(jQuery(this).css("padding-bottom")) + parseInt(ar.css("padding-top")) + parseInt(ar.css("padding-bottom")), aq = ar.height() + at, ap = Math.floor((an / 2) - (aq / 2));
                                if (ap > 0) {
                                    ar.css("margin-top", ap).css("margin-bottom", ap)
                                } else {
                                    ar.css("margin-top", "").css("margin-bottom", "")
                                }
                            })
                        }
                    })
                }
            })
        }, headerSlider: function () {
            jQuery("#site-loading").css("display", "block");
            jQuery(".home-slider-wrap").css("position", "fixed");
            jQuery("#main-container").css("position", "relative");
            jQuery("#container").css("top", jQuery(".home-slider-wrap").height());
            setTimeout(function () {
                jQuery("#site-loading").fadeOut(1000)
            }, 250);
            ag.smartresize(function () {
                jQuery("#container").css("top", jQuery(".home-slider-wrap").height())
            });
            jQuery("a#slider-continue").on("click", function (an) {
                an.preventDefault();
                jQuery("html, body").stop().animate({scrollTop: jQuery("#container").css("top")}, 1500, "easeInOutExpo")
            })
        }, fancyHeading: function () {
            var au = jQuery(".fancy-heading"), ar = au.find(".heading-text"), aq = ar.height(), ap = jQuery(".content-divider-wrap"), an = parseInt(au.data("height"), 10), av = jQuery(".header-wrap"), ao = 0;
            if (D.hasClass("header-naked-light") || D.hasClass("header-naked-dark")) {
                ao = av.height()
            }
            if (!an) {
                an = 400
            }
            if (aq > an) {
                an = aq + 80
            }
            an = an + ao;
            M = an;
            ar.vCenterTop();
            if (au.hasClass("page-heading-breadcrumbs")) {
                au.find("#breadcrumbs").vCenter()
            }
            var at = 400;
            if (!au.hasClass("fixed-height")) {
                au.transition({height: an}, 600, "easeOutCirc")
            }
            setTimeout(function () {
                ar.css("opacity", 1)
            }, at + 600);
            setTimeout(function () {
                au.addClass("animated")
            }, at + 1000);
            if (au.find("canvas").length > 0 && !I) {
                if (D.hasClass("hero-content-split")) {
                    an = jQuery("#main-container").height()
                }
                SWIFT.canvasEffects.init(an)
            }
            if (f && !I && au.find("canvas").length <= 0 && !D.hasClass("hero-content-split")) {
                ag.scroll(function () {
                    var az = ag.scrollTop(), ay = az, aw = 0, ax = 420;
                    if (au.parent().hasClass("fancy-tabbed-style")) {
                        ax = 180
                    }
                    if (jQuery(".sticky-header").length > 0) {
                        aw = jQuery(".sticky-header").height()
                    }
                    if (jQuery("#top-bar").length > 0) {
                        aw = aw + jQuery("#top-bar").height()
                    }
                    if (jQuery("#wpadminbar").length > 0) {
                        aw = aw + 32
                    }
                    if (jQuery("#sf-header-banner").length > 0) {
                        aw = aw + jQuery("#sf-header-banner").outerHeight()
                    }
                    az = az - aw;
                    if (az < jQuery(document).height() - ag.height()) {
                        if (az < 0) {
                            az = 0
                        }
                        au.stop(true, true).transition({y: az * 0.4}, 0);
                        if (au.parent().hasClass("fancy-tabbed-style")) {
                            ar.stop(true, true).transition({opacity: 1 - az / ax}, 0);
                            ap.stop(true, true).transition({opacity: 1 - az / ax}, 0)
                        } else {
                            ar.stop(true, true).transition({y: ay * 0.4, opacity: 1 - ay / ax}, 0)
                        }
                    }
                })
            }
        }, moveModals: function () {
            jQuery(".modal").each(function () {
                jQuery(this).appendTo("body")
            })
        }, modalClose: function () {
            jQuery(".modal-backdrop, .modal .close, .modal .btn").on("click", function () {
                jQuery(".modal iframe").each(function () {
                    var an = jQuery(this);
                    an.attr("src", an.attr("src"))
                })
            })
        }, smoothScrollLinks: function () {
            jQuery("a.smooth-scroll-link").on("click", function (ap) {
                var ao = jQuery(this).attr("href"), aq = jQuery(this).data("offset") ? jQuery(this).data("offset") : 0;
                if (ao && ao.indexOf("#") === 0) {
                    var an = 0;
                    if (jQuery(".sticky-header").length > 0) {
                        an = jQuery(".sticky-header").height() > 0 ? jQuery(".sticky-header").height() : jQuery("#header-section").height()
                    }
                    if (jQuery("#wpadminbar").length > 0) {
                        an = an + 32
                    }
                    if (jQuery(".sticky-top-bar").length > 0) {
                        an = an + jQuery(".sticky-top-bar").height() > 0 ? jQuery(".sticky-top-bar").height() : jQuery("#top-bar").height()
                    }
                    SWIFT.isScrolling = true;
                    jQuery("html, body").stop().animate({scrollTop: jQuery(ao).offset().top - an + aq}, 1000, "easeInOutExpo", function () {
                        SWIFT.isScrolling = false
                    });
                    ap.preventDefault()
                } else {
                    return ap
                }
            })
        }, onePageNav: function () {
            var ar = jQuery("#one-page-nav"), ap = ar.hasClass("opn-arrows") ? "arrows" : "standard", aq = "", ao = 0, an = jQuery(".page-content");
            an.find("section.row").each(function () {
                var at = jQuery(this).attr("id"), au = jQuery(this).data("rowname");
                if (at && au.length > 0 && jQuery(this).height() > 0) {
                    aq += '<li><a href="#' + at + '" data-title="' + au + '"><i></i></a><div class="hover-caption">' + au + "</div></li>";
                    ao++
                }
            });
            if (ao > 0) {
                if (ar.find("ul").length === 0) {
                    ar.append("<ul>" + aq + "</ul>");
                    if (ap === "arrows") {
                        ar.find("ul").css("display", "none");
                        ar.append('<a href="#" class="opn-up"><i class="sf-icon-chevron-up"></i></a>');
                        ar.append('<div class="opn-status"><span class="current">1</span>/<span class="total">' + ao + "</span></div>");
                        ar.append('<a href="#" class="opn-down"><i class="sf-icon-chevron-down"></i></a>')
                    }
                }
                ar.vCenter();
                setTimeout(function () {
                    SWIFT.page.onePageNavScroll(ar);
                    ar.css("display", "block").stop().animate({right: "0", opacity: 1}, 1000, "easeOutQuart");
                    jQuery("#one-page-nav ul li a").bind("click", function (at) {
                        SWIFT.page.onePageNavGoTo(jQuery(this).attr("href"));
                        at.preventDefault()
                    });
                    jQuery("#one-page-nav a.opn-up").bind("click", function (av) {
                        var aw = parseInt(jQuery(".opn-status .current").text(), 10), au = aw - 1, at = jQuery("#one-page-nav ul li:nth-child(" + au + ") > a").attr("href");
                        if (au > 0) {
                            SWIFT.page.onePageNavGoTo(at)
                        }
                        av.preventDefault()
                    });
                    jQuery("#one-page-nav a.opn-down").bind("click", function (au) {
                        var av = parseInt(jQuery(".opn-status .current").text(), 10), aw = av + 1, at = jQuery("#one-page-nav ul li:nth-child(" + aw + ") > a").attr("href");
                        if (aw <= ao) {
                            SWIFT.page.onePageNavGoTo(at)
                        }
                        au.preventDefault()
                    });
                    SWIFT.page.onePageNavScroll(ar);
                    ag.on("scroll", function () {
                        SWIFT.page.onePageNavScroll(ar)
                    })
                }, 1000)
            }
        }, onePageNavGoTo: function (ao) {
            var an = 0;
            if (jQuery("#wpadminbar").length > 0) {
                an = jQuery("#wpadminbar").height()
            }
            if (D.hasClass("sticky-header-enabled")) {
                an += jQuery(".sticky-header").height() > 0 ? jQuery(".sticky-header").height() : jQuery("#header-section").height()
            }
            if (jQuery(".sticky-top-bar").length > 0) {
                an += jQuery(".sticky-top-bar").height() > 0 ? jQuery(".sticky-top-bar").height() : jQuery("#top-bar").height()
            }
            SWIFT.isScrolling = true;
            jQuery("html, body").stop().animate({scrollTop: jQuery(ao).offset().top - an + 1}, 1000, "easeInOutExpo", function () {
                SWIFT.isScrolling = false
            })
        }, onePageNavScroll: function (at) {
            var ao = 0;
            if (D.hasClass("sticky-header-enabled")) {
                ao = jQuery(".sticky-header").height() > 0 ? ao + jQuery(".sticky-header").height() : ao + jQuery("#header-section").height()
            }
            if (jQuery("#wpadminbar").length > 0) {
                ao = ao + jQuery("#wpadminbar").height()
            }
            if (jQuery(".sticky-top-bar")) {
                ao = ao + jQuery(".sticky-top-bar").height() > 0 ? ao + jQuery(".sticky-top-bar").height() : ao + jQuery("#top-bar").height()
            }
            var ar = jQuery("section.row:in-viewport(" + ao + ")").data("rowname"), an = 0;
            if (!ar) {
                at.find("li").removeClass("selected")
            }
            if (at.is(":visible") && ar) {
                at.find("li").removeClass("selected");
                at.find('li a[data-title="' + ar + '"]').parent().addClass("selected");
                an = at.find('li a[data-title="' + ar + '"]').parent().index() + 1
            }
            if (an > 0) {
                jQuery(".opn-status .current").text(an)
            }
            if (at.hasClass("opn-arrows")) {
                var aq = at.find(".current").text(), ap = at.find(".total").text();
                if (aq === "1") {
                    at.find(".opn-up").addClass("disabled")
                } else {
                    at.find(".opn-up").removeClass("disabled")
                }
                if (aq === ap) {
                    at.find(".opn-down").addClass("disabled")
                } else {
                    at.find(".opn-down").removeClass("disabled")
                }
            }
        }, heroContentSplit: function () {
            var an = jQuery("#main-container");
            SWIFT.page.heroContentSplitResize();
            ag.smartresize(function () {
                SWIFT.page.heroContentSplitResize()
            });
            an.animate({opacity: 1}, 600, "easeOutExpo")
        }, heroContentSplitResize: function () {
            var an = jQuery("#main-container"), ap = ag.height(), ao = 0;
            if (jQuery(".sticky-header").length > 0) {
                ao = jQuery(".sticky-header").height() > 0 ? jQuery(".sticky-header").height() : jQuery("#header-section").height()
            }
            if (jQuery("#wpadminbar").length > 0) {
                ao = ao + jQuery("#wpadminbar").height()
            }
            if (jQuery("#top-bar").length > 0) {
                ao = ao + jQuery("#top-bar").height()
            }
            if (ag.width() > 991) {
                an.css("height", ap - ao)
            }
        }, shareCounts: function () {
            var ap = jQuery(".sf-share-counts"), an = ap.find("a.sf-share-fb"), au = ap.find("a.sf-share-twit"), at = ap.find("a.sf-share-pin"), ar = ap.find("a.sf-share-linked"), aq = window.location.href.replace(window.location.hash, "");
            if (an.length > 0) {
                jQuery.getJSON("https://graph.facebook.com/?id=" + aq + "&callback=?", function (av) {
                    if (av.shares !== undefined && av.shares !== null) {
                        an.find(".count").html(av.shares)
                    }
                    an.find(".count").addClass("animate")
                })
            }
            if (au.length > 0) {
                var ao = "http://urls.api.twitter.com/1/urls/count.json?url=" + aq + "&callback=?";
                if (document.location.protocol == "https:") {
                    ao = "https://urls.api.twitter.com/1/urls/count.json?url=" + aq + "&callback=?"
                }
                jQuery.getJSON(ao, function (av) {
                    if (av.count !== undefined && av.count !== null) {
                        au.find(".count").html(av.count)
                    }
                    au.find(".count").addClass("animate")
                })
            }
            if (ar.length > 0) {
                jQuery.getJSON("https://www.linkedin.com/countserv/count/share?url=" + aq + "&callback=?", function (av) {
                    if (av.count !== undefined && av.count !== null) {
                        ar.find(".count").html(av.count)
                    }
                    ar.find(".count").addClass("animate")
                })
            }
            if (at.length > 0) {
                jQuery.getJSON("https://api.pinterest.com/v1/urls/count.json?url=" + aq + "&callback=?", function (av) {
                    if (av.count !== undefined && av.count !== null) {
                        at.find(".count").html(av.count)
                    }
                    at.find(".count").addClass("animate")
                })
            }
        }, articleNavigation: function () {
            var ap = jQuery(".post-pagination-wrap"), ao = ap.find(".next-article > h2 > a").attr("href"), an = ap.find(".prev-article > h2 > a").attr("href");
            jQuery("article.type-post").hammer().on("swipeleft", function (aq) {
                if (an) {
                    window.location = an
                }
            });
            jQuery("article.type-post").hammer().on("swiperight", function (aq) {
                if (ao) {
                    window.location = ao
                }
            })
        }, postMediaTitle: function () {
            var ao = jQuery(".details-overlay"), an = jQuery(".detail-feature"), ap = ao.height() + 80;
            if (D.hasClass("header-naked-light") || D.hasClass("header-naked-dark")) {
                an.css("padding-top", jQuery(".header-wrap").height() * 2)
            }
            an.css("height", ap);
            setTimeout(function () {
                jQuery(".details-overlay").vCenter().stop().animate({bottom: "50%", opacity: 1}, 1500, "easeOutExpo")
            }, 500);
            ag.smartresize(function () {
                an.css("height", ao.height() + 80);
                jQuery(".details-overlay").vCenter()
            })
        }, lightbox: function () {
            if (!Q) {
                return
            }
            var ao = {};
            if (G) {
                ao = {
                    facebook: {source: "https://www.facebook.com/sharer/sharer.php?u={URL}", text: "Share on Facebook"},
                    twitter: true,
                    googleplus: true,
                    pinterest: {
                        source: "https://pinterest.com/pin/create/button/?url={URL}&media={URL}",
                        text: "Share on Pinterest"
                    }
                }
            }
            var an = [];
            jQuery('[data-rel^="ilightbox["]').each(function () {
                var ap = this.getAttribute("data-rel");
                if (jQuery(this).hasClass("ilightbox-enabled")) {
                    return
                }
                if (jQuery.inArray(ap, an) == -1) {
                    an.push(ap)
                }
            });
            jQuery.each(an, function (ap, aq) {
                jQuery('[data-rel="' + aq + '"]').iLightBox({
                    skin: V,
                    social: {buttons: ao},
                    path: "horizontal",
                    thumbnails: {maxWidth: 120, maxHeight: 120},
                    controls: {arrows: B, thumbnail: p}
                });
                jQuery('[data-rel="' + aq + '"]').addClass("ilightbox-enabled")
            })
        }, backToTop: function () {
            var an = ag.scrollTop();
            if (an > 300) {
                jQuery("#back-to-top").stop().animate({bottom: "10px", opacity: 1}, 300, "easeOutQuart")
            } else {
                if (an < 300) {
                    jQuery("#back-to-top").stop().animate({bottom: "-60px", opacity: 0}, 300, "easeInQuart")
                }
            }
        }, newsletterSubBar: function () {
            var an = jQuery("#sf-newsletter-bar"), ao = "newsletter-sub-bar-hidden";
            setTimeout(function () {
                if (jQuery.cookie(ao) != "1") {
                    an.fadeIn(600)
                }
            }, 3000);
            jQuery("a.sub-close").on("click", "", function (ap) {
                ap.preventDefault();
                jQuery.cookie(ao, "1", {expires: 7});
                an.fadeOut(600)
            })
        }, fwMediaNextPrevAdjust: function () {
            var an = 0;
            if (D.hasClass("single-portfolio")) {
                an = jQuery("article.portfolio").offset().top + jQuery("figure.fw-media-wrap").height() + 80
            } else {
                if (D.hasClass("single-post")) {
                    if (jQuery(".detail-feature").length > 0) {
                        an = jQuery("article.post").offset().top + jQuery(".detail-feature").height() + 80
                    } else {
                        an = jQuery("article.post").offset().top + jQuery("figure.fw-media-wrap").height() + 80
                    }
                }
            }
            jQuery("#prev-article-pagination").addClass("has-fw-media").css("top", an);
            jQuery("#next-article-pagination").addClass("has-fw-media").css("top", an)
        }, fsNextPrev: function () {
            var an = ag.scrollTop(), ap = 0, ao = D.hasClass("single-product") ? 60 : 100;
            if ((D.hasClass("single-portfolio") && jQuery("article.portfolio").hasClass("single-portfolio-fw-media")) || (D.hasClass("single-post") && (jQuery("article.type-post").hasClass("single-post-fw-media-title") || jQuery("article.type-post").hasClass("single-post-fw-media")))) {
                if (D.hasClass("single-portfolio")) {
                    ap = jQuery("article.portfolio").offset().top + jQuery("figure.fw-media-wrap").height() + 200
                } else {
                    if (D.hasClass("single-post")) {
                        if (jQuery(".detail-feature").length > 0) {
                            ap = jQuery("article.post").offset().top + jQuery(".detail-feature").height() + 200
                        } else {
                            ap = jQuery("article.post").offset().top + jQuery("figure.fw-media-wrap").height() + 200
                        }
                    }
                }
                if ((an + ag.height() / 2) > ap) {
                    jQuery("#prev-article-pagination").addClass("fs-nav-fixed");
                    jQuery("#next-article-pagination").addClass("fs-nav-fixed")
                } else {
                    if (an < ap) {
                        jQuery("#prev-article-pagination").removeClass("fs-nav-fixed");
                        jQuery("#next-article-pagination").removeClass("fs-nav-fixed")
                    }
                }
            } else {
                if (an > ao) {
                    jQuery("#prev-article-pagination").stop().animate({left: "0", opacity: 1}, 300, "easeOutQuart");
                    jQuery("#next-article-pagination").stop().animate({right: "0", opacity: 1}, 300, "easeOutQuart")
                } else {
                    if (an < ao) {
                        jQuery("#prev-article-pagination").stop().animate({
                            left: "-200px",
                            opacity: 1
                        }, 300, "easeOutQuart");
                        jQuery("#next-article-pagination").stop().animate({
                            right: "-200px",
                            opacity: 1
                        }, 300, "easeOutQuart")
                    }
                }
            }
        }, getViewportHeight: function () {
            var an = "innerHeight" in window ? window.innerHeight : document.documentElement.offsetHeight;
            return an
        }, checkIE: function () {
            var ap, an = 3, aq = document.createElement("div"), ao = aq.getElementsByTagName("i");
            while (aq.innerHTML = "<!--[if gt IE " + (++an) + "]><i></i><![endif]-->", ao[0]) {
            }
            return an > 4 ? an : ap
        }, pageTransitions: function () {
            jQuery("a").on("click", function (ar) {
                var an = jQuery(this), aq = an.attr("href"), at = an.attr("target"), ap = an.parent(), ao = ap.find("ul.sub-menu");
                if (an.data("toggle") === "tab" || an.parent().parent().hasClass("tabs") || an.parent(".ui-accordion-header").length > 0) {
                    return ar
                }
                if (aq.indexOf("#") === 0 && aq.length > 1) {
                    SWIFT.isScrolling = true;
                    SWIFT.page.onePageNavGoTo(aq);
                    setTimeout(function () {
                        SWIFT.isScrolling = false
                    }, 1000);
                    ar.preventDefault()
                } else {
                    if (aq.indexOf("#") === 0 && aq.length === 1) {
                        return
                    } else {
                        if (at === "_blank") {
                            return
                        } else {
                            if (aq.indexOf("?") >= 0 || aq.indexOf(".jpg") >= 0 || aq.indexOf(".png") >= 0 || aq.indexOf("mailto") >= 0 || ar.ctrlKey || ar.metaKey || aq.indexOf("javascript") === 0 || aq.indexOf("tel:") === 0) {
                                return ar
                            } else {
                                if (D.hasClass("mobile-menu-open") || D.hasClass("mh-overlay-show") || D.hasClass("side-slideout-open") || an.hasClass("cart-contents") || D.hasClass("overlay-menu-open")) {
                                    return
                                } else {
                                    SWIFT.page.fadePageOut(aq);
                                    ar.preventDefault()
                                }
                            }
                        }
                    }
                }
            })
        }, fadePageIn: function () {
            var an = 1000;
            if (jQuery(".parallax-window-height").length > 0) {
                an = 1200
            }
            D.addClass("page-fading-in");
            jQuery("#site-loading").css("opacity", "0");
            setTimeout(function () {
                jQuery("#site-loading").css("display", "none");
                D.removeClass("page-fading-in")
            }, an)
        }, fadePageOut: function (an) {
            jQuery("#site-loading").css("display", "block").transition({opacity: 1, delay: 200}, 600, "ease");
            setTimeout(function () {
                window.location = an
            }, 600)
        }, mobileThumbLinkClick: function () {
            jQuery(document).on("click", ".animated-overlay > a", function (ao) {
                var an = jQuery(this);
                if (an.hasClass("hovered")) {
                    return ao
                } else {
                    ao.preventDefault();
                    an.addClass("hovered")
                }
            })
        }, directorySubmit: function () {
            jQuery(document).on("click", "#sf_directory_calculate_coordinates", function (ao) {
                ao.preventDefault();
                var an = new google.maps.Geocoder();
                an.geocode({address: jQuery("#sf_directory_address").val()}, function (aq, ap) {
                    jQuery("#sf_directory_lat_coord").val(aq[0].geometry.location.lat());
                    jQuery("#sf_directory_lng_coord").val(aq[0].geometry.location.lng())
                })
            });
            jQuery("#directory-submit").click(function (an) {
                if (jQuery("#sf_directory_address").val() === "" || jQuery("#sf_directory_lat_coord").val() === "" || jQuery("sf_directory_lng_coord").val() === "" || jQuery("#directory_title").val() === "" || jQuery("#directory_description").val() === "" || jQuery("#directory-cat").val() <= 0 || jQuery("#directory-loc").val() <= 0) {
                    an.preventDefault();
                    jQuery(".directory-error").show();
                    jQuery("html, body").animate({scrollTop: jQuery(".directory-error").offset().top - 100}, 700);
                    return false
                }
                jQuery("#add-directory-entry").submit()
            })
        }
    };
    SWIFT.superSearch = {
        init: function () {
            jQuery(".search-options .ss-dropdown").on("click", function (ao) {
                ao.preventDefault();
                var an = jQuery(this), ap = an.find("ul");
                if (I) {
                    if (ap.hasClass("show-dropdown")) {
                        setTimeout(function () {
                            ap.removeClass("show-dropdown")
                        }, 100)
                    } else {
                        ap.addClass("show-dropdown")
                    }
                } else {
                    if (ap.hasClass("show-dropdown")) {
                        setTimeout(function () {
                            ap.removeClass("show-dropdown")
                        }, 100)
                    } else {
                        ap.addClass("show-dropdown")
                    }
                }
            });
            jQuery(".ss-option").on("click", function (ap) {
                ap.preventDefault();
                var an = jQuery(this), ao = an.attr("data-attr_value"), aq = an.parent().parent().parent();
                aq.find("li").removeClass("selected");
                an.parent().addClass("selected");
                aq.attr("data-attr_value", ao);
                aq.find("span").text(an.text());
                setTimeout(function () {
                    an.parents("ul").first().removeClass("show-dropdown")
                }, 100)
            });
            jQuery(".super-search-go").on("click", function (ar) {
                ar.preventDefault();
                var aq = jQuery(this).parents(".sf-super-search"), ao = SWIFT.superSearch.urlBuilder(aq), ap = jQuery(this).attr("data-home_url"), an = jQuery(this).attr("data-shop_url");
                if (ao.indexOf("product_cat") >= 0) {
                    location.href = ap + ao
                } else {
                    location.href = an + ao
                }
            })
        }, urlBuilder: function (an) {
            var ao = "";
            jQuery(an).find(".search-options .ss-dropdown").each(function () {
                var ap = jQuery(this).attr("id");
                var aq = jQuery(this).attr("data-attr_value");
                if (aq !== "") {
                    if (ap === "product_cat") {
                        if (ao === "") {
                            ao += "?product_cat=" + aq
                        } else {
                            ao += "&product_cat=" + aq
                        }
                    } else {
                        if (ao === "") {
                            ao += "?filter_" + ap + "=" + aq
                        } else {
                            ao += "&filter_" + ap + "=" + aq
                        }
                    }
                }
            });
            jQuery(".search-options input").each(function () {
                var ap = jQuery(this).attr("name");
                var aq = jQuery(this).attr("value");
                if (ao === "") {
                    ao += "?" + ap + "=" + aq
                } else {
                    ao += "&" + ap + "=" + aq
                }
            });
            return ao
        }
    };
    SWIFT.header = {
        init: function () {
            var ao = "", ar = false;
            if (D.hasClass("sticky-header-enabled") && !D.hasClass("vertical-header")) {
                SWIFT.header.stickyHeaderInit()
            }
            if (jQuery(".sticky-top-bar").length > 0) {
                SWIFT.header.stickyTopBarInit()
            }
            if (jQuery("#header-section").hasClass("header-split")) {
                SWIFT.header.splitHeader(true);
                ag.smartresize(function () {
                    SWIFT.header.splitHeader()
                })
            }
            if (jQuery("#fullscreen-search").length > 0) {
                SWIFT.header.fsSearch()
            }
            jQuery("a.fs-overlay-close").on("click", function (at) {
                at.preventDefault();
                if (D.hasClass("overlay-menu-open")) {
                    SWIFT.header.overlayMenuToggle()
                }
                if (D.hasClass("fs-supersearch-open")) {
                    SWIFT.header.fsSuperSearchToggle()
                }
                if (D.hasClass("fs-search-open")) {
                    SWIFT.header.fsSearchToggle()
                }
            });
            jQuery("a.fs-header-search-link").on("click", function (at) {
                at.preventDefault();
                if (D.hasClass("overlay-menu-open")) {
                    SWIFT.header.overlayMenuToggle()
                }
                if (D.hasClass("fs-supersearch-open")) {
                    SWIFT.header.fsSuperSearchToggle()
                }
                SWIFT.header.fsSearchToggle()
            });
            jQuery("a.fs-supersearch-link").on("click", function (at) {
                at.preventDefault();
                if (D.hasClass("overlay-menu-open")) {
                    SWIFT.header.overlayMenuToggle()
                }
                if (D.hasClass("fs-search-open")) {
                    SWIFT.header.fsSearchToggle()
                }
                SWIFT.header.fsSuperSearchToggle()
            });
            jQuery("a.overlay-menu-link").on("click", function (at) {
                at.preventDefault();
                SWIFT.header.overlayMenuToggle();
                if (D.hasClass("fs-search-open")) {
                    SWIFT.header.fsSearchToggle()
                }
                if (D.hasClass("fs-supersearch-open")) {
                    SWIFT.header.fsSuperSearchToggle()
                }
            });
            jQuery("#overlay-menu li.menu-item > a").on("click", function (aw) {
                var au = jQuery(this).parent(), av = jQuery(this).attr("href"), ax = jQuery(this).attr("target"), at = au.find("ul.sub-menu").first();
                if (!au.hasClass("parent")) {
                    SWIFT.header.overlayMenuToggle();
                    if (av.indexOf("#") === 0 && av.length > 1) {
                        SWIFT.isScrolling = true;
                        SWIFT.page.onePageNavGoTo(av);
                        setTimeout(function () {
                            SWIFT.isScrolling = false
                        }, 1000);
                        aw.preventDefault()
                    } else {
                        if (D.hasClass("page-transitions")) {
                            if (ax === "_blank") {
                                return aw
                            } else {
                                SWIFT.page.fadePageOut(av)
                            }
                        }
                    }
                    return aw
                }
                if (au.hasClass("sub-menu-open")) {
                    if (av.indexOf("http") === 0 || av.indexOf("/") === 0) {
                        return aw
                    } else {
                        au.removeClass("sub-menu-open");
                        at.slideUp();
                        aw.preventDefault()
                    }
                } else {
                    au.addClass("sub-menu-open");
                    at.slideDown();
                    aw.preventDefault()
                }
            });
            jQuery("a.side-slideout-link").on("click", function (at) {
                at.preventDefault();
                SWIFT.nav.showSideSlideout(jQuery(this).data("side"))
            });
            ag.smartresize(function () {
                var at = ag.width();
                if (at < 1024 && D.hasClass("mhs-tablet-land") && D.hasClass("side-slideout-open")) {
                    SWIFT.nav.sideSlideoutHideTrigger()
                } else {
                    if (at < 991 && D.hasClass("mhs-tablet-port") && D.hasClass("side-slideout-open")) {
                        SWIFT.nav.sideSlideoutHideTrigger()
                    } else {
                        if (at < 767 && D.hasClass("mhs-mobile") && D.hasClass("side-slideout-open")) {
                            SWIFT.nav.sideSlideoutHideTrigger()
                        }
                    }
                }
            });
            jQuery(".header-search-link-alt").on("click", function (av) {
                av.preventDefault();
                var au = jQuery(this), at = au.parent().find(".ajax-search-wrap");
                if (at.is(":visible")) {
                    at.fadeOut(300);
                    au.removeClass("search-open");
                    setTimeout(function () {
                        jQuery(".ajax-search-results").slideUp(100).empty();
                        jQuery(".ajax-search-form input[name=s]").val("")
                    }, 300)
                } else {
                    at.fadeIn(300);
                    au.addClass("search-open");
                    setTimeout(function () {
                        jQuery(".ajax-search-form input[name=s]").focus();
                        jQuery("#container").bind("click", function (ax) {
                            var aw = jQuery(".ajax-search-wrap");
                            if (!jQuery(ax.target).closest(".ajax-search-wrap").length) {
                                aw.fadeOut(300);
                                setTimeout(function () {
                                    jQuery(".ajax-search-results").slideUp(100).empty();
                                    jQuery(".ajax-search-form input[name=s]").val("")
                                }, 300);
                                jQuery("#container").unbind("click")
                            }
                        })
                    }, 300)
                }
            });
            jQuery(".ajax-search-form input[name=s],#fs-search-input").on("keyup", function (av) {
                var at = av.currentTarget.value, au = jQuery(".ajax-search-form").attr("action");
                if (jQuery(this).hasClass("noajax")) {
                    return av
                }
                clearTimeout(ar);
                if (ao != jQuery.trim(at) && at.length >= 3) {
                    ar = setTimeout(function () {
                        if (jQuery("#fullscreen-search").length > 0 && history.pushState) {
                            jQuery("#fullscreen-search").find(".search-wrap").animate({"margin-top": "10%"}, 200);
                            var aw = au + "?s=" + at;
                            window.history.pushState({path: aw}, "", aw)
                        }
                        SWIFT.header.ajaxSearch(av)
                    }, 400)
                }
            });
            jQuery("a.contact-menu-link").on("click", function (au) {
                au.preventDefault();
                var av = jQuery("#contact-slideout"), at = jQuery(this);
                if (D.scrollTop() > 0) {
                    jQuery("body,html").animate({scrollTop: 0}, 600, "easeOutCubic");
                    setTimeout(function () {
                        av.slideToggle(800, "easeInOutExpo");
                        if (at.hasClass("slide-open")) {
                            at.removeClass("slide-open")
                        } else {
                            SWIFT.map.init();
                            at.addClass("slide-open")
                        }
                    }, 800)
                } else {
                    av.slideToggle(800, "easeInOutExpo");
                    if (at.hasClass("slide-open")) {
                        at.removeClass("slide-open")
                    } else {
                        SWIFT.map.init();
                        at.addClass("slide-open")
                    }
                }
            });
            if (D.hasClass("mh-sticky")) {
                if (I) {
                    jQuery("html").addClass("has-mh-sticky")
                }
                var an = jQuery("#mobile-header"), aq = 0;
                an.sticky({topSpacing: aq});
                jQuery("#mobile-header-sticky-wrapper").css("height", an.outerHeight(true));
                ag.smartresize(function () {
                    an.sticky("update");
                    jQuery("#mobile-header-sticky-wrapper").css("height", an.outerHeight(true))
                })
            }
            if (D.hasClass("layout-boxed") && D.hasClass("vertical-header-right")) {
                var ap = (ag.width() - jQuery("#container").width()) / 2;
                jQuery(".header-wrap").css("right", ap);
                ag.smartresize(function () {
                    var at = (ag.width() - jQuery("#container").width()) / 2;
                    jQuery(".header-wrap").css("right", at)
                })
            }
        }, stickyHeaderInit: function () {
            var ar = 0, aq = jQuery(".sticky-header"), an = jQuery(".header-wrap");
            if (jQuery("#wpadminbar").length > 0) {
                ar = 32
            }
            if (jQuery(".sticky-top-bar").length > 0) {
                ar += jQuery(".sticky-top-bar").outerHeight()
            }
            aq.sticky({topSpacing: ar});
            ag.smartresize(function () {
                aq.sticky("update")
            });
            if (D.hasClass("layout-boxed")) {
                jQuery(".sticky-header").css("max-width", an.width());
                ag.smartresize(function () {
                    jQuery(".sticky-header").css("max-width", an.width())
                })
            }
            if (D.hasClass("sh-dynamic")) {
                var ao = an.offset().top;
                ag.scroll(function () {
                    ao = an.offset().top - ag.scrollTop();
                    if (jQuery(".sticky-wrapper").hasClass("is-sticky") && ao < -160) {
                        an.addClass("resized-header")
                    } else {
                        if (an.hasClass("resized-header")) {
                            an.removeClass("resized-header")
                        }
                    }
                })
            }
            if (D.hasClass("sh-show-hide")) {
                var ap = 0;
                ag.scroll(function (ay) {
                    var au = jQuery(this).scrollTop();
                    var at = 800;
                    var az = 0;
                    if (jQuery("#container > .swift-slider-outer").length > 0) {
                        var ax = jQuery("#container > .swift-slider-outer"), aw = ax.offset().top;
                        az = ax.height();
                        at = aw + az + 100
                    } else {
                        if (jQuery("#container > .home-slider-wrap").length > 0) {
                            var av = jQuery("#main-container").offset().top;
                            az = jQuery("#container > .home-slider-wrap").height();
                            at = av + az + 100
                        }
                    }
                    if (au > ap && au > at) {
                        if (D.hasClass("fs-supersearch-open") || D.hasClass("overlay-menu-open") || D.hasClass("fs-search-open")) {
                            return
                        }
                        jQuery(".sticky-header").addClass("sticky-header-hide")
                    } else {
                        if (jQuery(".sticky-header").hasClass("sticky-header-hide")) {
                            jQuery(".sticky-header").removeClass("sticky-header-hide")
                        }
                    }
                    ap = au
                })
            }
        }, stickyTopBarInit: function () {
            var ap = 0, ao = jQuery(".sticky-top-bar"), an = jQuery(".header-wrap");
            if (jQuery("#wpadminbar").length > 0) {
                ap = 32
            }
            ao.sticky({topSpacing: ap});
            ag.smartresize(function () {
                ao.sticky("update")
            });
            if (D.hasClass("layout-boxed")) {
                ao.css("max-width", an.width());
                ag.smartresize(function () {
                    ao.css("max-width", an.width())
                })
            }
        }, splitHeader: function (az) {
            var an = jQuery("#main-navigation"), au = an.find("> div > ul");
            au.find("> li").each(function () {
                if (D.hasClass("logged-in") && jQuery(this).hasClass("sf-menu-item-loggedout")) {
                    jQuery(this).remove()
                } else {
                    if (D.hasClass("logged-out") && jQuery(this).hasClass("sf-menu-item-loggedin")) {
                        jQuery(this).remove()
                    }
                }
            });
            var aB = au.find("> li").length, aq = jQuery("#logo");
            if (aB <= 0) {
                if (az) {
                    aq.imagesLoaded(function () {
                        aw = aq.width();
                        aq.css("margin-left", -(aw / 2))
                    });
                    jQuery(".header-split").addClass("header-split-loaded")
                }
                return
            } else {
                var ar = au.find("> li:nth-child(1)"), aA = Math.floor(aB / 2), ao = au.find("> li:nth-child(" + aA + ")"), aw = 0, ax = 62, av = 0, ay = 0;
                if (aq.find("img").length > 0) {
                    aq.imagesLoaded(function () {
                        aw = aq.width();
                        aq.css("margin-left", -(aw / 2));
                        au.find("> li").each(function () {
                            var aE = jQuery(this), aF = aE.index();
                            if (aF < aA) {
                                aE.addClass("left-side-item");
                                av += aE.width()
                            } else {
                                aE.addClass("right-side-item");
                                ay += aE.width()
                            }
                        });
                        if (av > ay) {
                            var aD = Math.floor((av - ay) / 2);
                            au.css("margin-left", -aD + "px")
                        } else {
                            var aC = Math.floor((ay - av) / 2);
                            au.css("margin-right", -aC + "px")
                        }
                        if (W) {
                            ao.css("margin-left", aw + ax + "px")
                        } else {
                            ao.css("margin-right", aw + ax + "px")
                        }
                        if (az) {
                            jQuery(".header-split").addClass("header-split-loaded")
                        }
                    })
                } else {
                    aw = aq.width();
                    aq.css("margin-left", -(aw / 2));
                    au.find("> li").each(function () {
                        var aC = jQuery(this), aD = aC.index();
                        if (aD < aA) {
                            av += aC.width()
                        } else {
                            ay += aC.width()
                        }
                    });
                    if (av > ay) {
                        var ap = Math.floor((av - ay) / 2);
                        au.css("margin-left", -ap + "px")
                    } else {
                        var at = Math.floor((ay - av) / 2);
                        au.css("margin-right", -at + "px")
                    }
                    ao.css("margin-right", aw + ax + "px");
                    if (az) {
                        jQuery(".header-split").addClass("header-split-loaded")
                    }
                }
            }
        }, ajaxSearch: function (ar) {
            var ao = jQuery(ar.currentTarget), an = ao.parents("form").serialize() + "&action=sf_ajaxsearch", ap = jQuery(".ajax-search-results"), aq = jQuery(".search-wrap .ajax-loading"), at = jQuery(".search-wrap").data("ajaxurl");
            jQuery.ajax({
                url: at, type: "POST", data: an, beforeSend: function () {
                    jQuery(".ajax-search-results").slideUp(200);
                    setTimeout(function () {
                        aq.fadeIn(50)
                    }, 150)
                }, success: function (au) {
                    if (au === 0 || au == "0") {
                        au = ""
                    } else {
                        ap.html(au)
                    }
                }, complete: function () {
                    aq.fadeOut(200);
                    setTimeout(function () {
                        ap.slideDown(400);
                        if (jQuery("#fullscreen-search").length > 0) {
                            ap.find(".search-result").each(function (av) {
                                var au = jQuery(this);
                                setTimeout(function () {
                                    au.addClass("load-in")
                                }, 200 * av)
                            })
                        }
                    }, 200)
                }
            })
        }, fsSearch: function () {
            var ao = jQuery("#fullscreen-search"), an = ao.find("#fs-search-input");
            an.autoGrowInput()
        }, fsSearchToggle: function () {
            var ao = jQuery("#fullscreen-search"), an = ao.find("#fs-search-input");
            if (D.hasClass("fs-search-open")) {
                D.removeClass("fs-aux-open");
                D.removeClass("fs-search-open");
                D.addClass("fs-search-closing");
                setTimeout(function () {
                    if (!D.hasClass("overlay-menu-open")) {
                        jQuery("#main-nav,#main-navigation").fadeIn(400)
                    }
                }, 200)
            } else {
                setTimeout(function () {
                    D.removeClass("fs-search-closing");
                    D.addClass("fs-search-open");
                    D.addClass("fs-aux-open");
                    an.focus();
                    jQuery("#main-nav,#main-navigation").fadeOut(300)
                }, 30)
            }
        }, fsSuperSearchToggle: function () {
            var an = jQuery("#fullscreen-supersearch");
            if (D.hasClass("fs-supersearch-open")) {
                D.removeClass("fs-supersearch-open");
                D.removeClass("fs-aux-open");
                D.addClass("fs-supersearch-closing");
                setTimeout(function () {
                    jQuery("#main-nav,#main-navigation").fadeIn(400)
                }, 200)
            } else {
                setTimeout(function () {
                    D.removeClass("fs-supersearch-closing");
                    D.addClass("fs-supersearch-open");
                    D.addClass("fs-aux-open");
                    jQuery("#main-nav,#main-navigation").fadeOut(300)
                }, 30)
            }
        }, overlayMenuToggle: function () {
            var ap = jQuery("#overlay-menu"), ao = Math.floor(ap.find("nav ul.menu").height() / ap.find("ul.menu > li.menu-item").length) - 5, an = Math.floor(ao * 0.5);
            if (an > 60) {
                an = 60
            }
            ap.find("ul.menu > li.menu-item > a").css("font-size", an + "px").css("line-height", ao - 20 + "px");
            if (D.hasClass("overlay-menu-open")) {
                D.removeClass("overlay-menu-open");
                D.removeClass("fs-aux-open");
                D.addClass("overlay-menu-closing");
                setTimeout(function () {
                    if (!D.hasClass("fs-search-open")) {
                        jQuery("#main-nav,#main-navigation").fadeIn(400)
                    }
                    D.removeClass("overlay-menu-closing")
                }, 200)
            } else {
                setTimeout(function () {
                    D.removeClass("overlay-menu-closing");
                    D.addClass("overlay-menu-open");
                    D.addClass("fs-aux-open");
                    jQuery("#main-nav,#main-navigation").fadeOut(300)
                }, 30)
            }
        }
    };
    SWIFT.nav = {
        init: function () {
            if (!N || ag.width() > 768) {
                SWIFT.nav.mainMenu()
            }
            SWIFT.nav.mobileMenuInit();
            SWIFT.nav.mainMenuActions();
            if (jQuery(".sf-side-slideout").length > 0) {
                SWIFT.nav.sideSlideoutInit()
            }
        }, mainMenu: function () {
            var an = jQuery("#main-navigation");
            if (jQuery(".header-wrap").hasClass("full-center")) {
                an.find("li.sf-mega-menu > ul.sub-menu").each(function () {
                    var aq = jQuery(this);
                    if (!aq.children().first().hasClass("container")) {
                        jQuery(this).wrapInner('<div class="container"></div>')
                    }
                })
            }
            an.find(".menu li.menu-item").hoverIntent({
                over: function () {
                    if (jQuery("#container").width() > 767 || D.hasClass("responsive-fixed")) {
                        jQuery(this).find("ul.sub-menu,.mega-menu-sub").first().fadeIn(200)
                    }
                }, out: function () {
                    if (jQuery("#container").width() > 767 || D.hasClass("responsive-fixed")) {
                        jQuery(this).find("ul.sub-menu,.mega-menu-sub").first().fadeOut(150)
                    }
                }, timeout: 0
            });
            var ap = an.height(), ao = an.find(".sub-menu");
            ao.each(function () {
                jQuery(this).css("top", ap)
            })
        }, mainMenuActions: function () {
            jQuery("ul.sub-menu").parents("li").addClass("parent");
            jQuery(".menu li.parent > a").on("click", function (ap) {
                if (jQuery("#container").width() < 1024 || D.hasClass("standard-browser")) {
                    return ap
                }
                var ao = jQuery(this).parent().find("ul.sub-menu").first();
                if (ao.css("opacity") === "1" || ao.css("opacity") === 1) {
                    return ap
                } else {
                    ap.preventDefault()
                }
            });
            jQuery("nav.std-menu").find(".menu li").each(function () {
                var ao = jQuery(this).outerHeight();
                jQuery(this).find("ul.sub-menu").first().css("top", ao)
            });
            jQuery("nav.std-menu").find(".menu li.parent").hoverIntent({
                over: function () {
                    var ao = jQuery(this).parents(".sf-side-slideout").length > 0;
                    if ((jQuery("#container").width() > 767 || D.hasClass("responsive-fixed")) && !ao) {
                        jQuery(this).find("ul.sub-menu").first().stop(true, true).fadeIn(200)
                    }
                }, out: function () {
                    var ao = jQuery(this).parents(".sf-side-slideout").length > 0;
                    if ((jQuery("#container").width() > 767 || D.hasClass("responsive-fixed")) && !ao) {
                        jQuery(this).find(".sub-menu").first().stop(true, true).fadeOut(150)
                    }
                }, timeout: 100
            });
            jQuery(document).on("mouseenter", "li.shopping-bag-item", function () {
                if (jQuery(this).parents("#mobile-menu-wrap").length > 0 || jQuery(this).parents("#mobile-cart-wrap").length > 0) {
                    return
                }
                if (jQuery("#container").width() > 767 || D.hasClass("responsive-fixed")) {
                    jQuery(this).find("ul.sub-menu").first().stop(true, true).fadeIn(200);
                    al = true
                }
            }).on("mouseleave", "li.shopping-bag-item", function () {
                if (jQuery(this).parents("#mobile-menu-wrap").length > 0 || jQuery(this).parents("#mobile-cart-wrap").length > 0) {
                    return
                }
                if (jQuery("#container").width() > 767 || D.hasClass("responsive-fixed")) {
                    jQuery(this).find("ul.sub-menu").first().stop(true, true).fadeOut(150);
                    al = false
                }
            });
            jQuery(".menu-item").on("click", "a", function (ay) {
                var ao = jQuery(this), aw = ao.attr("href"), aq = false, au = false, ax = false, ar = aw.match(/watch\?v=([a-zA-Z0-9\-_]+)/), ap = aw.match(/^http:\/\/(www\.)?vimeo\.com\/(clip\:)?(\d+).*$/);
                if (jQuery(this).parents("nav").attr("id") === "mobile-menu") {
                    aq = true
                }
                if (jQuery(this).parents(".sf-side-slideout").length > 0) {
                    au = true
                }
                if (jQuery(this).parents("#overlay-menu").length > 0) {
                    ax = true
                }
                if (ar || ap) {
                    var at = "";
                    if (ar) {
                        at = "https://www.youtube.com/embed/" + ar[1] + "?autoplay=1&amp;wmode=transparent"
                    } else {
                        if (ap) {
                            at = "https://player.vimeo.com/video/" + ap[3] + "?title=0&amp;byline=0&amp;portrait=0&amp;autoplay=1&amp;wmode=transparent"
                        }
                    }
                    if (at !== "") {
                        jQuery(this).data("video", at);
                        SWIFT.widgets.openFullWidthVideo(jQuery(this))
                    }
                    ay.preventDefault()
                } else {
                    if (aw.indexOf("#") === 0 && aw.length > 1) {
                        var av = 0;
                        if (ax) {
                            return
                        } else {
                            if (aq) {
                                SWIFT.nav.mobileMenuHideTrigger();
                                setTimeout(function () {
                                    if (D.hasClass("mh-sticky")) {
                                        av = jQuery("#mobile-header").height()
                                    }
                                    if (jQuery("#wpadminbar").length > 0) {
                                        av = av + jQuery("#wpadminbar").height()
                                    }
                                    if (jQuery(aw).length > 0) {
                                        jQuery("html, body").stop().animate({scrollTop: jQuery(aw).offset().top - av + 2}, 1000, "easeInOutExpo")
                                    }
                                }, 400)
                            } else {
                                SWIFT.page.onePageNavGoTo(aw)
                            }
                        }
                        ay.preventDefault()
                    } else {
                        if (aq || ax) {
                            return
                        } else {
                            return ay
                        }
                    }
                }
            });
            var an = jQuery("li.aux-languages").find(".current-language").html();
            if (an !== "") {
                jQuery("li.aux-languages > a").html(an)
            }
            jQuery("li.aux-languages > a").animate({opacity: 1}, 400, "easeOutQuart");
            ag.smartresize(function () {
                if (jQuery("#container").width() > 767 || D.hasClass("responsive-fixed")) {
                    var ao = jQuery("nav").find("ul.menu");
                    ao.each(function () {
                        jQuery(this).css("display", "")
                    })
                }
            });
            if (jQuery("section.row.row-has-id").length > 0) {
                SWIFT.nav.currentScrollIndication();
                ag.on("scroll", function () {
                    jQuery.throttle(250, SWIFT.nav.currentScrollIndication)
                })
            }
        }, currentScrollIndication: function () {
            var an = 0, ap;
            if (D.hasClass("sticky-header-enabled")) {
                an = jQuery(".header-wrap").height()
            }
            if (jQuery(".sticky-top-bar").length > 0) {
                an += jQuery(".sticky-top-bar").outerHeight()
            }
            var aq = jQuery("section.row:in-viewport(" + an + ")").attr("id"), ao = jQuery("#main-navigation .menu li a");
            if (typeof aq === "undefined") {
                return
            }
            ap = ao.filter('[href="#' + aq + '"]');
            jQuery("#main-navigation").find(".current-scroll-item").removeClass("current-scroll-item");
            if (ap.length > 0 && !ap.hasClass(".current-scroll-item")) {
                ap.parent().addClass("current-scroll-item")
            }
        }, mobileMenuInit: function () {
            jQuery("#mobile-logo > a").on("click touchstart", function (an) {
                if (D.hasClass("mobile-menu-open") || D.hasClass("mobile-cart-open") || D.hasClass("mobile-menu-closing")) {
                    return false
                } else {
                    return an
                }
            });
            jQuery(".mobile-menu-link").on("click", function (an) {
                an.preventDefault();
                if (D.hasClass("mh-overlay")) {
                    SWIFT.nav.mobileHeaderOverlay("menu")
                } else {
                    if (D.hasClass("mobile-menu-open")) {
                        SWIFT.nav.mobileMenuHideTrigger()
                    } else {
                        SWIFT.nav.showMobileMenu()
                    }
                }
            });
            jQuery(document).on("click", ".cart-contents", function (an) {
                if (jQuery(this).parents(".mobile-header-opts").length > 0) {
                    an.preventDefault();
                    if (D.hasClass("mh-overlay")) {
                        SWIFT.nav.mobileHeaderOverlay("cart")
                    } else {
                        if (D.hasClass("mobile-menu-open")) {
                            SWIFT.nav.mobileMenuHideTrigger()
                        } else {
                            SWIFT.nav.showMobileCart()
                        }
                    }
                } else {
                    return an
                }
            });
            jQuery(".mobile-overlay-close").on("click", function (an) {
                an.preventDefault();
                if (D.hasClass("mh-cart-show")) {
                    jQuery("#mobile-cart-wrap").animate({opacity: 0}, 500, "easeOutQuart");
                    setTimeout(function () {
                        D.removeClass("mh-overlay-show");
                        D.removeClass("mh-cart-show");
                        jQuery("#mobile-cart-wrap").css("display", "none")
                    }, 500)
                } else {
                    if (D.hasClass("mh-menu-show")) {
                        jQuery("#mobile-menu-wrap").animate({opacity: 0}, 500, "easeOutQuart");
                        setTimeout(function () {
                            D.removeClass("mh-overlay-show");
                            D.removeClass("mh-menu-show");
                            jQuery("#mobile-menu-wrap").css("display", "none")
                        }, 500)
                    }
                }
            });
            jQuery("#mobile-menu li > a").on("click", function (aq) {
                var ao = jQuery(this).parent(), ap = jQuery(this).attr("href"), an = ao.find("ul.sub-menu").first();
                if (!ao.hasClass("parent")) {
                    SWIFT.nav.mobileMenuHideTrigger();
                    if (ap.indexOf("#") === 0 && ap.length > 1) {
                        SWIFT.isScrolling = true;
                        SWIFT.page.onePageNavGoTo(ap);
                        setTimeout(function () {
                            SWIFT.isScrolling = false
                        }, 1000);
                        aq.preventDefault()
                    } else {
                        if (D.hasClass("page-transitions")) {
                            SWIFT.page.fadePageOut(ap)
                        }
                    }
                    return aq
                }
                if (ao.hasClass("sub-menu-open")) {
                    if (ap.indexOf("http") === 0 || ap.indexOf("/") === 0) {
                        return aq
                    } else {
                        ao.removeClass("sub-menu-open");
                        an.slideUp();
                        aq.preventDefault()
                    }
                } else {
                    ao.addClass("sub-menu-open");
                    an.slideDown();
                    aq.preventDefault()
                }
            });
            jQuery("#mobile-menu-wrap").swipe({
                swipeLeft: function () {
                    if (!D.hasClass("mobile-header-center-logo-alt") && !D.hasClass("mobile-header-left-logo")) {
                        SWIFT.nav.mobileMenuHideTrigger()
                    }
                }, swipeRight: function () {
                    if (D.hasClass("mobile-header-center-logo-alt") || D.hasClass("mobile-header-left-logo")) {
                        SWIFT.nav.mobileMenuHideTrigger()
                    }
                },
            });
            jQuery("#mobile-cart-wrap").swipe({
                swipeLeft: function () {
                    if (D.hasClass("mobile-header-center-logo-alt") || D.hasClass("mobile-header-right-logo") || D.hasClass("mobile-header-center-logo")) {
                        SWIFT.nav.mobileMenuHideTrigger()
                    }
                }, swipeRight: function () {
                    if (!D.hasClass("mobile-header-center-logo-alt") && !D.hasClass("mobile-header-right-logo")) {
                        SWIFT.nav.mobileMenuHideTrigger()
                    }
                },
            });
            ag.smartresize(function () {
                var an = ag.width();
                if (an > 1024 && D.hasClass("mhs-tablet-land")) {
                    SWIFT.nav.mobileMenuHideTrigger()
                } else {
                    if (an > 991 && D.hasClass("mhs-tablet-port")) {
                        SWIFT.nav.mobileMenuHideTrigger()
                    } else {
                        if (an > 767 && D.hasClass("mhs-mobile")) {
                            SWIFT.nav.mobileMenuHideTrigger()
                        }
                    }
                }
            })
        }, showMobileMenu: function () {
            D.addClass("mobile-menu-open");
            setTimeout(function () {
                jQuery("#container").on("click touchstart", SWIFT.nav.mobileMenuHideTrigger)
            }, 400)
        }, hideMobileMenu: function () {
            var an = ag.scrollTop();
            D.removeClass("mobile-menu-open");
            if (D.hasClass("mh-overlay-show")) {
                jQuery("#mobile-menu-wrap").animate({opacity: 0}, 300, "easeOutQuart")
            }
            setTimeout(function () {
                D.removeClass("mh-menu-show");
                if (D.hasClass("mh-overlay-show")) {
                    D.removeClass("mh-overlay-show");
                    jQuery("#mobile-menu-wrap").css("display", "none")
                }
                jQuery("#container").off("click touchstart", SWIFT.nav.mobileMenuHideTrigger)
            }, 300);
            setTimeout(function () {
                D.removeClass("mobile-menu-closing")
            }, 1000)
        }, showMobileCart: function () {
            D.addClass("mobile-cart-open");
            setTimeout(function () {
                jQuery("#container").on("click touchstart", SWIFT.nav.mobileMenuHideTrigger)
            }, 400)
        }, hideMobileCart: function () {
            var an = ag.scrollTop();
            D.removeClass("mobile-cart-open");
            if (D.hasClass("mh-overlay-show")) {
                jQuery("#mobile-cart-wrap").animate({opacity: 0}, 300, "easeOutQuart")
            }
            setTimeout(function () {
                if (D.hasClass("mh-overlay-show")) {
                    D.removeClass("mh-overlay-show");
                    jQuery("#mobile-cart-wrap").css("display", "none")
                }
                D.removeClass("mh-cart-show");
                jQuery("#container").off("click touchstart", SWIFT.nav.mobileMenuHideTrigger)
            }, 400);
            setTimeout(function () {
                D.removeClass("mobile-menu-closing")
            }, 1000)
        }, mobileMenuHideTrigger: function (an) {
            if (an) {
                an.preventDefault()
            }
            D.addClass("mobile-menu-closing");
            SWIFT.nav.hideMobileMenu();
            SWIFT.nav.hideMobileCart()
        }, mobileHeaderOverlay: function (an) {
            if (an === "menu") {
                jQuery("#mobile-menu-wrap").css("display", "block");
                D.addClass("mh-overlay-show");
                D.addClass("mh-menu-show");
                jQuery("#mobile-menu-wrap").animate({opacity: 1}, 500, "easeOutQuart")
            } else {
                if (an === "cart") {
                    jQuery("#mobile-cart-wrap").css("display", "block");
                    D.addClass("mh-overlay-show");
                    D.addClass("mh-cart-show");
                    jQuery("#mobile-cart-wrap").animate({opacity: 1}, 500, "easeOutQuart")
                }
            }
        }, showSideSlideout: function (an) {
            var ao = ag.scrollTop();
            if (an === "left") {
                jQuery("#side-slideout-left-wrap").css("display", "block");
                D.addClass("side-slideout-open");
                D.addClass("side-slideout-left-open")
            } else {
                jQuery("#side-slideout-right-wrap").css("display", "block");
                D.addClass("side-slideout-open");
                D.addClass("side-slideout-right-open")
            }
            if (ao > 0 && D.hasClass("sticky-header-enabled") && jQuery(".sticky-wrapper").hasClass("is-sticky")) {
                m = jQuery(".sticky-header").css("top");
                jQuery(".sticky-header").css("position", "absolute").css("top", ao);
                if (jQuery(".sticky-top-bar").length > 0) {
                    jQuery(".sticky-top-bar").css("position", "absolute").css("top", ao)
                }
            }
            setTimeout(function () {
                jQuery("#container").on("click touchstart", SWIFT.nav.sideSlideoutHideTrigger)
            }, 400)
        }, hideSideSlideout: function () {
            D.removeClass("side-slideout-open side-slideout-left-open side-slideout-right-open");
            setTimeout(function () {
                jQuery("#container").off("click touchstart", SWIFT.nav.sideSlideoutHideTrigger)
            }, 400);
            setTimeout(function () {
                D.removeClass("side-slideout-closing");
                if (D.hasClass("sticky-header-enabled") && jQuery(".sticky-wrapper").hasClass("is-sticky")) {
                    jQuery(".sticky-header").css("position", "fixed").css("top", m);
                    jQuery(".sticky-top-bar").css("position", "fixed").css("top", m)
                }
            }, 1000)
        }, sideSlideoutHideTrigger: function () {
            D.addClass("side-slideout-closing");
            SWIFT.nav.hideSideSlideout()
        }, sideSlideoutInit: function () {
            jQuery(".sf-side-slideout li.menu-item > a").on("click", function (ar) {
                var ap = jQuery(this).parent(), aq = jQuery(this).attr("href"), an = ap.find("ul.sub-menu").first(), ao = an.parent();
                if (!ap.hasClass("parent")) {
                    SWIFT.nav.sideSlideoutHideTrigger();
                    if (D.hasClass("page-transitions")) {
                        SWIFT.page.fadePageOut(aq)
                    }
                    return ar
                }
                if (ao.hasClass("sub-menu-open")) {
                    if (aq.indexOf("http") === 0 || aq.indexOf("/") === 0) {
                        return ar
                    } else {
                        ao.removeClass("sub-menu-open");
                        an.slideUp();
                        ar.preventDefault()
                    }
                } else {
                    ao.addClass("sub-menu-open");
                    an.slideDown();
                    ar.preventDefault()
                }
            })
        }
    };
    SWIFT.woocommerce = {
        init: function () {
            SWIFT.woocommerce.shopLayoutSwitch();
            if (D.hasClass("archive") && D.hasClass("woocommerce")) {
                SWIFT.woocommerce.infiniteScroll()
            }
            SWIFT.woocommerce.mobileShopFilters();
            if (!jQuery(".quantity").hasClass("mnm-quantity")) {
                SWIFT.woocommerce.productQuantityAdjust()
            }
            SWIFT.woocommerce.smallProductCheck();
            ag.smartresize(function () {
                SWIFT.woocommerce.smallProductCheck()
            });
            if (jQuery(".product-type-preview-slider").length > 0) {
                SWIFT.woocommerce.previewSliderLayout()
            }
            jQuery(".jckqvBtn").attr("data-toggle", "tooltip").attr("data-original-title", j.data("quickview-text"));
            jQuery(document).on("change", "form.cart input.qty", function () {
                jQuery(this.form).find("button[data-quantity]").attr("data-quantity", this.value)
            });
            jQuery(document).on("click", ".add_to_cart_button, .single_add_to_cart_button", function () {
                var ar = jQuery(this), ap = ar.parent(), aq = ar.attr("data-loading_text"), ao = ap.data("tooltip-added-text");
                if (ar.hasClass("disabled")) {
                    return
                }
                ar.addClass("added-spinner");
                ar.find("span").text(aq);
                ar.find("i").attr("class", "sf-icon-loader");
                if (!ap.hasClass("cart") && !ap.hasClass("add-to-cart-shortcode")) {
                    setTimeout(function () {
                        ap.tooltip("hide").attr("title", ao).tooltip("fixTitle")
                    }, 500);
                    setTimeout(function () {
                        ap.tooltip("show")
                    }, 700)
                }
            });
            jQuery("body").bind("added_to_cart", function () {
                var ap = jQuery(".shopping-bag-item:visible:last"), av = ap.find(".cart-contents"), au = jQuery(".added-spinner"), ao, at, aq, ar = "", aw = "";
                au.addClass("product-added");
                if (D.hasClass("single-product") || au.parents("#jckqv").length > 0) {
                    ao = jQuery(".add_to_cart_button, .single_add_to_cart_button");
                    at = ao.data("added_text");
                    ao.find("span").text(at)
                }
                if (au.parents("li.product").length > 0) {
                    ao = au;
                    at = ao.data("added_short");
                    ao.find("span").text(at)
                }
                if (au.parents(".add-to-cart-shortcode").length > 0) {
                    ao = au;
                    at = ao.data("added_text");
                    ao.find("span").text(at)
                }
                ap.addClass("added-notification");
                av.addClass("sf-animate " + h);
                au.find("i").attr("class", "sf-icon-tick");
                au.removeClass("added-spinner");
                setTimeout(function () {
                    ap.find("ul.sub-menu").fadeIn(200)
                }, 800);
                setTimeout(function () {
                    if (D.hasClass("single-product") || au.parents("#jckqv").length > 0) {
                        ao = jQuery(".add_to_cart_button, .single_add_to_cart_button");
                        ar = ao.data("default_text");
                        aw = ao.data("default_icon");
                        aq = ao.parent();
                        au.find("i").attr("class", aw);
                        ao.find("span").text(ar);
                        ao.removeClass("added product-added")
                    }
                    if (au.parents(".add-to-cart-shortcode").length > 0) {
                        ao = au;
                        aq = ao.parent();
                        ar = ao.data("default_text");
                        aw = ao.data("default_icon");
                        au.find("i").attr("class", aw);
                        ao.find("span").text(ar);
                        ao.removeClass("added product-added")
                    }
                }, 3000);
                setTimeout(function () {
                    ap.removeClass("added-notification");
                    av.removeClass("sf-animate " + h);
                    if (!al) {
                        ap.find("ul.sub-menu").fadeOut(150)
                    }
                }, 4000)
            });
            jQuery(document).on("click", ".add_to_wishlist", function () {
                jQuery(this).parent().parent().find(".yith-wcwl-wishlistaddedbrowse").show().removeClass("hide").addClass("show");
                jQuery(this).hide().addClass("hide").removeClass("show");
                var ap = {action: "sf_add_to_wishlist", product_id: jQuery(this).attr("data-product-id")};
                var ao = jQuery(this).attr("data-ajaxurl");
                jQuery.post(ao, ap, function (aq) {
                    var at = jQuery.parseJSON(aq);
                    jQuery(".cart-wishlist .wishlist-item .bag-contents").prepend(at.wishlist_output);
                    jQuery(".wishlist-empty").remove();
                    jQuery(".bag-buttons").removeClass("no-items");
                    var ar = jQuery(".wishlist-item:visible:last"), au = ar.find(".wishlist-link");
                    ar.addClass("added-notification");
                    au.addClass("sf-animate " + h);
                    setTimeout(function () {
                        ar.find("ul.sub-menu").fadeIn(200)
                    }, 800);
                    setTimeout(function () {
                        ar.removeClass("added-notification");
                        au.removeClass("sf-animate " + h);
                        if (!E) {
                            ar.find("ul.sub-menu").fadeOut(150)
                        }
                    }, 4000)
                })
            });
            jQuery(".show-products-link").on("click", function (aq) {
                aq.preventDefault();
                var ap = jQuery(this).attr("href").replace("?", ""), ar = document.location.href.replace(/\/page\/\d+/, ""), ao = document.location.search;
                if (ao.indexOf("?show") >= 0) {
                    window.location = jQuery(this).attr("href")
                } else {
                    if (ao.indexOf("?") >= 0) {
                        window.location = ar + "&" + ap
                    } else {
                        window.location = ar + "?" + ap
                    }
                }
            });
            jQuery(".shipping-calculator-form input").keypress(function (ao) {
                if (ao.which == 10 || ao.which == 13) {
                    jQuery(".update-totals-button button").click()
                }
            });
            if (jQuery(".product-grid").length > 0) {
                if (!jQuery(".inner-page-wrap").hasClass("full-width-shop")) {
                    var an = jQuery(".product-grid");
                    an.each(function () {
                        if (an.parent(".upsells").length > 0) {
                            return
                        }
                        SWIFT.woocommerce.productGridSetup(jQuery(this))
                    })
                }
            }
            if (jQuery(".products.multi-masonry-items").length > 0) {
                jQuery(".products.multi-masonry-items").each(function () {
                    SWIFT.woocommerce.multiMasonrySetup(jQuery(this))
                });
                ag.smartresize(function () {
                    SWIFT.woocommerce.windowResized()
                })
            }
            jQuery(".product-categories li span.count, .widget_layered_nav li span.count").each(function () {
                var ao = jQuery(this), ap = ao.text();
                ao.text(ap.replace("(", "").replace(")", ""));
                ao.addClass("show-count")
            });
            jQuery(".upsell-heading-link").on("click", "", function (ao) {
                var ap = jQuery(this);
                jQuery(".upsells > .products").slideToggle();
                if (ap.hasClass("upsell-open")) {
                    ap.find("i").removeClass("sf-icon-minus").addClass("sf-icon-plus");
                    ap.removeClass("upsell-open")
                } else {
                    ap.find("i").removeClass("sf-icon-plus").addClass("sf-icon-minus");
                    ap.addClass("upsell-open")
                }
                ao.preventDefault()
            });
            if (jQuery("ul.wcml_currency_switcher").length > 0) {
                jQuery("ul.wcml_currency_switcher").addClass("sub-menu")
            }
        }, load: function () {
            if (jQuery(".woocommerce-shop-page").hasClass("full-width-shop") && !(u && u < 9) && !jQuery("#products").hasClass("multi-masonry-items")) {
                SWIFT.woocommerce.fullWidthShop()
            }
            SWIFT.woocommerce.variations();
            SWIFT.woocommerce.swatches()
        }, cartWishlist: function () {
            jQuery(document).on("click", ".shopping-bag .remove-product", function (at) {
                at.preventDefault();
                at.stopPropagation();
                var av = jQuery(this).attr("data-product-id"), ar = jQuery(this).attr("data-variation-id"), aw = jQuery(this).attr("data-product-qty"), ap = jQuery(".shopping-bag").attr("data-empty-bag-txt"), au = jQuery(".shopping-bag").attr("data-singular-item-txt"), aq = jQuery(".shopping-bag").attr("data-multiple-item-txt"), ao = {
                    action: "sf_cart_product_remove",
                    product_id: av,
                    variation_id: ar
                }, an = jQuery(this).attr("data-ajaxurl");
                jQuery(".shopping-bag .loading-overlay").fadeIn(200);
                jQuery.post(an, ao, function (ay) {
                    var az = ay;
                    var ax = 0;
                    if (D.hasClass("woocommerce-checkout")) {
                        jQuery(".shopping-bag").find(".bag-button")[0].click()
                    }
                    if (D.hasClass("woocommerce-cart")) {
                        location.reload()
                    }
                    jQuery(".shopping-bag .loading-overlay").fadeOut(100);
                    ax = parseInt(jQuery(".cart-contents .num-items").first().text()) - aw;
                    jQuery(".cart-contents .amount").replaceWith(az);
                    jQuery(".bag-total .amount").replaceWith(az);
                    jQuery(".cart-contents .num-items").text(ax);
                    jQuery(".cart-contents .num-items").each(function (aA) {
                        jQuery(this).text(ax)
                    });
                    if (ar > 0) {
                        jQuery(".product-var-id-" + ar).remove()
                    } else {
                        jQuery(".product-id-" + av).remove()
                    }
                    if (ax <= 0) {
                        jQuery(".sub-menu .shopping-bag").prepend('<div class="bag-empty">' + ap + "</div>");
                        jQuery(".sub-menu .shopping-bag .bag-buttons").remove();
                        jQuery(".sub-menu .shopping-bag .bag-header").remove();
                        jQuery(".sub-menu .shopping-bag .bag-total").remove();
                        jQuery(".sub-menu .shopping-bag .bag-contents").remove()
                    } else {
                        if (ax == 1) {
                            jQuery(".sub-menu .shopping-bag .bag-header").text("1 " + au)
                        } else {
                            jQuery(".sub-menu .shopping-bag .bag-header").text(ax + " " + aq)
                        }
                    }
                    var $fragment_refresh = {
                        url: wc_cart_fragments_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'get_refreshed_fragments' ),
                        type: 'POST',
                        success: function( data ) {
                            if ( data && data.fragments ) {

                                jQuery.each( data.fragments, function( key, value ) {
                                    jQuery( key ).replaceWith( value );
                                });

                                if ( jQuery.supports_html5_storage ) {
                                    sessionStorage.setItem( wc_cart_fragments_params.fragment_name, JSON.stringify( data.fragments ) );
                                    set_cart_hash( data.cart_hash );

                                    if ( data.cart_hash ) {
                                        set_cart_creation_timestamp();
                                    }
                                }

                                jQuery( document.body ).trigger( 'wc_fragments_refreshed' );
                            }
                        }
                    };
                    jQuery.ajax( $fragment_refresh );
                });
                return false
            });

            jQuery(document).on("click", ".wbgm-gold-member-add-to-cart", function () {
                var $fragment_refresh = {
                    url: wc_cart_fragments_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'get_refreshed_fragments' ),
                    type: 'POST',
                    success: function( data ) {
                        if ( data && data.fragments ) {

                            jQuery.each( data.fragments, function( key, value ) {
                                jQuery( key ).replaceWith( value );
                            });

                            if ( jQuery.supports_html5_storage ) {
                                sessionStorage.setItem( wc_cart_fragments_params.fragment_name, JSON.stringify( data.fragments ) );
                                set_cart_hash( data.cart_hash );

                                if ( data.cart_hash ) {
                                    set_cart_creation_timestamp();
                                }
                            }

                            jQuery( document.body ).trigger( 'wc_fragments_refreshed' );
                        }
                    }
                };
                jQuery.ajax( $fragment_refresh );
            });
            jQuery(document).on("click", ".wishlist_table .remove", function () {
                jQuery(".prod-" + jQuery(this).attr("data-product-id")).remove();
                if (jQuery(".wishlist-bag").find(".bag-product").length === 0) {
                    jQuery(".bag-buttons").addClass("no-items")
                }
            })
        }, variations: function () {
            jQuery(".single_variation_wrap").on("show_variation", function () {
                if (aj) {
                    jQuery(".zoomContainer").remove();
                    setTimeout(function () {
                        if (SWIFT.productSlider) {
                            jQuery(".product-slider-image").each(function () {
                                jQuery(this).data("zoom-image", jQuery(this).parent().find("a.zoom").attr("href"))
                            });
                            var an = jQuery("#product-img-slider li:first").find(".product-slider-image");
                            SWIFT.woocommerce.productZoom(an);
                            SWIFT.productSlider.goToSlide(0)
                        }
                    }, 500)
                } else {
                    setTimeout(function () {
                        if (SWIFT.productSlider) {
                            SWIFT.productSlider.goToSlide(0)
                        }
                    }, 500)
                }
                setTimeout(function () {
                    jQuery(".product-slider-image").each(function () {
                        var an = jQuery(this).attr("src");
                        jQuery(this).parent().find("a.zoom").attr("href", an).attr("data-o_href", "").attr("data-o_href", an);
                        jQuery('[data-rel="ilightbox[product]"]').removeClass("ilightbox-enabled").iLightBox().destroy();
                        SWIFT.page.lightbox()
                    })
                }, 600)
            });
            jQuery("form.variations_form").on("wc_additional_variation_images_frontend_image_swap_callback wc_additional_variation_images_frontend_ajax_default_image_swap_callback wc_additional_variation_images_frontend_on_reset", function (aq, ao, at, an, ap, ar) {
                switch (aq.type) {
                    case"wc_additional_variation_images_frontend_image_swap_callback":
                        jQuery("#product-img-slider .slides").html(ao.gallery_images);
                        jQuery("#product-img-nav ul.slides a.zoom.lightbox").each(function () {
                            var au = jQuery(this).parent().find("img").attr("data-zoom-image");
                            jQuery(this).attr("href", au)
                        });
                        break;
                    case"wc_additional_variation_images_frontend_ajax_default_image_swap_callback":
                        jQuery("#product-img-slider .slides").html(ap);
                        break;
                    case"wc_additional_variation_images_frontend_on_reset":
                        jQuery("#product-img-slider .slides").html(ap);
                        break
                }
                SWIFT.productSlider.destroy();
                SWIFT.sliders.productSlider();
                setTimeout(function () {
                    jQuery('[data-rel="ilightbox[product]"]').removeClass("ilightbox-enabled").iLightBox().destroy();
                    SWIFT.page.lightbox()
                }, 500)
            });
            jQuery("form.variations_form").on("wc_additional_variation_images_frontend_lightbox_done", function () {
                setTimeout(function () {
                    jQuery('[data-rel="ilightbox[product]"]').removeClass("ilightbox-enabled").iLightBox().destroy();
                    SWIFT.page.lightbox()
                }, 500)
            });
            jQuery(document).on("reset_image", function () {
                setTimeout(function () {
                    if (aj) {
                        jQuery(".zoomContainer").remove();
                        if (SWIFT.productSlider) {
                            SWIFT.productSlider.goToSlide(0);
                            var an = jQuery("#product-img-slider li:first").find(".product-slider-image");
                            an.attr("data-zoom-image", an.parent().attr("data-thumb"));
                            an.data("zoom-image", an.parent().attr("data-thumb"));
                            setTimeout(function () {
                                SWIFT.woocommerce.productZoom(an)
                            }, 200)
                        }
                    } else {
                        if (SWIFT.productSlider) {
                            SWIFT.productSlider.goToSlide(0)
                        }
                    }
                }, 500)
            })
        }, swatches: function () {
            jQuery(document).on("change", "div.select", function () {
                if (aj) {
                    jQuery(".zoomContainer").remove();
                    setTimeout(function () {
                        if (SWIFT.productSlider) {
                            jQuery(".product-slider-image").each(function () {
                                jQuery(this).data("zoom-image", jQuery(this).parent().find("a.zoom").attr("href"))
                            });
                            var an = jQuery("#product-img-slider li:first").find(".product-slider-image");
                            SWIFT.woocommerce.productZoom(an);
                            SWIFT.productSlider.goToSlide(0)
                        }
                    }, 500)
                } else {
                    setTimeout(function () {
                        if (SWIFT.productSlider) {
                            SWIFT.productSlider.goToSlide(0)
                        }
                    }, 500)
                }
            })
        }, productZoom: function (an) {
            jQuery("#product-img-slider li a.zoom").css("display", "none");
            jQuery(".zoomContainer").remove();
            an.elevateZoom({
                zoomType: b,
                cursor: "crosshair",
                zoomParent: "#product-img-slider .lSSlideWrapper",
                responsive: true,
                zoomWindowFadeIn: 400,
                zoomWindowFadeOut: 500,
                lensSize: 350
            });
            ag.smartresize(function () {
                jQuery(".zoomContainer").remove();
                an.elevateZoom({
                    zoomType: b,
                    cursor: "crosshair",
                    zoomParent: "#product-img-slider .lSSlideWrapper",
                    responsive: true,
                    zoomWindowFadeIn: 400,
                    zoomWindowFadeOut: 500,
                    lensSize: 350
                })
            })
        }, shopLayoutSwitch: function () {
            var an = false;
            jQuery(document).on("click", "a.layout-opt", function (ar) {
                var aq = jQuery("#products"), ao = jQuery(this).data("layout"), at = aq.find(".product").first().data("width"), ap = jQuery(".inner-page-wrap").hasClass("has-no-sidebar") ? "col-sm-sf-5" : "col-sm-3";
                if (jQuery(this).parent().data("display-type") == "gallery" || jQuery(this).parent().data("display-type") == "gallery-bordered") {
                    ap = "col-sm-2"
                }
                if (an) {
                    return
                }
                an = true;
                aq.animate({opacity: 0}, 400);
                setTimeout(function () {
                    aq.find(".product").removeClass("product-layout-standard product-layout-list product-layout-grid product-layout-solo");
                    aq.find(".product").addClass("product-layout-" + ao);
                    if (jQuery(".product-grid").length > 0) {
                        jQuery(".product-grid").children().css("min-height", "0");
                        if (ao === "grid") {
                            aq.find(".product").removeClass(at).addClass(ap)
                        }
                        if (ao === "standard" || ao === "solo") {
                            aq.find(".product").removeClass(ap).addClass(at)
                        }
                        if (ao !== "list" && ao !== "solo") {
                            jQuery(".product-grid").equalHeights()
                        }
                    }
                    aq.isotope("layout");
                    aq.animate({opacity: 1}, 400);
                    an = false
                }, 500);
                ar.preventDefault()
            })
        }, mobileShopFilters: function () {
            jQuery(document).on("click", ".sf-mobile-shop-filters-link", function (ao) {
                ao.preventDefault();
                var an = jQuery(this);
                if (an.hasClass("filters-open")) {
                    jQuery(".sf-mobile-shop-filters").slideUp(400);
                    an.removeClass("filters-open")
                } else {
                    jQuery(".sf-mobile-shop-filters").slideDown(600);
                    an.addClass("filters-open")
                }
            })
        }, fullWidthShop: function () {
            var ap = jQuery(".full-width-shop").find(".products"), ao = ap.find("li.product").first().data("width"), an = ap.find(".sidebar");
            if (an.length > 0) {
                SWIFT.woocommerce.fullWidthShopSetSidebarHeight();
                ag.smartresize(function () {
                    SWIFT.woocommerce.fullWidthShopSetSidebarHeight()
                });
                ap.isotope({
                    itemSelector: ".product",
                    layoutMode: "fitRows",
                    masonry: {columnWidth: "." + ao},
                    isOriginLeft: !W
                });
                SWIFT.woocommerce.animateItems(ap);
                an.stop().animate({opacity: 1}, 500);
                ap.isotope("stamp", an);
                ap.isotope("layout");
                setTimeout(function () {
                    ap.isotope("layout")
                }, 500)
            } else {
                ap.isotope({itemSelector: ".product", layoutMode: "fitRows", isOriginLeft: !W});
                setTimeout(function () {
                    ap.isotope("layout")
                }, 500);
                SWIFT.woocommerce.animateItems(ap)
            }
        }, fullWidthShopSetSidebarHeight: function () {
            var ar = jQuery(".full-width-shop").find(".products"), ao = ar.find("div.sidebar"), aq = ao.css("height", "").outerHeight(), at = 0, ap = 2, an = ar.find("li.product").first().outerHeight(true);
            ap = Math.ceil(aq / an);
            at = an * ap;
            ao.css("height", at)
        }, productGridSetup: function (an) {
            an.imagesLoaded(function () {
                an.isotope({resizable: false, itemSelector: ".product", layoutMode: "fitRows", isOriginLeft: !W})
            });
            an.appear(function () {
                if (N) {
                    setTimeout(function () {
                        an.isotope("layout");
                        SWIFT.woocommerce.animateItems(an)
                    }, 500)
                } else {
                    SWIFT.woocommerce.animateItems(an)
                }
            })
        }, multiMasonrySetup: function (an) {
            if (N) {
                an.appear(function () {
                    SWIFT.woocommerce.animateItems(an)
                });
                return
            }
            an.imagesLoaded(function () {
                SWIFT.woocommerce.multiMasonrySizeFix(an, false);
                an.isotope({
                    resizable: false,
                    itemSelector: ".product",
                    layoutMode: "packery",
                    packery: {columnWidth: ".grid-sizer"},
                    isOriginLeft: !W
                });
                if (N) {
                    setTimeout(function () {
                        an.isotope("layout")
                    }, 500)
                }
            });
            an.appear(function () {
                SWIFT.woocommerce.animateItems(an)
            })
        }, multiMasonrySizeFix: function (ao, ap) {
            var at = ao.find(".product.size-standard").first(), aq = at.height(), an = 0;
            if (aq > 0) {
                an = (aq * 2) + parseInt(at.css("margin-bottom"), 10)
            } else {
                var ar = ao.find(".product.size-large,.product.size-tall").first();
                an = ar.height()
            }
            if (an > 0) {
                ao.find(".product.size-large .multi-masonry-img-wrap").css("height", an);
                ao.find(".product.size-tall .multi-masonry-img-wrap").css("height", an)
            }
            if (ap) {
                ao.isotope("layout")
            }
        }, windowResized: function () {
            jQuery(".products.multi-masonry-items").each(function () {
                SWIFT.woocommerce.multiMasonrySizeFix(jQuery(this), true)
            })
        }, animateItems: function (an) {
            an.find(".product").each(function (ao) {
                jQuery(this).delay(ao * 200).animate({opacity: 1}, 800, "easeOutExpo", function () {
                    jQuery(this).addClass("item-animated")
                })
            })
        }, productQuantityAdjust: function () {
            jQuery(document).on("click", ".qty-plus", function (ar) {
                ar.preventDefault();
                var an = jQuery(this).parents(".quantity").find("input.qty"), ao = parseInt(an.attr("step"), 10), aq = parseInt(an.val(), 10) + ao, ap = parseInt(an.attr("max"), 10);
                if (!ap) {
                    ap = 9999999999
                }
                if (aq <= ap) {
                    an.val(aq);
                    an.change()
                }
            });
            jQuery(document).on("click", ".qty-minus", function (ar) {
                ar.preventDefault();
                var an = jQuery(this).parents(".quantity").find("input.qty"), ao = parseInt(an.attr("step"), 10), aq = parseInt(an.val(), 10) - ao, ap = parseInt(an.attr("min"), 10);
                if (!ap) {
                    ap = 0
                }
                if (aq >= ap) {
                    an.val(aq);
                    an.change()
                }
            })
        }, smallProductCheck: function () {
            jQuery(".product").each(function () {
                var an = jQuery(this);
                if (an.width() < 220) {
                    an.addClass("mini-view")
                }
            })
        }, previewSliderLayout: function () {
            var an = jQuery(".product-type-preview-slider > .products, .products.product-type-preview-slider").children(".product");
            an.each(function () {
                var ao = jQuery(this), ap = SWIFT.woocommerce.pslCreateDots(ao);
                if (!ao.find(".variable-image-wrapper").hasClass("is-variable")) {
                    return
                }
                SWIFT.woocommerce.pslUpdatePrice(ao, 0);
                if (ap) {
                    ap.on("click", function () {
                        var at = jQuery(this);
                        if (!at.hasClass("selected")) {
                            var ar = at.index(), aq = ao.find(".variable-image-wrapper .selected").index();
                            if (aq < ar) {
                                SWIFT.woocommerce.pslNextSlide(ao, ap, ar)
                            } else {
                                SWIFT.woocommerce.pslPrevSlide(ao, ap, ar)
                            }
                            SWIFT.woocommerce.pslUpdatePrice(ao, ar)
                        }
                    })
                }
                ao.find(".variable-image-wrapper").swipe({
                    swipeLeft: function () {
                        var ar = jQuery(this), aq = 0;
                        if (!ar.find(".selected").is(":last-child")) {
                            aq = ao.find(".variable-image-wrapper .selected").index() + 1;
                            SWIFT.woocommerce.pslNextSlide(ao, ap);
                            SWIFT.woocommerce.pslUpdatePrice(ao, aq)
                        }
                    }, swipeRight: function () {
                        var ar = jQuery(this), aq = 0;
                        if (!ar.find(".selected").is(":first-child")) {
                            aq = ao.find(".variable-image-wrapper .selected").index() - 1;
                            SWIFT.woocommerce.pslPrevSlide(ao, ap);
                            SWIFT.woocommerce.pslUpdatePrice(ao, aq)
                        }
                    },
                });
                ao.on("mouseover", ".move-right, .move-left", function (aq) {
                    SWIFT.woocommerce.pslHoverItem(jQuery(this), true)
                });
                ao.on("mouseleave", ".move-right, .move-left", function (aq) {
                    SWIFT.woocommerce.pslHoverItem(jQuery(this), false)
                });
                ao.on("click", ".move-right, .move-left", function (ar) {
                    ar.preventDefault();
                    var aq = 0;
                    if (jQuery(this).hasClass("move-right")) {
                        aq = ao.find(".variable-image-wrapper .selected").index() + 1;
                        SWIFT.woocommerce.pslNextSlide(ao, ap)
                    } else {
                        aq = ao.find(".variable-image-wrapper .selected").index() - 1;
                        SWIFT.woocommerce.pslPrevSlide(ao, ap)
                    }
                    SWIFT.woocommerce.pslUpdatePrice(ao, aq)
                })
            })
        }, pslCreateDots: function (ao) {
            if (ao.find(".variable-image-wrapper .img-wrap").length <= 1) {
                return false
            }
            var an = jQuery('<ol class="preview-slider-dots"></ol>').insertAfter(ao.find(".variable-image-wrapper"));
            ao.find(".variable-image-wrapper .img-wrap").each(function (aq) {
                var ar = (aq === 0) ? jQuery('<li class="selected"></li>') : jQuery("<li></li>"), ap = jQuery('<a href="#0"></a>').appendTo(ar);
                ar.appendTo(an);
                ap.text(aq + 1)
            });
            return an.children("li")
        }, pslHoverItem: function (ao, an) {
            if (ao.hasClass("move-right")) {
                ao.toggleClass("hover", an).siblings(".selected, .move-left").toggleClass("focus-on-right", an)
            } else {
                ao.toggleClass("hover", an).siblings(".selected, .move-right").toggleClass("focus-on-left", an)
            }
        }, pslNextSlide: function (ao, ar, aq) {
            var ap = ao.find(".variable-image-wrapper .selected"), an = ao.find(".preview-slider-dots .selected");
            if (typeof aq === "undefined") {
                aq = ap.index() + 1
            }
            ap.removeClass("selected");
            ao.find(".variable-image-wrapper .img-wrap").eq(aq).addClass("selected").removeClass("move-right hover").prevAll().removeClass("move-right move-left focus-on-right").addClass("hide-left").end().prev().removeClass("hide-left").addClass("move-left").end().next().addClass("move-right");
            an.removeClass("selected");
            ar.eq(aq).addClass("selected")
        }, pslPrevSlide: function (ao, ar, aq) {
            var ap = ao.find(".variable-image-wrapper .selected"), an = ao.find(".preview-slider-dots .selected");
            if (typeof aq === "undefined") {
                aq = ap.index() - 1
            }
            ap.removeClass("selected focus-on-left");
            ao.find(".variable-image-wrapper .img-wrap").eq(aq).addClass("selected").removeClass("move-left hide-left hover").nextAll().removeClass("hide-left move-right move-left focus-on-left").end().next().addClass("move-right").end().prev().removeClass("hide-left").addClass("move-left");
            an.removeClass("selected");
            ar.eq(aq).addClass("selected")
        }, pslUpdatePrice: function (an, au) {
            var aq = an.find(".product-details"), ao = aq.find("span.price"), at = an.find(".variable-image-wrapper .img-wrap").eq(au), ar = at.find(".variation-price").html(), ap = at.data("sale");
            if (!ar || ao.html() === at.find(".variation-price span.price").html()) {
                return
            }
            if (ap) {
                aq.addClass("on-sale");
                ao.replaceWith(ar);
                setTimeout(function () {
                    aq.addClass("is-visible")
                }, 100)
            } else {
                aq.removeClass("on-sale is-visible");
                ao.fadeOut(function () {
                    ao.replaceWith(ar)
                }).fadeIn()
            }
        }, infiniteScroll: function () {
            if (!(u && u < 9)) {
                var ao = jQuery("#inf-scroll-params"), aq = jQuery(".products"), ap = aq.parents(".page-content").find(".pagination-wrap").hasClass("load-more") ? true : false;
                if (!aq.parents(".page-content").find(".pagination-wrap").hasClass("infinite-scroll-enabled")) {
                    return
                }
                var an = {
                    loading: {
                        img: ao.data("loadingimage"),
                        msgText: ap ? ao.data("msgtext") : "",
                        finishedMsg: ap ? ao.data("finishedmsg") : "",
                        selector: ".woocommerce-shop-page .page-content",
                        loaderHTML: jQuery("body > .sf-svg-loader").html()
                    },
                    nextSelector: ".pagenavi li:last-child a",
                    navSelector: ".pagination-wrap",
                    itemSelector: ".product",
                    contentSelector: "#products",
                    errorCallback: function () {
                        setTimeout(function () {
                            jQuery("#infscr-loading").animate({opacity: 0}, 500)
                        }, 1000)
                    },
                };
                jQuery(an.contentSelector).infinitescroll(an, function (ar) {
                    aq.imagesLoaded(function () {
                        aq.isotope("appended", ar);
                        jQuery.each(ar, function (au, at) {
                            jQuery(at).addClass("item-animated")
                        })
                    });
                    if (ap) {
                        setTimeout(function () {
                            jQuery(".load-more-btn").css("display", "block")
                        }, 200)
                    }
                });
                if (ap) {
                    aq.parent().addClass("products-load-more-pagination");
                    ag.unbind(".infscr");
                    jQuery(".load-more-btn").on("click", function (ar) {
                        ar.preventDefault();
                        jQuery(an.contentSelector).infinitescroll("retrieve");
                        jQuery(".load-more-btn").css("display", "none");
                        ag.trigger("resize")
                    })
                }
            } else {
                jQuery(".pagination-wrap").removeClass("hidden")
            }
        }
    };
    SWIFT.edd = {
        init: function () {
            var ao = jQuery(".edd-cart-contents .cart-total"), an = jQuery(".edd-cart-contents .num-items");
            D.on("edd_cart_item_added", function (ar, aq) {
                ao.html(aq.subtotal);
                an.html(aq.cart_quantity);
                jQuery(".edd-cart").find(".empty").removeClass("force-hide force-show");
                var ap = jQuery(".edd-shopping-bag-item:visible:last"), at = ap.find(".edd-cart-contents");
                ap.addClass("added-notification");
                at.addClass("sf-animate " + h);
                setTimeout(function () {
                    ap.find("ul.sub-menu").fadeIn(200)
                }, 800);
                setTimeout(function () {
                    ap.removeClass("added-notification");
                    at.removeClass("sf-animate " + h);
                    if (!al) {
                        ap.find("ul.sub-menu").fadeOut(150)
                    }
                }, 4000)
            });
            D.on("edd_cart_item_removed", function (aq, ap) {
                ao.html(ap.subtotal);
                an.html(ap.cart_quantity);
                if (ap.cart_quantity === "0") {
                    jQuery(".edd-cart").find(".empty").first().addClass("force-show");
                    jQuery(".edd-cart").find(".empty").last().addClass("force-hide")
                }
            })
        }
    };
    SWIFT.sliders = {
        init: function () {
            if (jQuery("#product-img-slider").length > 0) {
                SWIFT.sliders.productSlider()
            }
            if (jQuery(".item-slider").length > 0) {
                SWIFT.sliders.itemSlider()
            }
            if (jQuery(".content-slider").length > 0) {
                SWIFT.sliders.contentSlider()
            }
        }, itemSlider: function () {
            jQuery(".item-slider > ul").lightSlider({
                item: 1,
                pager: true,
                controls: true,
                slideMargin: 0,
                adaptiveHeight: true,
                loop: true,
                rtl: W,
                auto: y,
                pause: ad,
                speed: T
            })
        }, contentSlider: function () {
            jQuery(".content-slider > ul").each(function () {
                var ao = jQuery(this), aq = ((ao.parent().attr("data-autoplay") === "yes") ? true : false), ap;
                var an = ao.lightSlider({
                    mode: "fade",
                    item: 1,
                    pager: true,
                    controls: false,
                    slideMargin: 0,
                    adaptiveHeight: true,
                    loop: true,
                    rtl: W,
                    auto: aq,
                    pause: ad,
                    speed: T,
                    onSliderLoad: function () {
                        an.removeClass("cS-hidden")
                    }
                });
                ao.parent().on("mouseenter", function () {
                    if (aq) {
                        an.pause();
                        clearTimeout(ap)
                    }
                });
                ao.parent().on("mouseleave", function () {
                    if (aq) {
                        ap = setTimeout(function () {
                            an.play()
                        }, ad)
                    }
                })
            })
        }, productSlider: function () {
            var ap = jQuery("#product-img-slider > ul > li").length > 1 ? true : false, aq = false, an = parseInt(af, 10), ao = 4, ar = 3;
            if (I || ag.width() <= 768) {
                e = "bottom"
            }
            if (e === "left") {
                aq = true;
                ao = Math.floor(an / 120);
                ar = 3
            }
            SWIFT.productSlider = jQuery("#product-img-slider > ul").lightSlider({
                item: 1,
                gallery: ap,
                autoWidth: false,
                slideMargin: 0,
                speed: 400,
                auto: false,
                loop: false,
                vThumbWidth: 70,
                vertical: aq,
                verticalHeight: an,
                pause: 2000,
                keyPress: true,
                controls: true,
                rtl: W,
                adaptiveHeight: true,
                thumbItem: ao,
                thumbMargin: 30,
                freeMove: false,
                currentPagerPosition: "middle",
                swipeThreshold: 40,
                responsive: [{breakpoint: 768, settings: {verticalHeight: (an / 2), thumbItem: ar,}}],
                onSliderLoad: function (at) {
                    at.addClass("slider-loaded");
                    at.parents("#product-img-slider").find(".lSPager").addClass("thumbnails");
                    if (aj) {
                        var au = jQuery("#product-img-slider").find(".lslide.active > .product-slider-image");
                        SWIFT.woocommerce.productZoom(au)
                    }
                    at.find(".product-slider-image").each(function () {
                        var av = (this.width / this.height >= 1) ? "wide" : "tall";
                        jQuery(this).addClass(av)
                    })
                },
                onBeforeSlide: function (at) {
                    if (aj) {
                        jQuery(".zoomContainer").remove()
                    }
                },
                onAfterSlide: function (at) {
                    if (aj) {
                        if (SWIFT.variationsReset) {
                            return
                        }
                        var au = jQuery("#product-img-slider").find(".lslide.active > .product-slider-image");
                        SWIFT.woocommerce.productZoom(au)
                    }
                }
            })
        }, thumb: function () {
            jQuery(".thumb-slider > ul").lightSlider({
                item: 1,
                pager: false,
                controls: true,
                slideMargin: 0,
                loop: true,
                adaptiveHeight: true,
                rtl: W,
                auto: y,
                pause: ad,
                speed: T
            })
        }
    };
    var x = jQuery(".portfolio-wrap").find(".filterable-items");
    SWIFT.portfolio = {
        init: function () {
            x.each(function () {
                var an = jQuery(this);
                if (an.hasClass("masonry-items") && !(u && u < 9)) {
                    SWIFT.portfolio.masonrySetup(an)
                } else {
                    if (an.hasClass("multi-masonry-items") && !(u && u < 9)) {
                        SWIFT.portfolio.multiMasonrySetup(an)
                    } else {
                        SWIFT.portfolio.standardSetup(an)
                    }
                }
            });
            ag.smartresize(function () {
                SWIFT.portfolio.windowResized()
            });
            jQuery(".portfolio-wrap .filtering li").each(function () {
                var ao = jQuery(this), an = jQuery(this).find("a").attr("class"), aq = jQuery(this).parents(".portfolio-wrap").find(".filterable-items"), ap = 0;
                aq.find(".portfolio-item").each(function () {
                    if (jQuery(this).hasClass(an)) {
                        ao.addClass("has-items");
                        ap++
                    }
                });
                if (ao.find("sup.count").length > 0) {
                    ao.find("sup.count").text(ap)
                } else {
                    ao.find("a").append('<sup class="count">' + ap + "</sup>")
                }
            }).parents(".filtering").animate({opacity: 1}, 400);
            jQuery(".portfolio-wrap .filtering li").on("click", "a", function (ap) {
                ap.preventDefault();
                jQuery(this).parent().parent().find("li").removeClass("selected");
                jQuery(this).parent().addClass("selected");
                var an = jQuery(this).data("filter");
                var ao = jQuery(this).parents(".portfolio-wrap").find(".filterable-items");
                ao.isotope({filter: an})
            });
            jQuery(".filter-wrap > a").on("click", function (an) {
                an.preventDefault();
                jQuery(this).parent().find(".filter-slide-wrap").slideToggle()
            })
        }, standardSetup: function (an) {
            an.imagesLoaded(function () {
                SWIFT.sliders.thumb();
                an.animate({opacity: 1}, 800);
                an.isotope({resizable: true, layoutMode: "fitRows", isOriginLeft: !W});
                setTimeout(function () {
                    SWIFT.portfolio.setItemHeight();
                    ag.trigger("resize");
                    an.isotope("layout")
                }, 500)
            });
            an.appear(function () {
                SWIFT.portfolio.animateItems(an)
            })
        }, masonrySetup: function (an) {
            an.imagesLoaded(function () {
                SWIFT.sliders.thumb();
                an.isotope({
                    resizable: false,
                    itemSelector: ".portfolio-item",
                    layoutMode: "masonry",
                    isOriginLeft: !W
                });
                setTimeout(function () {
                    an.isotope("layout")
                }, 500)
            });
            an.appear(function () {
                SWIFT.portfolio.animateItems(an)
            })
        }, multiMasonrySetup: function (an) {
            an.imagesLoaded(function () {
                SWIFT.sliders.thumb();
                SWIFT.portfolio.multiMasonrySizeFix(false);
                var ao = an.isotope({
                    resizable: false,
                    itemSelector: ".portfolio-item",
                    layoutMode: "packery",
                    packery: {columnWidth: ".grid-sizer"},
                    isOriginLeft: !W
                });
                setTimeout(function () {
                    an.isotope("layout")
                }, 500);
                ao.on("layoutComplete", function () {
                    ag.trigger("resize")
                })
            });
            an.appear(function () {
                SWIFT.portfolio.animateItems(an)
            })
        }, animateItems: function (an) {
            an.find(".portfolio-item").each(function (ao) {
                jQuery(this).delay(ao * 200).animate({opacity: 1}, 800, "easeOutExpo", function () {
                    jQuery(this).addClass("item-animated")
                })
            })
        }, setItemHeight: function () {
            if (!x.hasClass("col-1") && !x.hasClass("masonry-items") && !x.hasClass("multi-masonry-items")) {
                x.children().css("min-height", "0");
                x.equalHeights()
            }
        }, multiMasonrySizeFix: function (ap) {
            var au = x.find(".portfolio-item.size-standard").first(), aq = au.height(), an = 0;
            if (aq > 0) {
                an = (aq * 2) + parseInt(au.css("margin-bottom"), 10)
            } else {
                var at = x.find(".portfolio-item.size-tall,.portfolio-item.size-wide-tall").first();
                an = at.height();
                aq = (an / 2) - parseInt(au.css("margin-bottom"), 10)
            }
            if (an > 0) {
                x.find(".portfolio-item.size-wide .multi-masonry-img-wrap").css("height", aq);
                x.find(".portfolio-item.size-wide-tall .multi-masonry-img-wrap").css("height", an);
                x.find(".portfolio-item.size-tall .multi-masonry-img-wrap").css("height", an);
                var ar = (x.find(".portfolio-item.size-wide-tall ul.slides > li").first().height() - an) / 2;
                x.find(".portfolio-item.size-wide-tall ul.slides").css("max-height", an);
                x.find(".portfolio-item.size-wide-tall ul.slides > li").css("margin-top", -ar);
                var ao = (x.find(".portfolio-item.size-wide ul.slides > li").first().height() - aq) / 2;
                x.find(".portfolio-item.size-wide ul.slides").css("max-height", aq);
                x.find(".portfolio-item.size-wide ul.slides > li").css("margin-top", -ao)
            }
            if (ap) {
                x.isotope("layout")
            }
        }, windowResized: function () {
            if (!x.hasClass("col-1") && !x.hasClass("masonry-items") && !x.hasClass("multi-masonry-items")) {
                SWIFT.portfolio.setItemHeight()
            }
            if (x.hasClass("multi-masonry-items")) {
                SWIFT.portfolio.multiMasonrySizeFix(true)
            }
        }, portfolioShowcaseInit: function () {
            SWIFT.sliders.thumb();
            SWIFT.portfolio.portfolioShowcaseWrap();
            SWIFT.portfolio.portfolioShowcaseItems();
            ag.smartresize(function () {
                SWIFT.portfolio.portfolioShowcaseWrap();
                SWIFT.portfolio.portfolioShowcaseItems()
            })
        }, portfolioShowcaseWrap: function () {
            var an = jQuery(".portfolio-showcase-wrap");
            an.animate({opacity: 1}, 600)
        }, portfolioShowcaseItems: function () {
            jQuery(".portfolio-showcase-wrap").each(function () {
                var az = jQuery("#main-container").width();
                if (jQuery("#container").hasClass("boxed-layout")) {
                    az = jQuery("#container").width()
                }
                var av = jQuery(this), au = av.find(".portfolio-showcase-items").data("columns"), ao = az + 2, aw = Math.floor(ao / au), aq = Math.floor(ao * 40 / 100), ax = Math.floor(ao / 5), ap = (aw / 2 - aq / 2) / 0.75, ay = (ax / 2 - aq / 2) / 1.3, an = !1, ar = 300;
                var at = av.find("li.portfolio-item");
                if (au === 5) {
                    aq = Math.floor(ao * 25 / 100);
                    ax = Math.floor(ao / 5.33);
                    ap = (aw / 2 - aq / 2) / 0.75;
                    ay = (ax / 2 - aq / 2) / 1.3;
                    at.css("width", aw);
                    at.css("height", aq / 1.5);
                    at.find(".main-image").css("width", aq);
                    at.find(".main-image").css("left", ay);
                    at.find(".main-image").css("top", -aq / 6);
                    ar = 200
                } else {
                    at.css("width", aw);
                    at.css("height", aq / 2);
                    at.find(".main-image").css("width", aq);
                    at.find(".main-image").css("left", ay)
                }
                at.each(function () {
                    if (ao > 768) {
                        jQuery(this).mouseenter(function () {
                            if (!an) {
                                an = !0;
                                jQuery(this).removeClass("deselected-item");
                                av.find(".deselected-item").stop().animate({width: ax}, ar);
                                av.find(".deselected-item").find(".main-image").stop().animate({left: ap}, ar);
                                jQuery(this).find(".main-image").stop().animate({left: 0}, ar);
                                jQuery(this).stop().animate({width: aq}, ar + 1, function () {
                                    jQuery(this).find(".item-info").stop().show();
                                    jQuery(this).find(".item-info").stop().animate({bottom: 0}, ar, "easeInOutQuart")
                                })
                            }
                        });
                        jQuery(this).mouseleave(function () {
                            if (an) {
                                an = !1;
                                jQuery(this).addClass("deselected-item");
                                av.find(".portfolio-item").stop().animate({width: aw}, ar);
                                av.find(".portfolio-item .main-image").stop().animate({left: ay}, ar);
                                jQuery(this).find(".item-info").stop().animate({bottom: -85}, ar, function () {
                                    jQuery(this).find(".item-info").stop().hide()
                                })
                            }
                        })
                    }
                })
            })
        }, stickyDetails: function () {
            var an = 0;
            if (jQuery(".sticky-header").length > 0) {
                an = jQuery(".sticky-header").height() > 0 ? jQuery(".sticky-header").height() : jQuery("#header-section").height()
            }
            if (jQuery("#wpadminbar").length > 0) {
                an = an + jQuery("#wpadminbar").height()
            }
            if (jQuery(".sticky-top-bar").length > 0) {
                an = an + jQuery(".sticky-top-bar").height() > 0 ? jQuery(".sticky-top-bar").height() : jQuery("#top-bar").height()
            }
            jQuery(".page-content").stick_in_parent({offset_top: an + 30})
        }
    };
    var ab = jQuery(".blog-wrap").find(".blog-items");
    SWIFT.blog = {
        init: function () {
            ab.each(function () {
                var an = jQuery(this);
                if (an.hasClass("blog-grid-items")) {
                    SWIFT.blog.blogGrid(an.find(".grid-items"))
                } else {
                    SWIFT.blog.blogLayout(an)
                }
            });
            SWIFT.blog.blogFiltersInit();
            jQuery(".blog-slideout-trigger").on("click", function (ap) {
                ap.preventDefault();
                var aq = jQuery(this).parent().parent().parent().parent();
                var ao = aq.find(".blog-filter-wrap .filter-slide-wrap");
                var an = jQuery(this).attr("data-aux");
                aq.find(".aux-list li").addClass("col-sm-2");
                aq.find(".aux-list li a span").each(function () {
                    jQuery(this).html(jQuery(this).html().replace("(", "").replace(")", ""))
                });
                if (jQuery(this).parent().hasClass("selected") && !ao.is(":animated")) {
                    aq.find(".blog-aux-options li").removeClass("selected");
                    ao.slideUp(400);
                    return
                }
                aq.find(".blog-aux-options li").removeClass("selected");
                jQuery(this).parent().addClass("selected");
                if (ao.is(":visible")) {
                    ao.slideUp(400);
                    setTimeout(function () {
                        aq.find(".aux-list").css("display", "none");
                        aq.find(".aux-" + an).css("display", "block");
                        ao.slideDown()
                    }, 600)
                } else {
                    aq.find(".aux-list").css("display", "none");
                    aq.find(".aux-" + an).css("display", "block");
                    ao.slideDown()
                }
            })
        }, blogFiltersInit: function () {
            SWIFT.blog.blogShowFilters();
            jQuery(".filtering").animate({opacity: 1}, 400);
            jQuery(".blog-wrap .filtering li").on("click", "a", function (ap) {
                ap.preventDefault();
                jQuery(this).parent().parent().find("li").removeClass("selected");
                jQuery(this).parent().addClass("selected");
                var an = jQuery(this).data("filter");
                var ao = jQuery(this).parents(".blog-wrap").find(".blog-items");
                ao.isotope({filter: an})
            });
            jQuery(".filter-wrap > a").on("click", function (an) {
                an.preventDefault();
                jQuery(this).parent().find(".filter-slide-wrap").slideToggle()
            })
        }, blogShowFilters: function () {
            jQuery(".blog-wrap .filtering li").each(function () {
                var ap = jQuery(this), ao = jQuery(this).find("a").attr("class"), an = jQuery(this).parents(".blog-wrap").find(".blog-items"), aq = 0;
                an.find(".blog-item").each(function () {
                    if (jQuery(this).hasClass(ao)) {
                        ap.addClass("has-items");
                        aq++
                    }
                });
                if (ap.find("sup.count").length > 0) {
                    ap.find("sup.count").text(aq)
                } else {
                    ap.find("a").append('<sup class="count">' + aq + "</sup>")
                }
            })
        }, blogLayout: function (an) {
            var ar = an.data("blog-type"), aq = "fitRows";
            if (ar === "masonry") {
                aq = "masonry"
            }
            if (ar === "masonry" && an.hasClass("social-blog")) {
                var ap = an.parent().find(".blog-tweets").html(), ao = an.parent().find(".blog-instagrams");
                an.imagesLoaded(function () {
                    SWIFT.sliders.thumb();
                    an.isotope({
                        resizable: false,
                        itemSelector: ".blog-item",
                        layoutMode: "masonry",
                        getSortData: {
                            date: function (at) {
                                return jQuery(at).data("date")
                            }
                        },
                        sortBy: "date",
                        sortAscending: false,
                        isOriginLeft: !W
                    });
                    if (ap !== "") {
                        an.isotope("insert", jQuery(ap))
                    }
                    if (ao.length > 0) {
                        SWIFT.blog.masonryInstagram(ao, an)
                    }
                    an.isotope("updateSortData").isotope();
                    setTimeout(function () {
                        an.isotope("layout")
                    }, 500)
                })
            } else {
                an.imagesLoaded(function () {
                    SWIFT.sliders.thumb();
                    an.isotope({resizable: true, layoutMode: aq, isOriginLeft: !W});
                    setTimeout(function () {
                        an.isotope("layout")
                    }, 500)
                });
                an.appear(function () {
                    SWIFT.blog.animateItems(an)
                })
            }
        }, masonryInstagram: function (ap, ao) {
            var an = ap.data("userid"), aq = ap.data("token"), ar = ap.data("count"), au = ap.data("itemclass"), at = "756db9880cc84c3dab85118df38f9b91";
            jQuery.ajax({
                url: "https://api.instagram.com/v1/users/" + an + "/media/recent?access_token=" + aq,
                dataType: "jsonp",
                type: "GET",
                data: {client_id: at, count: ar},
                success: function (ax) {
                    for (var aw = 0; aw < ar; aw++) {
                        if (ax.data[aw]) {
                            var av = "";
                            if (ax.data[aw].caption) {
                                av = ax.data[aw].caption.text
                            }
                            ap.append("<li class='blog-item instagram-item " + au + "' data-date='" + ax.data[aw].created_time + "'><a class='timestamp inst-icon' target='_blank' href='" + ax.data[aw].link + "'><i class='fa-instagram'></i></a><div class='inst-overlay'><a target='_blank' href='" + ax.data[aw].link + "'></a><h6>" + ap.data("title") + "</h6><h2>" + av + "</h2><div class='name-divide'></div><data class='date timeago' title='" + ax.data[aw].created_time + "' value=''>" + ax.data[aw].created_time + "</data></div><img class='instagram-image' src='" + ax.data[aw].images.standard_resolution.url + "' width='306px' height='306px' /></li>")
                        }
                    }
                    jQuery("data.timeago").timeago();
                    ap.imagesLoaded(function () {
                        ao.isotope("insert", jQuery(ap.html()))
                    });
                    ao.isotope("updateSortData").isotope()
                },
                error: function (av) {
                    console.log(av)
                }
            })
        }, animateItems: function (an) {
            an.find(".blog-item").each(function (ao) {
                jQuery(this).delay(ao * 200).animate({opacity: 1,}, 800, "easeOutExpo", function () {
                    jQuery(this).addClass("item-animated")
                })
            })
        }, blogGrid: function (ao) {
            var ap = ao.parent().find(".blog-tweets").html(), an = ao.parent().find(".blog-instagrams");
            ao.imagesLoaded(function () {
                SWIFT.sliders.thumb();
                ao.isotope({
                    resizable: false,
                    itemSelector: ".blog-item",
                    layoutMode: "fitRows",
                    getSortData: {
                        id: function (aq) {
                            return jQuery(aq).data("sortid")
                        }
                    },
                    sortBy: "id",
                    sortAscending: true,
                    isOriginLeft: !W
                });
                setTimeout(function () {
                    ao.isotope("layout")
                }, 500);
                if (ap !== "") {
                    ao.isotope("insert", jQuery(ap))
                }
                if (an.length > 0) {
                    SWIFT.blog.blogGridInstagram(an, ao)
                }
                ao.isotope("updateSortData").isotope();
                SWIFT.blog.blogGridResize()
            }).animate({opacity: 1}, 800, "easeOutExpo");
            ag.smartresize(function () {
                SWIFT.blog.blogGridResize()
            })
        }, blogGridResize: function () {
            ab.find(".grid-items").each(function () {
                var an = jQuery(this).find(".blog-item"), ao = an.first().width();
                if (an.first().hasClass("col-sm-sf-25")) {
                    ao = ao / 2
                }
                an.css("height", ao)
            });
            setTimeout(function () {
                jQuery(".tweet-text,.quote-excerpt").dotdotdot();
                ab.find(".grid-items").isotope("layout")
            }, 500)
        }, blogGridInstagram: function (ao, aq) {
            var an = ao.data("userid"), ap = ao.data("token"), ar = ao.data("count"), au = ao.data("itemclass"), at = "756db9880cc84c3dab85118df38f9b91";
            jQuery.ajax({
                url: "https://api.instagram.com/v1/users/" + an + "/media/recent?access_token=" + ap,
                dataType: "jsonp",
                type: "GET",
                data: {client_id: at, count: ar},
                success: function (ax) {
                    for (var aw = 0; aw < ar; aw++) {
                        if (ax.data[aw]) {
                            var av = "";
                            if (ax.data[aw].caption) {
                                av = ax.data[aw].caption.text
                            }
                            ao.append("<li class='blog-item " + au + " instagram-item' data-date='" + ax.data[aw].created_time + "' data-sortid='" + aw * 2 + "'><a class='timestamp inst-icon' target='_blank' href='" + ax.data[aw].link + "'><i class='fa-instagram'></i></a><div class='inst-img-wrap'><div class='inst-overlay'><a target='_blank' href='" + ax.data[aw].link + "'></a><h6>" + ao.data("title") + "</h6><h2>" + av + "</h2><div class='name-divide'></div><data class='date timeago' title='" + ax.data[aw].created_time + "' value=''>" + ax.data[aw].created_time + "</data></div><img class='instagram-image' src='" + ax.data[aw].images.low_resolution.url + "' /></div></li>")
                        }
                    }
                    jQuery("data.timeago").timeago();
                    SWIFT.blog.blogGridResize();
                    ao.imagesLoaded(function () {
                        aq.isotope("insert", jQuery(ao.html()));
                        SWIFT.blog.blogGridResize()
                    });
                    aq.isotope("updateSortData").isotope()
                },
                error: function (av) {
                    console.log(av)
                }
            })
        }, infiniteScroll: function () {
            if (!(u && u < 9)) {
                var ao = jQuery("#inf-scroll-params");
                var an = {
                    loading: {
                        img: ao.data("loadingimage"),
                        msgText: ao.data("msgtext"),
                        finishedMsg: ao.data("finishedmsg")
                    },
                    nextSelector: ".pagenavi li.next a",
                    navSelector: ".pagenavi",
                    itemSelector: ".blog-item",
                    contentSelector: ".blog-items"
                };
                jQuery(an.contentSelector).infinitescroll(an, function (ap) {
                    SWIFT.sliders.thumb();
                    ab.imagesLoaded(function () {
                        ab.isotope("appended", ap);
                        jQuery.each(ap, function (ar, aq) {
                            jQuery(aq).addClass("item-animated")
                        })
                    });
                    jQuery('[data-rel="ilightbox[posts]"]').removeClass("ilightbox-enabled").iLightBox().destroy();
                    SWIFT.page.lightbox();
                    SWIFT.blog.blogShowFilters();
                    if (ab.parent().find(".pagination-wrap").hasClass("load-more")) {
                        jQuery(".load-more-btn").animate({opacity: 1}, 400)
                    }
                    ag.trigger("resize")
                });
                if (ab.parent().find(".pagination-wrap").hasClass("load-more")) {
                    ag.unbind(".infscr");
                    jQuery(".load-more-btn").on("click", function (ap) {
                        ap.preventDefault();
                        jQuery(an.contentSelector).infinitescroll("retrieve");
                        jQuery(".load-more-btn").animate({opacity: 0}, 400);
                        ag.trigger("resize")
                    })
                }
            } else {
                jQuery(".pagination-wrap").removeClass("hidden")
            }
        }
    };
    var L = jQuery(".galleries-wrap").find(".filterable-items");
    SWIFT.galleries = {
        init: function () {
            L.each(function () {
                var an = jQuery(this);
                if (an.hasClass("masonry-items")) {
                    SWIFT.galleries.masonrySetup(an)
                } else {
                    SWIFT.galleries.standardSetup(an)
                }
            });
            ag.smartresize(function () {
                SWIFT.galleries.windowResized()
            });
            jQuery(".galleries-wrap .filtering li").each(function () {
                var ao = jQuery(this), an = jQuery(this).find("a").attr("class"), aq = jQuery(this).parents(".galleries-wrap").find(".filterable-items"), ap = 0;
                aq.find(".gallery-item").each(function () {
                    if (jQuery(this).hasClass(an)) {
                        ao.addClass("has-items");
                        ap++
                    }
                });
                if (ao.find("sup.count").length > 0) {
                    ao.find("sup.count").text(ap)
                } else {
                    ao.find("a").append('<sup class="count">' + ap + "</sup>")
                }
            }).parents(".filtering").animate({opacity: 1}, 400);
            jQuery(".galleries-wrap .filtering li").on("click", "a", function (ao) {
                ao.preventDefault();
                jQuery(this).parent().parent().find("li").removeClass("selected");
                jQuery(this).parent().addClass("selected");
                var an = jQuery(this).data("filter");
                var ap = jQuery(this).parents(".galleries-wrap").find(".filterable-items");
                ap.isotope({filter: an})
            })
        }, standardSetup: function (an) {
            an.imagesLoaded(function () {
                SWIFT.galleries.setItemHeight();
                an.animate({opacity: 1}, 800);
                an.isotope({resizable: true, layoutMode: "fitRows", isOriginLeft: !W});
                setTimeout(function () {
                    an.isotope("layout")
                }, 500)
            });
            an.appear(function () {
                SWIFT.galleries.animateItems(an)
            })
        }, masonrySetup: function (an) {
            an.imagesLoaded(function () {
                an.isotope({resizable: false, itemSelector: ".gallery-item", layoutMode: "masonry", isOriginLeft: !W});
                setTimeout(function () {
                    an.isotope("layout")
                }, 500)
            });
            an.appear(function () {
                SWIFT.galleries.animateItems(an)
            })
        }, animateItems: function (an) {
            an.find(".gallery-item").each(function (ao) {
                jQuery(this).delay(ao * 200).animate({opacity: 1}, 800, "easeOutExpo", function () {
                    jQuery(this).addClass("item-animated")
                })
            })
        }, setItemHeight: function () {
            if (!L.hasClass("col-1") && !L.hasClass("masonry-items")) {
                L.children().css("min-height", "0");
                L.equalHeights()
            }
        }, windowResized: function () {
            if (!L.hasClass("col-1") && !L.hasClass("masonry-items")) {
                SWIFT.galleries.setItemHeight()
            }
        },
    };
    SWIFT.gallery = {
        init: function () {
            jQuery(".spb_gallery_widget").each(function () {
                if (jQuery(this).hasClass("gallery-masonry")) {
                    SWIFT.gallery.galleryMasonry(jQuery(this).find(".filterable-items"))
                } else {
                    if (jQuery(this).hasClass("gallery-slider")) {
                        SWIFT.gallery.gallerySlider(jQuery(this))
                    }
                }
            })
        }, galleryMasonry: function (an) {
            an.imagesLoaded(function () {
                an.isotope({resizable: false, itemSelector: ".gallery-image", layoutMode: "masonry", isOriginLeft: !W});
                setTimeout(function () {
                    an.isotope("layout")
                }, 500)
            });
            an.appear(function () {
                SWIFT.gallery.animateItems(an)
            })
        }, animateItems: function (an) {
            an.find(".gallery-image").each(function (ao) {
                jQuery(this).delay(ao * 200).animate({opacity: 1}, 800, "easeOutExpo", function () {
                    jQuery(this).addClass("item-animated")
                })
            })
        }, gallerySlider: function (ap) {
            var ao = ap.find(".gallery-slider > ul"), an = ao.parent().data("autoplay") === "yes" ? true : false, aq = ao.parent().data("thumbs") === "yes" ? true : false;
            ao.lightSlider({
                mode: ao.parent().data("transition"),
                item: 1,
                gallery: aq,
                autoWidth: false,
                slideMargin: 0,
                speed: T,
                auto: an,
                loop: true,
                pause: ad,
                keyPress: true,
                controls: true,
                rtl: W,
                adaptiveHeight: true,
                thumbMargin: 30,
                galleryMargin: 30,
                currentPagerPosition: "middle",
                swipeThreshold: 40,
                responsive: [{breakpoint: 1024, settings: {thumbItem: 3,}}],
                onSliderLoad: function (ar) {
                    ar.addClass("slider-loaded")
                }
            })
        }
    };
    SWIFT.recentPosts = {
        init: function () {
            var an = jQuery(".recent-posts:not(.carousel-items,.posts-type-list)");
            an.imagesLoaded(function () {
                SWIFT.sliders.thumb()
            });
            ag.smartresize(function () {
                jQuery(".recent-posts:not(.carousel-items,.posts-type-list)").children().css("min-height", "0");
                jQuery(".recent-posts:not(.carousel-items,.posts-type-list)").equalHeights()
            })
        }, load: function () {
            setTimeout(function () {
                jQuery(".recent-posts:not(.carousel-items,.posts-type-list)").children().css("min-height", "0");
                jQuery(".recent-posts:not(.carousel-items,.posts-type-list)").equalHeights()
            }, 400)
        }
    };
    SWIFT.carouselWidgets = {
        init: function () {
            var at = jQuery(".carousel-items"), an = j.data("carousel-autoplay"), aq = j.data("carousel-pagespeed"), au = j.data("carousel-slidespeed"), ap = j.data("carousel-pagination"), ao = "ltr", ar = 1199;
            if (D.hasClass("vertical-header")) {
                ar = ar + jQuery("#header-section").width()
            }
            if (an) {
                an = true
            } else {
                an = false
            }
            if (ap) {
                ap = true
            } else {
                ap = false
            }
            if (W) {
                ao = "rtl"
            }
            at.each(function () {
                var aw = jQuery("#" + jQuery(this).attr("id")), az = parseInt(aw.attr("data-columns"), 10), ay = 4 > az ? az : 4, av = 3 > az ? az : 3, ax = 1;
                if (aw.hasClass("clients-items")) {
                    ax = 2
                }
                if (aw.hasClass("testimonials")) {
                    ay = 1;
                    av = 1;
                    ax = 1
                }
                aw.imagesLoaded(function () {
                    if (!aw.hasClass("no-gutters")) {
                        var aA = aw.parent().width();
                        if (W) {
                            aw.css("margin-right", "-15px").css("width", aA + 30)
                        } else {
                            aw.css("margin-left", "-15px").css("width", aA + 30)
                        }
                    }
                    aw.owlCarousel({
                        items: az,
                        itemsDesktop: [ar, ay],
                        itemsDesktopSmall: [ar - 220, av],
                        itemsTablet: ax,
                        itemsMobile: [479, ax],
                        paginationSpeed: aq,
                        slideSpeed: au,
                        autoPlay: an,
                        autoPlayDirection: ao,
                        pagination: ap,
                        autoHeight: false,
                        beforeUpdate: function () {
                            if (!aw.hasClass("no-gutters")) {
                                var aB = aw.parent().width();
                                if (W) {
                                    aw.css("margin-right", "-15px").css("width", aB + 30)
                                } else {
                                    aw.css("margin-left", "-15px").css("width", aB + 30)
                                }
                            }
                        },
                        afterUpdate: function () {
                            setTimeout(function () {
                                SWIFT.sliders.thumb()
                            }, 200)
                        },
                        afterInit: function () {
                            SWIFT.sliders.thumb();
                            ag.trigger("resize");
                            setTimeout(function () {
                                SWIFT.parallax.init(true)
                            }, 200)
                        },
                        afterAction: function () {
                            var aB = aw.parents(".carousel-wrap").find(".carousel-next"), aC = aw.parents(".carousel-wrap").find(".carousel-prev");
                            if (this.itemsAmount > this.visibleItems.length) {
                                aB.show();
                                aC.show();
                                aB.removeClass("disabled");
                                aC.removeClass("disabled");
                                if (this.currentItem === 0) {
                                    aC.addClass("disabled")
                                }
                                if (this.currentItem == this.maximumItem) {
                                    aB.addClass("disabled")
                                }
                            } else {
                                aB.hide();
                                aC.hide()
                            }
                        }
                    }).animate({opacity: 1}, 800)
                })
            });
            jQuery(".carousel-next").click(function (aw) {
                aw.preventDefault();
                var av = jQuery(this).closest(".spb_content_element").find(".owl-carousel");
                if (W) {
                    av.data("owlCarousel").prev()
                } else {
                    av.data("owlCarousel").next()
                }
            });
            jQuery(".carousel-prev").click(function (aw) {
                aw.preventDefault();
                var av = jQuery(this).closest(".spb_content_element").find(".owl-carousel");
                if (W) {
                    av.data("owlCarousel").next()
                } else {
                    av.data("owlCarousel").prev()
                }
            })
        }, carouselSwipeIndicator: function (an) {
            an.appear(function () {
                var ao = jQuery(this).parents(".carousel-wrap").find(".sf-swipe-indicator");
                setTimeout(function () {
                    ao.fadeIn(500)
                }, 400);
                setTimeout(function () {
                    ao.addClass("animate")
                }, 1000);
                setTimeout(function () {
                    ao.fadeOut(400)
                }, 3000)
            })
        }, carouselMinHeight: function (ao) {
            var an = parseInt(ao.find(".carousel-item:not(.no-thumb)").eq(0).css("height"));
            ao.find(".owl-item").each(function () {
                jQuery(this).css("min-height", an + "px")
            })
        }
    };
    SWIFT.widgets = {
        init: function () {
            SWIFT.widgets.accordion();
            SWIFT.widgets.toggle();
            SWIFT.widgets.fullWidthVideo();
            SWIFT.widgets.introAnimations();
            SWIFT.widgets.iconBoxes();
            jQuery(".tabs-type-dynamic .menu-icon").hover(function () {
                jQuery(this).parents(".nav-tabs").addClass("show-tabs")
            });
            jQuery(".tabs-type-dynamic").mouseleave(function () {
                jQuery(this).find(".nav-tabs").removeClass("show-tabs")
            });
            jQuery(".widget_categories li span").each(function () {
                var an = jQuery(this), ao = an.text();
                an.text(ao.replace("(", "").replace(")", ""));
                an.addClass("show-count")
            })
        }, load: function () {
            SWIFT.widgets.tabs();
            if (s.hasClass("has-progress-bar")) {
                SWIFT.widgets.initSkillBars()
            }
            if (jQuery('[data-toggle="tooltip"]').length > 0 && !I) {
                SWIFT.widgets.initTooltips()
            }
        }, accordion: function () {
            jQuery(".spb_accordion").each(function () {
                var ap, ao = false, an = parseInt(jQuery(this).attr("data-active"), 10);
                if (jQuery.type(an) === "number") {
                    ao = an
                }
                ap = jQuery(this).find(".spb_accordion_wrapper").accordion({
                    header: "> div > h4",
                    autoHeight: true,
                    collapsible: true,
                    active: ao,
                    heightStyle: "content"
                })
            }).css("opacity", 1)
        }, tabs: function () {
            setTimeout(function () {
                jQuery(".spb_tabs").each(function () {
                    jQuery(this).find(".tab-pane").first().addClass("active");
                    jQuery(this).find(".tab-pane").removeClass("load")
                })
            }, 200);
            setTimeout(function () {
                jQuery(".spb_tour").each(function () {
                    jQuery(this).find(".tab-pane").first().addClass("active");
                    jQuery(this).find(".tab-pane").removeClass("load")
                })
            }, 200);
            jQuery("ul.nav-tabs li a, .spb_accordion_section > h4 a").on("click", "", function () {
                var ao = jQuery(this), an = ao.parents(".spb_content_element").first();
                if (an.find(".map-canvas").length > 0) {
                    setTimeout(function () {
                        jQuery(window).trigger("resize");
                        var ap = an.find(".map-canvas");
                        SWIFT.map.init()
                    }, 100)
                }
            });
            jQuery('a[data-toggle="tab"]').on("shown.bs.tab", function (ao) {
                var an = jQuery(ao.target).attr("href");
                if (jQuery(an).find(".filterable-items").length > 0) {
                    jQuery(an).find(".filterable-items").isotope("layout")
                }
            });
            setTimeout(function () {
                if (jQuery(".spb_tabs").length > 0) {
                    ag.trigger("resize");
                    var ar = document.location.toString();
                    if (ar.match("#") && jQuery('.nav-tabs a[href="#' + ar.split("#")[1] + '"]').length > 0) {
                        var av = jQuery('.nav-tabs a[href="#' + ar.split("#")[1] + ']"'), aw = ar.split("#")[1];
                        jQuery('.nav-tabs a[href="#' + aw + '"]').tab("show")
                    }
                    jQuery(".nav-tabs a").click(function (ay) {
                        var ax = ay.target.hash;
                        if (history.pushState) {
                            history.pushState(null, null, ax)
                        } else {
                            location.hash = ax
                        }
                    })
                }
                if (jQuery(".spb_accordion").length > 0) {
                    var aq = document.location.toString();
                    if (aq.match("#") && jQuery('.spb_accordion a[href="#' + aq.split("#")[1] + '"]').length > 0) {
                        var au = jQuery('.spb_accordion a[href="#' + aq.split("#")[1] + '"]'), at = aq.split("#")[1];
                        jQuery('.spb_accordion a[href="#' + at + '"]').click()
                    }
                    jQuery(".spb_accordion a").click(function (ay) {
                        var ax = ay.target.hash;
                        if (history.pushState) {
                            history.pushState(null, null, ax)
                        } else {
                            location.hash = ax
                        }
                    })
                }
                if (jQuery(".spb_tour").length > 0) {
                    var ao = document.location.toString();
                    if (ao.match("#") && jQuery('.spb_tour a[href="#' + ao.split("#")[1] + '"]').length > 0) {
                        var ap = jQuery('.spb_tour a[href="#' + ao.split("#")[1] + '"]'), an = ao.split("#")[1];
                        jQuery('.spb_tour a[href="#' + an + '"]').click()
                    }
                    jQuery(".spb_tour a").click(function (ay) {
                        var ax = ay.target.hash;
                        if (history.pushState) {
                            history.pushState(null, null, ax)
                        } else {
                            location.hash = ax
                        }
                    })
                }
            }, 200)
        }, toggle: function () {
            jQuery(".spb_toggle").click(function () {
                if (jQuery(this).hasClass("spb_toggle_title_active")) {
                    jQuery(this).removeClass("spb_toggle_title_active").next().slideUp(500)
                } else {
                    jQuery(this).addClass("spb_toggle_title_active").next().slideDown(500)
                }
            });
            jQuery(".spb_toggle_content").each(function () {
                if (jQuery(this).next().is("h4.spb_toggle") === false) {
                    jQuery('<div class="last_toggle_el_margin"></div>').insertAfter(this)
                }
            })
        }, initSkillBars: function () {
            SWIFT.widgets.animateSkillBars();
            jQuery("a.ui-tabs-anchor").click(function () {
                SWIFT.widgets.animateSkillBars()
            })
        }, animateSkillBars: function () {
            jQuery(".progress:not(.animated)").each(function () {
                var an = jQuery(this);
                an.appear(function () {
                    var ap = jQuery(this), ao = ap.find(".bar").data("value");
                    ap.addClass("animated");
                    ap.find(".bar").animate({width: ao + "%"}, 800, function () {
                        ap.parent().find(".bar-text").css("width", ao + "%");
                        ap.parent().find(".bar-text .progress-value").fadeIn(600)
                    })
                })
            })
        }, fullWidthVideo: function () {
            D.on("click", ".fw-video-link", function () {
                if (jQuery(this).data("video") !== "") {
                    SWIFT.widgets.openFullWidthVideo(jQuery(this))
                }
                return false
            });
            D.on("click", ".fw-video-close", function () {
                SWIFT.widgets.closeFullWidthVideo()
            })
        }, openFullWidthVideo: function (an) {
            jQuery(".fw-video-close").addClass("is-open");
            jQuery(".fw-video-spacer").animate({height: C}, 1000, "easeInOutExpo");
            jQuery(".fw-video-area").css("display", "block").animate({
                top: 0,
                height: "100%"
            }, 1000, "easeInOutExpo", function () {
                jQuery(".fw-video-area > .fw-video-wrap").append('<iframe class="fw-video" src="' + an.data("video") + '" width="100%" height="100%" frameborder="0" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen=""></iframe>')
            })
        }, closeFullWidthVideo: function () {
            jQuery(".fw-video-close").removeClass("is-open");
            jQuery(".fw-video-spacer").animate({height: 0}, 1000, "easeInOutExpo", function () {
            });
            jQuery(".fw-video-area").animate({top: "-100%"}, 1000, "easeInOutExpo", function () {
                jQuery(".fw-video-area").css("display", "none");
                jQuery(".fw-video-area .fw-video").remove()
            });
            jQuery(".fw-video-area video").each(function () {
                this.pause()
            });
            setTimeout(function () {
                jQuery(".fw-video-area").find("iframe").remove()
            }, 1500);
            return false
        }, introAnimations: function () {
            if (!(I && D.hasClass("disable-mobile-animations"))) {
                jQuery(".sf-animation").each(function () {
                    var an = jQuery(this);
                    an.waypoint(function (ap) {
                        var aq = an.data("animation"), ao = an.data("delay");
                        setTimeout(function () {
                            window.requestAnimationFrame(function () {
                                an.addClass(aq + " sf-animate")
                            })
                        }, ao)
                    }, {offset: "90%", triggerOnce: true})
                })
            }
        }, iconBoxes: function () {
            if (I) {
                jQuery(".sf-icon-box").on("click", function () {
                    jQuery(this).addClass("sf-mobile-hover")
                })
            } else {
                jQuery(".sf-icon-box").hover(function () {
                    jQuery(this).addClass("sf-hover")
                }, function () {
                    jQuery(this).removeClass("sf-hover")
                })
            }
        }, initTooltips: function () {
            jQuery('[data-toggle="tooltip"]').tooltip({trigger: "hover"})
        }
    };
    SWIFT.teamMembers = {
        init: function () {
            var an = jQuery(".team-members:not(.carousel-items)");
            an.imagesLoaded(function () {
                if (ag.width() > 767) {
                    an.equalHeights()
                }
            });
            ag.smartresize(function () {
                jQuery(".team-members:not(.carousel-items)").children().css("min-height", "0");
                if (ag.width() > 767) {
                    jQuery(".team-members:not(.carousel-items)").equalHeights()
                }
            })
        }
    };
    SWIFT.relatedPosts = {
        init: function () {
            var an = jQuery(".related-items");
            an.imagesLoaded(function () {
                if (ag.width() > 767) {
                    an.equalHeights()
                }
            });
            ag.smartresize(function () {
                jQuery(".related-items").children().css("min-height", "0");
                if (ag.width() > 767) {
                    jQuery(".related-items").equalHeights()
                }
            })
        }
    };
    SWIFT.parallax = {
        init: function (an) {
            jQuery(".spb_parallax_asset").each(function (ap) {
                var ao = jQuery(this);
                if (ao.hasClass("sf-parallax-video")) {
                    if (!I) {
                        SWIFT.parallax.parallaxVideoInit()
                    } else {
                        ao.find("video").remove();
                        ao.transition({opacity: 1}, 300)
                    }
                    ag.smartresize(function () {
                        SWIFT.parallax.parallaxVideoResize(ao)
                    })
                } else {
                    if (ao.hasClass("parallax-window-height")) {
                        ao.css("height", "");
                        var aq = ag.height();
                        if (ao.height() > aq && !ap) {
                            aq = ao.height()
                        }
                        ao.height(aq - (parseInt(ao.css("padding-top"), 10) * 2));
                        if (ao.data("v-center") === "true") {
                            ao.find("div:first").vCenterTop()
                        }
                        ao.transition({opacity: 1}, 300);
                        setTimeout(function () {
                            SWIFT.parallax.windowImageResize(ao)
                        }, 500);
                        ag.smartresize(function () {
                            SWIFT.parallax.windowImageResize(ao)
                        })
                    }
                }
            })
        }, load: function () {
            jQuery.stellar({horizontalScrolling: false, verticalOffset: 0,})
        }, videoScroll: function (aq) {
            var ap = aq.offset().top, au = ag.scrollTop(), at = parseInt(aq.data("height-default"), 10), ar = au - ap, ao = aq.find(".spb_content_wrapper").css("top"), an = at - ar * 1.5;
            if (au > ap) {
                aq.css("height", an);
                aq.find(".spb_content_wrapper").css("opacity", 1 - (ar / 300));
                if (aq.hasClass("parallax-window-height") && aq.data("v-center") === "true") {
                    aq.find(".spb_content_wrapper").css("top", ao + (ar / 4))
                } else {
                    if (aq.data("v-center") === "true") {
                        aq.find(".spb_content_wrapper").css("top", (ar / 3))
                    }
                }
            } else {
                aq.css("height", at);
                aq.find(".spb_content_wrapper").css("opacity", 1);
                if (aq.hasClass("parallax-video-height") && aq.data("v-center") === "true") {
                    aq.find(".spb_content_wrapper").css("top", "50%")
                } else {
                    aq.find(".spb_content_wrapper").css("top", 0)
                }
            }
        }, windowImageResize: function (ao) {
            if (ao.hasClass("spb-row-container")) {
                var an = ao.find("> .spb_content_element").height();
                if (ao.hasClass("parallax-window-height")) {
                    if (an < ag.height()) {
                        an = ag.height()
                    }
                }
                ao.height(an);
                if (ao.data("v-center")) {
                    ao.find("> .spb_content_element").vCenterTop()
                }
            } else {
                var ap = ao.height();
                if (ao.hasClass("parallax-window-height")) {
                    if (ap < ag.height()) {
                        ap = ag.height()
                    }
                }
                ao.height(ap - ao.css("padding-top") / 2);
                ao.find(".spb_content_wrapper").vCenterTop()
            }
        }, parallaxVideoInit: function () {
            jQuery(".spb_parallax_asset.sf-parallax-video").each(function () {
                var aq = jQuery(this), ar = aq.find("video"), ao = ar.width(), an = aq.find("div:first"), ap = 0;
                if (aq.hasClass("parallax-window-height")) {
                    if (an.height() > ag.height()) {
                        ap = an.height()
                    } else {
                        ap = ag.height()
                    }
                    aq.animate({height: ap}, 400);
                    setTimeout(function () {
                        SWIFT.parallax.parallaxVideoResize(aq);
                        aq.transition({opacity: 1}, 300)
                    }, 500);
                    setTimeout(function () {
                        aq.find(".video-overlay").animate({opacity: 0.8}, 200)
                    }, 100);
                    if (aq.data("v-center") === "true") {
                        an.vCenterTop()
                    }
                    setTimeout(function () {
                        an.animate({opacity: 1, top: "50%"}, 600, "easeOutExpo")
                    }, 600);
                    aq.attr("data-height-default", ar.height())
                } else {
                    SWIFT.parallax.scaleVideo(aq)
                }
                if (ag.width() < ao) {
                    ar.css("left", -(ao - ag.width()) / 2)
                }
                var at = ar.get(0);
                at.load();
                at.addEventListener("loadeddata", function () {
                    SWIFT.parallax.parallaxVideoResize(aq)
                })
            })
        }, parallaxVideoResize: function (ap) {
            var an = ap.find("div:first"), ao = 0;
            if (ap.hasClass("parallax-window-height")) {
                if (an.height() > ag.height()) {
                    ao = an.height()
                } else {
                    ao = ag.height()
                }
                ap.animate({height: ao}, 400);
                if (ap.data("v-center") === "true") {
                    an.vCenterTop()
                }
            }
            SWIFT.parallax.scaleVideo(ap)
        }, scaleVideo: function (aq) {
            var ao = aq.find("video"), at = aq.outerHeight(), an = aq.outerWidth(), av = ao[0].videoWidth, au = ao[0].videoHeight;
            var ar = an / av;
            var ax = at / au;
            var ap = ar > ax ? ar : ax;
            var aw = av / au * (at + 20);
            if (ap * av < aw) {
                ap = aw / av
            }
            ao.width(Math.ceil(ap * av + 2));
            ao.height(Math.ceil(ap * au + 50));
            ao.css("margin-top", -(ao.height() - at) / 2);
            ao.css("margin-left", -(ao.width() - an) / 2)
        },
    };
    var F = [], Z = [], R, P, o, ac = "", H, ah, ai, z, t, K = "", a = true, n, Y, ak, X = [], k, U, w, ae, O, c = "";
    SWIFT.map = {
        init: function () {
            var ao = jQuery(".map-canvas");
            var an;
            if (typeof google !== "undefined") {
                P = new google.maps.LatLngBounds()
            }
            ao.each(function (aq, ap) {
                an = ap;
                var at = an.getAttribute("data-zoom"), ar = an.getAttribute("data-controls") == "yes" ? true : false;
                H = an.getAttribute("data-maptype");
                ah = an.getAttribute("data-mapcolor");
                z = an.getAttribute("data-center-lat");
                t = an.getAttribute("data-center-lng");
                ai = an.getAttribute("data-mapsaturation");
                SWIFT.map.createMap(an, at, ar, H, ah, ai, jQuery(this))
            })
        }, getLatLong: function (ao, aq, an, ap) {
            var ar;
            ar = new google.maps.Geocoder();
            ar.geocode({address: ao}, function (au, at) {
                ap(au[0].geometry.location, au[0].geometry.location.lat(), au[0].geometry.location.lng(), aq, an)
            })
        }, addWinContent: function (an, ao, ap) {
            google.maps.event.addListener(an, "click", function () {
                R.setContent(ao);
                R.open(ap, an)
            })
        }, addMarker: function (ap, au, ao, av, aq, aw, ar) {
            var an;
            ak = new google.maps.LatLng(n, Y);
            if (au) {
                K = new google.maps.LatLng(n, Y);
                an = new google.maps.Marker({position: ak, map: ap, icon: au, animation: google.maps.Animation.DROP})
            } else {
                K = new google.maps.LatLng(n, Y);
                an = new google.maps.Marker({position: ak, map: ap, animation: google.maps.Animation.DROP})
            }
            var at = '<div class="pinmarker">';
            if (ao !== "") {
                at += "<h3>" + ao + "</h3>"
            }
            if (av !== "") {
                at += "<p>" + av + " </p>"
            }
            if (aq !== "" && ar !== "") {
                at += '<div><a href="' + aq + '" target="_blank">' + ar + "</a></div>"
            }
            at += "</div>";
            R = new google.maps.InfoWindow();
            SWIFT.map.addWinContent(an, at, ap);
            P.extend(ak)
        }, createMap: function (av, ax, ay, at, az, aw, au) {
            if (typeof google == "undefined") {
                return
            }
            o = new google.maps.LatLngBounds();
            var aA = "", ap = false;
            var an = [], ar = false;
            if (jQuery(av).parent().find(".map-styles-array").length > 0) {
                ar = true;
                an = JSON.parse(jQuery(av).parent().find(".map-styles-array").text())
            } else {
                if (aw == "mono-light") {
                    if (az === "") {
                        az = "#ffffff"
                    }
                    aw = -100
                } else {
                    if (aw == "mono-dark") {
                        if (az === "") {
                            az = "#222222"
                        }
                        aw = -100;
                        ap = true
                    } else {
                        aw = -20
                    }
                }
                an = [{stylers: [{hue: az}, {invert_lightness: ap}, {saturation: aw}]}]
            }
            if (I) {
                a = false
            }
            if (at === "satellite") {
                ac = google.maps.MapTypeId.SATELLITE
            } else {
                if (at === "terrain") {
                    ac = google.maps.MapTypeId.TERRAIN
                } else {
                    if (at === "hybrid") {
                        ac = google.maps.MapTypeId.HYBRID
                    } else {
                        ac = google.maps.MapTypeId.ROADMAP
                    }
                }
            }
            var aB = {
                zoom: parseInt(ax, 10),
                scrollwheel: false,
                draggable: a,
                mapTypeControl: true,
                disableDefaultUI: !ay,
                mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
                navigationControl: true,
                navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
                mapTypeId: ac,
                styles: an
            };
            var aq = new google.maps.Map(av, aB);
            var ao = au.parent().find(".pin_location").length;
            F.push(aq);
            google.maps.event.addDomListener(window, "resize", function () {
                jQuery.each(F, function (aC, aD) {
                    aD.fitBounds(Z[aC]);
                    aD.setZoom(parseInt(ax, 10))
                })
            });
            P = new google.maps.LatLngBounds();
            Z.push(P);
            au.parent().find(".pin_location").each(function (aD, aC) {
                aA = aC.getAttribute("data-pinimage");
                k = aC.getAttribute("data-title");
                U = aC.getAttribute("data-content");
                ae = aC.getAttribute("data-address");
                w = aC.getAttribute("data-pinlink");
                n = aC.getAttribute("data-lat");
                Y = aC.getAttribute("data-lng");
                O = aC.getAttribute("data-button-text");
                if (n === "" && Y === "") {
                    SWIFT.map.getLatLong(ae, k, aA, function (aF, aI, aH, aG, aE) {
                        n = aI;
                        Y = aH;
                        k = aG;
                        aA = aE;
                        SWIFT.map.addMarker(aq, aA, k, U, w, ae, O);
                        if (ao > 1) {
                            if (z !== "" && t !== "") {
                                aq.setZoom(parseInt(ax, 10));
                                aq.setCenter(new google.maps.LatLng(z, t))
                            } else {
                                aq.fitBounds(P)
                            }
                        } else {
                            aq.setZoom(parseInt(ax, 10));
                            aq.setCenter(new google.maps.LatLng(n, Y))
                        }
                    })
                } else {
                    SWIFT.map.addMarker(aq, aA, k, U, w, ae, O);
                    if (ao > 1) {
                        if (z !== "" && t !== "") {
                            aq.setZoom(parseInt(ax, 10));
                            aq.setCenter(new google.maps.LatLng(z, t))
                        } else {
                            aq.fitBounds(P)
                        }
                    } else {
                        aq.setZoom(parseInt(ax, 10));
                        aq.setCenter(new google.maps.LatLng(n, Y))
                    }
                }
            })
        }
    };
    SWIFT.mapDirectory = {
        init: function (an, aq, ao) {
            an = jQuery("#dir-search-value").val();
            aq = jQuery(".directory-location-option").val();
            ao = jQuery(".directory-category-option").val();
            var ar = jQuery(".map-directory-canvas");
            var ap, at;
            ar.each(function (ay, ax) {
                var az = ax, aB = az.getAttribute("data-zoom"), aA = az.getAttribute("data-maptype"), av = az.getAttribute("data-mapcolor"), aw = az.getAttribute("data-mapsaturation"), au = az.getAttribute("data-excerpt");
                if (ao === null || ao == "All") {
                    ao = az.getAttribute("data-directory-category")
                }
                SWIFT.mapDirectory.directoryMap(az, aB, aA, av, aw, jQuery(this), an, aq, ao)
            })
        }, searchDirectory: function () {
            SWIFT.mapDirectory.init(jQuery("#dir-search-value").val(), jQuery(".directory-location-option").val(), jQuery(".directory-category-option").val())
        }, getLatLong: function (an, ao) {
            var ap;
            ap = new google.maps.Geocoder();
            ap.geocode({address: an}, function (ar, aq) {
                ao(ar[0].geometry.location, ar[0].geometry.location.lat(), ar[0].geometry.location.lng())
            })
        }, addWinContent: function (an, ao, ap) {
            X.push(an);
            google.maps.event.addListener(an, "click", function () {
                R.setContent(ao);
                R.open(ap, an)
            })
        }, addMarkerDir: function (aq, aw, ao, ay, ar, az, at, aA, av, ax) {
            var an, ap;
            ak = new google.maps.LatLng(av, ax);
            if (aw) {
                K = new google.maps.LatLng(av, ax);
                an = new google.maps.Marker({
                    position: ak,
                    map: aq,
                    icon: aw,
                    optimized: false,
                    animation: google.maps.Animation.DROP
                })
            } else {
                K = new google.maps.LatLng(av, ax);
                an = new google.maps.Marker({position: ak, map: aq, animation: google.maps.Animation.DROP})
            }
            if (aA === null) {
                ap = ""
            } else {
                ap = '<img class="info-window-img" alt="" src="' + aA + '" height="140" width="140"/>'
            }
            var au = "";
            if (ar === "" || at === "") {
                au = '<div class="pinmarker">' + ap + '<div class="pinmarker-container"><h3>' + ao + '</h3><div class="excerpt">' + ay + "</div></div></div>"
            } else {
                au = '<div class="pinmarker">' + ap + '<div class="pinmarker-container"><h3>' + ao + '</h3><div class="excerpt">' + ay + '</div><a class="pin-button" href="' + ar + '" target="_blank">' + at + "</a></div></div>"
            }
            R = new google.maps.InfoWindow();
            SWIFT.mapDirectory.addWinContent(an, au, aq);
            o.extend(ak)
        }, directoryMap: function (aw, aF, aH, aL, aE, aG, aI, ax, au, aB) {
            var aK = "", aJ = false;
            var aC = aw.getAttribute("data-directory-map-filter");
            var an = aw.getAttribute("data-directory-map-filter-pos");
            var az = aw.getAttribute("data-directory-map-results");
            var aq = aw.getAttribute("data-excerpt");
            var av = "";
            if (az !== "list") {
                if (aE == "mono-light") {
                    if (aL === "") {
                        aL = "#ffffff"
                    }
                    aE = -100
                } else {
                    if (aE == "mono-dark") {
                        if (aL === "") {
                            aL = "#222222"
                        }
                        aE = -100;
                        aJ = true
                    } else {
                        aE = -20
                    }
                }
                var ay = [{stylers: [{hue: aL}, {invert_lightness: aJ}, {saturation: aE}]}];
                var ar = new google.maps.StyledMapType(ay, {name: "Styled Map"});
                if (I) {
                    a = false
                }
                if (aH === "satellite") {
                    ac = google.maps.MapTypeId.SATELLITE
                } else {
                    if (aH === "terrain") {
                        ac = google.maps.MapTypeId.TERRAIN
                    } else {
                        if (aH === "hybrid") {
                            ac = google.maps.MapTypeImapDirContainerd.HYBRID
                        } else {
                            ac = google.maps.MapTypeId.ROADMAP
                        }
                    }
                }
            } else {
                jQuery(aw).hide()
            }
            var aM, ao, ap, at, aA, aD, aP;
            var aO = aG.parent().find(".pin_location").length;
            o = new google.maps.LatLngBounds();
            if (au === "") {
                au = aw.getAttribute("data-directory-category")
            }
            var aN = {action: "sf_directory", search_term: aI, location_term: ax, category_term: au, item_excerpt: aq};
            jQuery.post(aw.getAttribute("data-ajaxurl"), aN, function (aU) {
                var aY = jQuery.parseJSON(aU);
                var aW;
                var aQ = aY.results;
                jQuery(".directory-results").hide();
                var aT = {
                    scrollwheel: false,
                    draggable: a,
                    mapTypeControl: true,
                    mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
                    navigationControl: true,
                    navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
                    mapTypeId: ac
                };
                if (aQ > 0) {
                    var aR = new google.maps.Map(aw, aT);
                    X = [];
                    if (aL !== "" && az != "list") {
                        aR.mapTypes.set("map_style", ar);
                        aR.setMapTypeId("map_style")
                    }
                    google.maps.event.addDomListener(window, "resize", function () {
                        aR.fitBounds(o);
                        aR.setZoom(parseInt(aF, 10))
                    });
                    var aX = "", aS = "";
                    if (aQ > 1) {
                        aX = aY.results_text_1 + " " + aQ + " " + aY.results_text_2plural
                    } else {
                        aX = aY.results_text_1 + " " + aQ + " " + aY.results_text_2
                    }
                    jQuery(aw).parent().parent().parent().find(".directory-results").prepend('<div class="results-title"><h2>' + aX + "</h2>")
                } else {
                    for (var aV = 0; aV < X.length; aV++) {
                        X[aV].setMap(null)
                    }
                    jQuery(aw).parent().parent().parent().find(".directory-results").append('<div class="results-title"><h2>' + aY.errormsg + "</h2>")
                }
                if (aQ > 0 && az != "list") {
                    jQuery(aw).show();
                    jQuery(".directory-results").append(aY.pagination);
                    jQuery.each(aY.items, function (bb, bc) {
                        var be = bc.pin_title, bd = bc.pin_logo_url, a0 = bc.pin_content, a7 = bc.pin_short_content, a3 = bc.pin_address, a1 = bc.pin_link, a5 = bc.pin_button_text, a8 = bc.pin_lat, a6 = bc.pin_lng, bg = bc.pin_thumbnail, a9 = bc.categories, aZ = bc.location, ba = "", bf = true, a4 = false, a2 = "";
                        if (aq !== "") {
                            a0 = a7
                        }
                        if (bg && a1) {
                            a4 = true;
                            ba = '<figure class="animated-overlay overlay-alt"><img itemprop="image" src="' + bg + '" alt="' + be + '"><a href="' + a1 + '" target="_blank" class="link-to-post"></a><div class="figcaption-wrap"></div><figcaption><div class="thumb-info"><h4>' + be + "</h4></div></figcaption></figure>"
                        } else {
                            if (bg) {
                                a4 = true;
                                ba = '<figure><img itemprop="image" src="' + bg + '" alt="' + be + '"></figure>'
                            }
                        }
                        if (!a4) {
                            a2 = "no-thumb"
                        }
                        if (az != "list") {
                            SWIFT.mapDirectory.addMarkerDir(aR, bd, be, a0, a1, a3, a5, bg, a8, a6);
                            if (aQ > 1) {
                                aR.fitBounds(o)
                            } else {
                                aR.setZoom(parseInt(aF, 10));
                                aR.setCenter(new google.maps.LatLng(a8, a6))
                            }
                        }
                    })
                } else {
                    jQuery(aw).hide()
                }
                jQuery(".directory-results").show()
            })
        }
    };
    SWIFT.crowdfunding = {
        init: function () {
            if (jQuery("#back-this-project").find(".edd_price_options").length <= 0) {
                jQuery("#back-this-project > h2").css("display", "none")
            }
            if (jQuery("#back-this-project").hasClass("project-donate-only")) {
                jQuery(".edd_price_options").find("li").first().addClass("atcf-selected");
                jQuery(".edd_price_options").find("li").first().find('input[type="radio"]').prop("checked", true)
            }
            jQuery(".atcf-price-option").on("click", function () {
                var ap = jQuery(this), ao = ap.data("price").substr(0, ap.data("price").indexOf("-"));
                if (ap.hasClass("inactive")) {
                    return false
                }
                if (ao && jQuery("#atcf_custom_price").val().length <= 0) {
                    jQuery("#atcf_custom_price").val(ao)
                }
                jQuery(".atcf-price-option").find('input[type="radio"]').prop("checked", false);
                jQuery(".atcf-price-option").removeClass("atcf-selected");
                ap.find('input[type="radio"]').prop("checked", true);
                ap.addClass("atcf-selected")
            });
            var an = jQuery(".campaign-items:not(.carousel-items)");
            an.imagesLoaded(function () {
                an.equalHeights()
            });
            ag.smartresize(function () {
                jQuery(".campaign-items:not(.carousel-items)").children().css("min-height", "0");
                jQuery(".campaign-items:not(.carousel-items)").equalHeights()
            })
        }
    };
    var i, M, S, q, r, v, J, d = true;
    SWIFT.canvasEffects = {
        init: function (ao) {
            var an = jQuery(".sf-canvas-effect");
            if (an.data("type") === "circles") {
                SWIFT.canvasEffects.initCircles(an, ao)
            } else {
                if (an.data("type") === "geometric") {
                    SWIFT.canvasEffects.initGeometry(an, ao)
                }
            }
        }, initCircles: function (ao, ap) {
            i = ao.parent().width();
            M = ap > 0 ? ap : ao.parent().height();
            J = {x: 0, y: M};
            var aq = ao.find("canvas").data("canvas_id");
            ao.find("canvas").attr("width", i).attr("height", M);
            q = document.getElementById(aq).getContext("2d");
            v = [];
            for (var an = 0; an < i * 2; an++) {
                var ar = new SWIFT.canvasEffects.circleInstance();
                v.push(ar)
            }
            SWIFT.canvasEffects.animateCircles()
        }, animateCircles: function () {
            q.clearRect(0, 0, i, M);
            for (var an = 0; an < v.length; an++) {
                v[an].draw()
            }
            requestAnimationFrame(SWIFT.canvasEffects.animateCircles)
        }, circleInstance: function () {
            var ao = this;
            (function () {
                ao.pos = {};
                an()
            })();
            function an() {
                ao.pos.x = Math.random() * i;
                ao.pos.y = -30 - Math.random() * 100;
                ao.alpha = 0.1 + Math.random() * 0.3;
                ao.scale = 0.1 + Math.random() * 0.3;
                ao.velocity = -Math.random()
            }

            this.draw = function () {
                if (ao.alpha <= 0) {
                    an()
                }
                ao.pos.y -= ao.velocity;
                ao.alpha -= 0.0005;
                q.beginPath();
                q.arc(ao.pos.x, ao.pos.y, ao.scale * 10, 0, 2 * Math.PI, false);
                q.fillStyle = "rgba(255,255,255," + ao.alpha + ")";
                q.fill()
            }
        }, initGeometry: function (ap, aE) {
            i = ap.parent().width();
            M = aE > 0 ? aE : ap.parent().height();
            J = {x: i / 2, y: M / 2};
            var au = ap.find("canvas").data("canvas_id");
            ap.find("canvas").attr("width", i).attr("height", M);
            q = document.getElementById(au).getContext("2d");
            r = [];
            for (var at = 0; at < i; at = at + i / 20) {
                for (var ar = 0; ar < M; ar = ar + M / 20) {
                    var ax = at + Math.random() * i / 40;
                    var aw = ar + Math.random() * M / 20;
                    var ay = {x: ax, originX: ax, y: aw, originY: aw};
                    r.push(ay)
                }
            }
            for (var aD = 0; aD < r.length; aD++) {
                var av = [];
                var ao = r[aD];
                for (var aC = 0; aC < r.length; aC++) {
                    var an = r[aC];
                    if (ao != an) {
                        var aF = false;
                        for (var aB = 0; aB < 3; aB++) {
                            if (!aF) {
                                if (av[aB] === undefined) {
                                    av[aB] = an;
                                    aF = true
                                }
                            }
                        }
                        for (var aq = 0; aq < 3; aq++) {
                            if (!aF) {
                                if (SWIFT.canvasEffects.getDistance(ao, an) < SWIFT.canvasEffects.getDistance(ao, av[aq])) {
                                    av[aq] = an;
                                    aF = true
                                }
                            }
                        }
                    }
                }
                ao.closest = av
            }
            for (var aA = 0; aA < r.length; aA++) {
                var aG = new SWIFT.canvasEffects.geoCircleInstance(r[aA], 2 + Math.random(), "rgba(255,255,255,0.3)");
                r[aA].circle = aG
            }
            SWIFT.canvasEffects.animateGeometry();
            for (var az = 0; az < r.length; az++) {
                SWIFT.canvasEffects.shiftPoint(r[az])
            }
            if (!("ontouchstart" in window)) {
                window.addEventListener("mousemove", SWIFT.canvasEffects.mouseMove)
            }
        }, mouseMove: function (ao) {
            var an = 0;
            var ap = 0;
            if (ao.pageX || ao.pageY) {
                an = ao.pageX;
                ap = ao.pageY
            } else {
                if (ao.clientX || ao.clientY) {
                    an = ao.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
                    ap = ao.clientY + document.body.scrollTop + document.documentElement.scrollTop
                }
            }
            J.x = an;
            J.y = ap / 2
        }, animateGeometry: function () {
            q.clearRect(0, 0, i, M);
            for (var an = 0; an < r.length; an++) {
                if (Math.abs(SWIFT.canvasEffects.getDistance(J, r[an])) < 20000) {
                    r[an].active = 0.2;
                    r[an].circle.active = 0.3
                } else {
                    if (Math.abs(SWIFT.canvasEffects.getDistance(J, r[an])) < 300000) {
                        r[an].active = 0.1;
                        r[an].circle.active = 0.2
                    } else {
                        if (Math.abs(SWIFT.canvasEffects.getDistance(J, r[an])) < 2000000) {
                            r[an].active = 0.02;
                            r[an].circle.active = 0.1
                        } else {
                            r[an].active = 0;
                            r[an].circle.active = 0
                        }
                    }
                }
                SWIFT.canvasEffects.drawLines(r[an]);
                r[an].circle.draw()
            }
            requestAnimationFrame(SWIFT.canvasEffects.animateGeometry)
        }, shiftPoint: function (an) {
            TweenLite.to(an, 1 + 1 * Math.random(), {
                x: an.originX - 50 + Math.random() * 100,
                y: an.originY - 50 + Math.random() * 100,
                ease: Circ.easeInOut,
                onComplete: function () {
                    SWIFT.canvasEffects.shiftPoint(an)
                }
            })
        }, drawLines: function (ao) {
            if (!ao.active) {
                return
            }
            for (var an = 0; an < ao.closest.length; an++) {
                q.beginPath();
                q.moveTo(ao.x, ao.y);
                q.lineTo(ao.closest[an].x, ao.closest[an].y);
                q.strokeStyle = "rgba(255,255,255," + ao.active + ")";
                q.stroke()
            }
        }, geoCircleInstance: function (aq, an, ao) {
            var ap = this;
            (function () {
                ap.pos = aq || null;
                ap.radius = an || null;
                ap.color = ao || null
            })();
            this.draw = function () {
                if (!ap.active) {
                    return
                }
                q.beginPath();
                q.arc(ap.pos.x, ap.pos.y, ap.radius, 0, 2 * Math.PI, false);
                q.fillStyle = "rgba(255,255,255," + ap.active + ")";
                q.fill()
            }
        }, getDistance: function (ao, an) {
            return Math.pow(ao.x - an.x, 2) + Math.pow(ao.y - an.y, 2)
        }
    };
    SWIFT.reloadFunctions = {
        init: function () {
            jQuery("img[title]").each(function () {
                jQuery(this).removeAttr("title")
            });
            if (!am) {
                jQuery("embed").show()
            }
            jQuery(".animate-top").on("click", function (an) {
                an.preventDefault();
                jQuery("body,html").animate({scrollTop: 0}, 800, "easeOutCubic")
            })
        }, load: function () {
            if (!I) {
                jQuery(".tooltip").each(function () {
                    jQuery(this).css("marginLeft", "-" + Math.round((jQuery(this).outerWidth(true) / 2)) + "px")
                });
                jQuery(".comment-avatar").hover(function () {
                    jQuery(this).find(".tooltip").stop().animate({bottom: "44px", opacity: 1}, 500, "easeInOutExpo")
                }, function () {
                    jQuery(this).find(".tooltip").stop().animate({bottom: "25px", opacity: 0}, 400, "easeInOutExpo")
                });
                jQuery(".grid-image").hover(function () {
                    jQuery(this).find(".tooltip").stop().animate({bottom: "85px", opacity: 1}, 500, "easeInOutExpo")
                }, function () {
                    jQuery(this).find(".tooltip").stop().animate({bottom: "65px", opacity: 0}, 400, "easeInOutExpo")
                })
            }
        }
    };
    var ag = jQuery(window), D = jQuery("body"), s = jQuery("#sf-included"), j = jQuery("#sf-option-params"), C = SWIFT.page.getViewportHeight(), l = navigator.userAgent.toLowerCase(), N = l.match(/(iphone|ipod|android|iemobile)/), I = l.match(/(iphone|ipod|ipad|android|iemobile)/), am = l.match(/(iphone|ipod|ipad)/), aa = l.match(/(iemobile)/), g = navigator.userAgent.indexOf("Safari") != -1 && navigator.userAgent.indexOf("Chrome") == -1 && navigator.userAgent.indexOf("Android") == -1, f = navigator.userAgent.indexOf("Safari") != -1 || navigator.userAgent.indexOf("Chrome") == -1, u = SWIFT.page.checkIE(), W = D.hasClass("rtl") ? true : false, al = false, E = false, A = false, m = 0, y = j.data("slider-autoplay") ? true : false, ad = j.data("slider-slidespeed"), T = j.data("slider-animspeed"), Q = j.data("lightbox-enabled") ? true : false, B = j.data("lightbox-nav") === "arrows" ? true : false, p = j.data("lightbox-thumbs") ? true : false, V = j.data("lightbox-skin") === "dark" ? "metro-black" : "metro-white", G = j.data("lightbox-sharing") ? true : false, aj = jQuery("#sf-included").hasClass("has-productzoom") && !I ? true : false, b = j.data("product-zoom-type") === "lens" ? "lens" : "inner", e = j.data("product-slider-thumbs-pos") === "left" ? "left" : "bottom", af = j.data("product-slider-vert-height"), h = j.data("cart-notification");
    SWIFT.isScrolling = false;
    SWIFT.productSlider = false;
    SWIFT.onReady = {
        init: function () {
            SWIFT.page.init();
            SWIFT.sliders.init();
            if (s.hasClass("has-gallery")) {
                SWIFT.gallery.init()
            }
            if (jQuery(".sf-super-search").length > 0) {
                SWIFT.superSearch.init()
            }
            if (jQuery("#header-section").length > 0) {
                SWIFT.header.init()
            }
            SWIFT.nav.init();
            SWIFT.woocommerce.init();
            SWIFT.woocommerce.cartWishlist();
            SWIFT.edd.init();
            if (s.hasClass("has-portfolio")) {
                SWIFT.portfolio.init()
            }
            if (s.hasClass("has-portfolio-showcase")) {
                SWIFT.portfolio.portfolioShowcaseInit()
            }
            if (s.hasClass("has-blog")) {
                SWIFT.blog.init()
            }
            if (s.hasClass("has-infscroll")) {
                SWIFT.blog.infiniteScroll()
            }
            if (s.hasClass("has-galleries")) {
                SWIFT.galleries.init()
            }
            SWIFT.widgets.init();
            if (s.hasClass("has-team")) {
                SWIFT.teamMembers.init()
            }
            if (s.hasClass("has-carousel")) {
                SWIFT.carouselWidgets.init()
            }
            if (s.hasClass("has-parallax")) {
                SWIFT.parallax.init()
            }
            SWIFT.crowdfunding.init();
            SWIFT.reloadFunctions.init()
        }
    };
    SWIFT.onLoad = {
        init: function () {
            if (D.hasClass("sf-preloader")) {
                SWIFT.page.homePreloader()
            }
            if (s.hasClass("has-parallax")) {
                SWIFT.parallax.load()
            }
            if (s.hasClass("has-products") || D.hasClass("woocommerce-cart") || D.hasClass("woocommerce-account")) {
                SWIFT.woocommerce.load()
            }
            SWIFT.page.load();
            if (D.hasClass("page-transitions")) {
                SWIFT.page.fadePageIn()
            }
            SWIFT.widgets.load();
            if (s.hasClass("has-map")) {
                SWIFT.map.init();
                SWIFT.mapDirectory.init("", "", "");
                jQuery(document).on("click", "#directory-search-button", function () {
                    jQuery(".directory-search-form").submit()
                });
                jQuery("ul.nav-tabs li a").click(function () {
                    var an = jQuery(this).attr("href");
                    if (jQuery(an).find(".spb_gmaps_widget").length > 0) {
                        SWIFT.map.init();
                        SWIFT.mapDirectory.init("", "", "")
                    }
                })
            }
            SWIFT.reloadFunctions.load();
            if (s.hasClass("stickysidebars") && jQuery(".sticky-widget").length > 0) {
                SWIFT.page.stickyWidget()
            }
        }
    };
    jQuery(document).ready(SWIFT.onReady.init);
    jQuery(window).load(SWIFT.onLoad.init)
})(jQuery);
window.onpageshow = function (a) {
    if (a.persisted && jQuery("body").hasClass("page-transitions")) {
        window.location.reload()
    }
};
window.onunload = function () {
    if (jQuery("body").hasClass("page-transitions")) {
        var a = 1000;
        if (jQuery(".parallax-window-height").length > 0) {
            a = 1200
        }
        jQuery("body").addClass("page-fading-in");
        jQuery("#site-loading").css("opacity", "0");
        setTimeout(function () {
            jQuery("#site-loading").css("display", "none");
            jQuery("body").removeClass("page-fading-in")
        }, a)
    }
};