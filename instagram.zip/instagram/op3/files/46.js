jQuery(function () {
    initPortfolioGallery();
	// initComingSoonCountDown();
	initFoundation();
	initFooterInstagram();
	initPaginationCurrentClass();
	initAnimateBLock();
});

$(window).load(function()
{
	initAjaxLoadMoreFunction();
    $('.loaded-block').fadeOut(); 
});

 function initAnimateBLock() {
	var condition = $('.animateBlockHolder').size()
		// && false
		;init(condition);

	function init(condition) {
		if(condition || condition == null) {
			$(window).load(function(){
				$('.animateBlockHolder').viewportChecker({
					classToAdd: 'animate_start',
					offset: '10%'
				});
			});
		}
	}
}

function initPaginationCurrentClass() {
    var condition = $('.pagination').size()
        // && false
    ;init(condition);

    function init(condition) {
        if(condition || condition == null) {
            $('.pagination .active').addClass('current');
        }
    }
}

function initFooterInstagram()
{
	var userId = $('#instafeed').data('user_id');
	var clientId = $('#instafeed').data('client_id');
	var accessToken = $('#instafeed').data('access_token');
	var feed = new Instafeed({
		get: 'user',
		clientId: clientId,
		accessToken : accessToken,
		userId : userId,
		resolution : 'low_resolution',
		limit : 8,
		after : function()
		{
			if ( typeof window.instgrm !== 'undefined' ) {
				window.instgrm.Embeds.process();
			}
		},
		template: '<li class="col"><a target="_blank" href="{{link}}"><img src="{{image}}" alt="image description" width="85" height="85"></a></li>'
	});
	feed.run();
}

function initFoundation() {
	jQuery(document).foundation();

	$(function() {
		$('.search')
		  .bind('click', function(event) {
			$(".search-field").toggleClass("expand-search");
	  
			// if the search field is expanded, focus on it
			if ($(".search-field").hasClass("expand-search")) {
			  $(".search-field").focus();
			}
		  })
	  });
}

/*Coming Soon*/
// function initComingSoonCountDown() {
//     var condition = $('.comingSoonTimerHolder').size()
//         // && false
//     ;init(condition);

//     function init(condition) {
//         if(condition || condition == null) {
//             $('.comingSoonTimerHolder').countdowntimer({
//                 dateAndTime : "2019/06/06 00:00:00",
//                 size : "lg",
//                 regexpMatchFormat : "([0-9]{1,3}):([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})",
//                 regexpReplaceWith : '<div class="column"> <div class="holder"> <span>$1</span> <p>days</p></div></div><div class="column"> <div class="holder"> <span>$2</span> <p>hours</p></div></div><div class="column"> <div class="holder"> <span>$3</span> <p>minutes</p></div></div><div class="column"> <div class="holder"> <span>$4</span> <p>seconds</p></div></div>'
//             });
//         }
//     }
// }
/*End Coming Soon*/

function initAjaxLoadMoreFunction()
{
	var condition = $('.ajaxListHolder').size()
	    // && false
	;init(condition);

	function init(condition)
	{
	    if(condition || condition == null)
	    {
			var $container = $('.ajaxListHolder');

			if($container.find('.next').length)
			{
				$('.loadMoreBtn').attr('href', $container.find('.next a').attr('href'));
				$container.find('.pagination').remove();
			}
			else
			{
				$('.loadMoreBtn').hide();
			}

			$container.isotope(
				{
					itemSelector: '.load-item',
					animationEngine: 'best-available',
					transitionDuration : '0.6s'
				});

			$('.filterBTNHolder a').on( 'click', function()
			{
				var _this = $(this);
				var filterValue = _this.attr('data-filter');

				$('.filterBTNHolder li').removeClass('active');
				_this.closest('li').addClass('active');

				$container.isotope({ filter: filterValue });

				return false;
			});

			$('.loadMoreBtn').click(function()
			{
				var _this = $(this);
				var _href = _this.attr('href');

				$.ajax({
					url: _href,
					success: function(data){
						var requiredObject =  $('div.ajaxListHolder', data);
						var _items = requiredObject.find('.load-item');
						var _nextPageLink = requiredObject.find('.next');

						if(_nextPageLink.length)
						{
							$('.loadMoreBtn').attr('href', _nextPageLink.find('a').attr('href'));
						}
						else
						{
							$('.loadMoreBtn').hide();
						}

						$container.append( _items ).isotope( 'appended', _items ).isotope('layout');

						setTimeout(function()
						{
							$('.filterBTNHolder .active a').trigger('click');
						},500);
					}
				});

				// $container.isotope();

				return false;
			});
	    }
	}
}


 function initPortfolioGallery() {
    var condition = $('.portfolioGalleryHolder').size()
        // && false
        ;init(condition);

    function init(condition) {
        if(condition || condition == null) {
            var $grid = $('.portfolioGalleryHolder').masonry({
                itemSelector: '.cell',
                percentPosition: true,
                originLeft :true,
                originTop : true
            });

            $grid.imagesLoaded().progress( function() {
                $grid.masonry('layout');
            });

            $('.portfolioGalleryHolder a').fancybox({
                nextEffect : 'fade',
                prevEffect : 'fade'

            });
        }
    }
}

// Generated by CoffeeScript 1.9.3
(function(){var e;e=function(){function e(e,t){var n,r;this.options={target:"instafeed",get:"popular",resolution:"thumbnail",sortBy:"none",links:!0,mock:!1,useHttp:!1};if(typeof e=="object")for(n in e)r=e[n],this.options[n]=r;this.context=t!=null?t:this,this.unique=this._genKey()}return e.prototype.hasNext=function(){return typeof this.context.nextUrl=="string"&&this.context.nextUrl.length>0},e.prototype.next=function(){return this.hasNext()?this.run(this.context.nextUrl):!1},e.prototype.run=function(t){var n,r,i;if(typeof this.options.clientId!="string"&&typeof this.options.accessToken!="string")throw new Error("Missing clientId or accessToken.");if(typeof this.options.accessToken!="string"&&typeof this.options.clientId!="string")throw new Error("Missing clientId or accessToken.");return this.options.before!=null&&typeof this.options.before=="function"&&this.options.before.call(this),typeof document!="undefined"&&document!==null&&(i=document.createElement("script"),i.id="instafeed-fetcher",i.src=t||this._buildUrl(),n=document.getElementsByTagName("head"),n[0].appendChild(i),r="instafeedCache"+this.unique,window[r]=new e(this.options,this),window[r].unique=this.unique),!0},e.prototype.parse=function(e){var t,n,r,i,s,o,u,a,f,l,c,h,p,d,v,m,g,y,b,w,E,S,x,T,N,C,k,L,A,O,M,_,D;if(typeof e!="object"){if(this.options.error!=null&&typeof this.options.error=="function")return this.options.error.call(this,"Invalid JSON data"),!1;throw new Error("Invalid JSON response")}if(e.meta.code!==200){if(this.options.error!=null&&typeof this.options.error=="function")return this.options.error.call(this,e.meta.error_message),!1;throw new Error("Error from Instagram: "+e.meta.error_message)}if(e.data.length===0){if(this.options.error!=null&&typeof this.options.error=="function")return this.options.error.call(this,"No images were returned from Instagram"),!1;throw new Error("No images were returned from Instagram")}this.options.success!=null&&typeof this.options.success=="function"&&this.options.success.call(this,e),this.context.nextUrl="",e.pagination!=null&&(this.context.nextUrl=e.pagination.next_url);if(this.options.sortBy!=="none"){this.options.sortBy==="random"?M=["","random"]:M=this.options.sortBy.split("-"),O=M[0]==="least"?!0:!1;switch(M[1]){case"random":e.data.sort(function(){return.5-Math.random()});break;case"recent":e.data=this._sortBy(e.data,"created_time",O);break;case"liked":e.data=this._sortBy(e.data,"likes.count",O);break;case"commented":e.data=this._sortBy(e.data,"comments.count",O);break;default:throw new Error("Invalid option for sortBy: '"+this.options.sortBy+"'.")}}if(typeof document!="undefined"&&document!==null&&this.options.mock===!1){m=e.data,A=parseInt(this.options.limit,10),this.options.limit!=null&&m.length>A&&(m=m.slice(0,A)),u=document.createDocumentFragment(),this.options.filter!=null&&typeof this.options.filter=="function"&&(m=this._filter(m,this.options.filter));if(this.options.template!=null&&typeof this.options.template=="string"){f="",d="",w="",D=document.createElement("div");for(c=0,N=m.length;c<N;c++){h=m[c],p=h.images[this.options.resolution];if(typeof p!="object")throw o="No image found for resolution: "+this.options.resolution+".",new Error(o);E=p.width,y=p.height,b="square",E>y&&(b="landscape"),E<y&&(b="portrait"),v=p.url,l=window.location.protocol.indexOf("http")>=0,l&&!this.options.useHttp&&(v=v.replace(/https?:\/\//,"//")),d=this._makeTemplate(this.options.template,{model:h,id:h.id,link:h.link,type:h.type,image:v,width:E,height:y,orientation:b,caption:this._getObjectProperty(h,"caption.text"),likes:h.likes.count,comments:h.comments.count,location:this._getObjectProperty(h,"location.name")}),f+=d}D.innerHTML=f,i=[],r=0,n=D.childNodes.length;while(r<n)i.push(D.childNodes[r]),r+=1;for(x=0,C=i.length;x<C;x++)L=i[x],u.appendChild(L)}else for(T=0,k=m.length;T<k;T++){h=m[T],g=document.createElement("img"),p=h.images[this.options.resolution];if(typeof p!="object")throw o="No image found for resolution: "+this.options.resolution+".",new Error(o);v=p.url,l=window.location.protocol.indexOf("http")>=0,l&&!this.options.useHttp&&(v=v.replace(/https?:\/\//,"//")),g.src=v,this.options.links===!0?(t=document.createElement("a"),t.href=h.link,t.appendChild(g),u.appendChild(t)):u.appendChild(g)}_=this.options.target,typeof _=="string"&&(_=document.getElementById(_));if(_==null)throw o='No element with id="'+this.options.target+'" on page.',new Error(o);_.appendChild(u),a=document.getElementsByTagName("head")[0],a.removeChild(document.getElementById("instafeed-fetcher")),S="instafeedCache"+this.unique,window[S]=void 0;try{delete window[S]}catch(P){s=P}}return this.options.after!=null&&typeof this.options.after=="function"&&this.options.after.call(this),!0},e.prototype._buildUrl=function(){var e,t,n;e="https://api.instagram.com/v1";switch(this.options.get){case"popular":t="media/popular";break;case"tagged":if(!this.options.tagName)throw new Error("No tag name specified. Use the 'tagName' option.");t="tags/"+this.options.tagName+"/media/recent";break;case"location":if(!this.options.locationId)throw new Error("No location specified. Use the 'locationId' option.");t="locations/"+this.options.locationId+"/media/recent";break;case"user":if(!this.options.userId)throw new Error("No user specified. Use the 'userId' option.");t="users/"+this.options.userId+"/media/recent";break;default:throw new Error("Invalid option for get: '"+this.options.get+"'.")}return n=e+"/"+t,this.options.accessToken!=null?n+="?access_token="+this.options.accessToken:n+="?client_id="+this.options.clientId,this.options.limit!=null&&(n+="&count="+this.options.limit),n+="&callback=instafeedCache"+this.unique+".parse",n},e.prototype._genKey=function(){var e;return e=function(){return((1+Math.random())*65536|0).toString(16).substring(1)},""+e()+e()+e()+e()},e.prototype._makeTemplate=function(e,t){var n,r,i,s,o;r=/(?:\{{2})([\w\[\]\.]+)(?:\}{2})/,n=e;while(r.test(n))s=n.match(r)[1],o=(i=this._getObjectProperty(t,s))!=null?i:"",n=n.replace(r,function(){return""+o});return n},e.prototype._getObjectProperty=function(e,t){var n,r;t=t.replace(/\[(\w+)\]/g,".$1"),r=t.split(".");while(r.length){n=r.shift();if(!(e!=null&&n in e))return null;e=e[n]}return e},e.prototype._sortBy=function(e,t,n){var r;return r=function(e,r){var i,s;return i=this._getObjectProperty(e,t),s=this._getObjectProperty(r,t),n?i>s?1:-1:i<s?1:-1},e.sort(r.bind(this)),e},e.prototype._filter=function(e,t){var n,r,i,s,o;n=[],r=function(e){if(t(e))return n.push(e)};for(i=0,o=e.length;i<o;i++)s=e[i],r(s);return n},e}(),function(e,t){return typeof define=="function"&&define.amd?define([],t):typeof module=="object"&&module.exports?module.exports=t():e.Instafeed=t()}(this,function(){return e})}).call(this);