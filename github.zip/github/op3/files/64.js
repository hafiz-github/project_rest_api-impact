var gFirstRepoCreated = false;

// Check for auth info in URL params.
var urlParams = window.location.search.substring(1).split('&');
var username = null;
var authCode = null;
for (var i = urlParams.length - 1; i >= 0; i--) {
	var param = urlParams[i];
	var args = param.split('=');
	if (args[0] == 'accessToken') {
		authCode = authCode || args[1].replace('/', '');
	}
	if (args[0] == 'username') {
		username = username || args[1].replace('/', '');
	}
}
// Help the user create the token if they don't have one.
if (authCode == null || username == null) {
	window.location = 'auth.html';
}

var ajaxHeaders = {'Authorization': 'Basic ' + btoa(username + ':' + authCode)};

var githubUrl = "https://api.github.com/";

function debugAjaxError(response) {
	console.log('Ajax error:', response.responseText, response);
}

var Commit = function(sha, author, date, message, parents) {
	this.sha = sha;
	this.author = author;
	this.date = date;
	this.message = message;
	this.parents = parents;
}

var Repository = function(userName, repoName, description) {
	this.userName = userName;
	this.repoName = repoName;
	this.fullName = repoName + '\nby ' + userName;
	this.description = description;
	this.relatedRepos = [];
	this.commits = [];
	this.fetchLanguages();
	this.texture = 'slate';
}

Repository.prototype.fetchRelated = function(quantity, isAsync) {
	if(quantity <= 0) return;
	
	var repo = this;
	if (!repo.description) {
		console.log('This repository does not have a description; unable to find related repositories.');
		return;
	}
	var repoWords = repo.description.split(' ');
	var query = getQueryFromWords(repoWords);

	var searchApiUrl = githubUrl + 'search/repositories';
	var relatedRepos = [];
	$.ajax({
		type: "GET",
		url: searchApiUrl,
		async: isAsync,
		data: {q: query},
		headers: ajaxHeaders,
		success: function(response) {
			quantity = Math.min(quantity, response.items.length);

			var excludeIndex = -1;
			var endIndex = quantity;
			for(var i = 0; i < quantity; i++) {
				if(response.items[i].name === repo.name) {
					excludeIndex = i;
					endIndex++;
					break;
				}
			}

			for(var i = 0; i < endIndex; i++){
				if(i !== excludeIndex) {
					var tempRepo = response.items[i];
					var currentRelated = new Repository(tempRepo.owner.login, tempRepo.name, tempRepo.description);
					currentRelated.fetchCommits(true);
					currentRelated.fetchLanguages(true);
					repo.relatedRepos.push(currentRelated);
				}
			}
		},
		error: debugAjaxError
	});

}

Repository.prototype.fetchCommits = function(isAsync) {
	var repo = this;
	var fetchAsync = isAsync || false;
	var userName = repo.userName;
	var repoName = repo.repoName;
	var commitsApiUrl = githubUrl + 'repos/' + userName + '/' + repoName + '/commits';
	var tempCommits;
	$.ajax({
		type: "GET",
		url: commitsApiUrl,
		async: fetchAsync,
		headers: ajaxHeaders,
		success: function(response) {
			tempCommits = response;
			var returnCommits = [];
			for(var i = 0; i < tempCommits.length; i++){
				var c = tempCommits[i];
				returnCommits.push(new Commit(c.sha, c.commit.committer.name, c.commit.committer.date, c.commit.message, c.parents));
			}

			repo.commits = returnCommits;
			repo.updateCommitParents();
			repo.commitTree = repo.commits[0];
		},
		error: debugAjaxError
	});
}

Repository.prototype.updateCommitParents = function(isAsync) {
	var commits = this.commits;
	var rootCommit = commits[0];
	for(var i = 0; i < commits.length; i++) {
		var currentCommit = commits[i];
		var currentParents = currentCommit.parents;
		var updatedParents = [];
		for(var j = 0; j < currentParents.length; j++) {
			var tempParent = currentParents[j];
			for(var k = 0; k < commits.length; k++) {
				if(commits[k].sha === tempParent.sha){
					updatedParents.push(commits[k]);
					break;
				}
			}
		}
		currentCommit.parents = updatedParents;
	}
}


Repository.prototype.fetchLanguages = function(isAsync) {
	var repo = this;
	var userName = repo.userName;
	var repoName = repo.repoName;
	var langsApiUrl = githubUrl + 'repos/' + userName + '/' + repoName + '/languages';
	$.ajax({
		type: "GET",
		url: langsApiUrl,
		async: isAsync,
		headers: ajaxHeaders,
		success: function(response) {
			var languages = [];
			var currentMainLang;
			var currentMax = 0;
			for (var key in response) {
				if(response.hasOwnProperty(key)) {
					languages.push(key);
					if(response[key] > currentMax) {
						currentMax = response[key];
						currentMainLang = key;
					}
				}
			}
			repo.languages = languages;
			repo.mainLanguage = currentMainLang;

			repo.updateTexture();
		},
		error: debugAjaxError
	});
}

Repository.prototype.updateTexture = function() {
	for (var i = 0; i < this.languages.length; i++) {
		// Use the lang->texture map in room-navigation.js.
		var tex = langTextureMap[this.languages[i]];
		if (tex) {
			this.texture = tex;
			break;
		}
	}
}

var langTextureMap = {
	'JavaScript': 'bricks',
	'Objective-C': 'slat',
	'C': 'rustywall',
	'Ruby': 'logs',
	'Shell': 'rockgrid',
	'PHP': 'rustic',
};

function makeFirstRepository() {
	// TODO: start with a random repo

	var repo = getRandomRepository();
	gInitRepoFetched = true;
	repo.fetchCommits(false);

	return repo;
}

function fillRandomRepository(done){
	var randomNumber = randomIntBetween(1, 25000000).toString();

	//var randomNumber = 100000;
	$.ajax({
		type: "GET",
		url: githubUrl + "rate_limit",
		data: {since: randomNumber},
		headers: ajaxHeaders,
		success: function(response) {
			console.log(response.rate);
		},
		error: debugAjaxError
	});

	$.ajax({
		type: "GET",
		url: githubUrl + "repositories",
		data: {since: randomNumber},
		headers: ajaxHeaders,
		success: function(response) {
			var response = response[0];
			var tempRepo = new Repository(
				response.owner.login,
				response.name,
				response.description);
			done(tempRepo);
		},
		error: debugAjaxError
	});
}

glInitFunctions.push(function() {
	// Every 100 ms, kick off requests to fetch related repository information
	// if it hasn't been acquired for the current room.
	setInterval(fetchRelatedRepositories, 100);
});

var lastFetchedRoom = null;

function fetchRelatedRepositories() {
	if (lastFetchedRoom != gCurRoom) {
		lastFetchedRoom = gCurRoom;

		if (gCurRoom.relatedRepos.length == 0) {
			gCurRoom.fetchRelated(5, true);
		}
	}
}

function randomIntBetween(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}

function getQueryFromWords(words) {
	var query = "";
	for(var i = 0; i < 5; i++) {
		query = words[randomIntBetween(0, words.length - 1)];
		if(query.length > 3) break;
	}
	return query;
}
