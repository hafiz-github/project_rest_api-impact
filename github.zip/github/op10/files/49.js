// Github.js 0.7.0
// (c) 2012 Michael Aufreiter, Development Seed
// Github.js is freely distributable under the MIT license.
// For all details and documentation:
// http://substance.io/michael/github

(function() {
  var Github;
  var API_URL = 'https://api.github.com';

  Github = window.Github = function(options) {

    // HTTP Request Abstraction
    // =======
    // 
    // I'm not proud of this and neither should you be if you were responsible for the XMLHttpRequest spec.

    function _request(method, path, data, cb, dataType) {

    var raw = dataType == "raw";
    // Work-around for demo mode
    if (options.token == null || options.token == undefined) {
        function decodeMDContent(data) {
          for (d in data) {
            if (d == 'data') {
              var splitted = data[d].content.split('\n');
              var decoded = "";
              for (s in splitted) {
                decoded += $.base64.decode(splitted[s]);
              }
              return decoded;
            }
          }
        };

        $.ajax({
            url: API_URL + path,
            type: method,
            dataType: "jsonp",
            success: function(obj) {
              cb(null, raw ? decodeMDContent(obj) : obj['data']);
            },
            error: function(err) {
              cb({request: this, error: this.status});
            }
        });
        return;
    } // Work-around for local pages loading

      function getURL() {
        var url = API_URL + path;
        return url + ((/\?/).test(url) ? "&" : "?") + (new Date()).getTime();
      }

      var xhr = new XMLHttpRequest();
      if (!raw) {xhr.dataType = "json";}

      xhr.open(method, getURL());
      xhr.onreadystatechange = function () {
        if (this.readyState == 4) {
          if (this.status >= 200 && this.status < 300 || this.status === 304) {
            // Extract x-rate-limit-remaning
            Github.xRateLimitRemaining = this.getResponseHeader('X-RateLimit-Remaining');
            cb(null, raw ? this.responseText : this.responseText ? JSON.parse(this.responseText) : true);
          } else {
            cb({request: this, error: this.status});
          }
        }
      };

      if (raw) {
        xhr.setRequestHeader('Accept','application/vnd.github.v3.raw');
      }
      else {
        xhr.setRequestHeader('Accept','application/vnd.github.v3+json');
      }
      xhr.setRequestHeader('Content-Type','application/json');


      if (
         (options.auth == 'oauth' && options.token) ||
         (options.auth == 'basic' && options.username && options.password)
         ) {
           xhr.setRequestHeader('Authorization',options.auth == 'oauth'
             ? 'token '+ options.token
             : 'Basic ' + Base64.encode(options.username + ':' + options.password)
           );
         }
      data ? xhr.send(JSON.stringify(data)) : xhr.send();
    }

    // User API
    // =======

    Github.User = function() {
      this.repos = function(cb) {
        _request("GET", "/user/repos?type=all&per_page=1000&sort=updated", null, function(err, res) {
          cb(err, res);
        });
      };

      // List user organizations
      // -------

      this.orgs = function(cb) {
        _request("GET", "/user/orgs", null, function(err, res) {
          cb(err, res);
        });
      };

      // List authenticated user's gists
      // -------

      this.gists = function(cb) {
        _request("GET", "/gists", null, function(err, res) {
          cb(err,res);
        });
      };

      // Show user information
      // -------

      this.show = function(username, cb) {
        var command = username ? "/users/"+username : "/user";

        _request("GET", "/users/"+username, null, function(err, res) {
          cb(err, res);
        });
      };

      // List user repositories
      // -------

      this.userRepos = function(username, cb) {
        _request("GET", "/users/"+username+"/repos?type=all&per_page=1000&sort=updated", null, function(err, res) {
          cb(err, res);
        });
      };

      // List a user's gists
      // -------

      this.userGists = function(username, cb) {
        _request("GET", "/users/"+username+"/gists", null, function(err, res) {
          cb(err,res);
        });
      };

      // List organization repositories
      // -------

      this.orgRepos = function(orgname, cb) {
        _request("GET", "/orgs/"+orgname+"/repos?type=all&per_page=1000&sort=updated&direction=desc", null, function(err, res) {
          cb(err, res);
        });
      };

      // Follow user
      // -------

      this.follow = function(username, cb) {
        _request("PUT", "/user/following/"+username, null, function(err, res) {
          cb(err, res);
        });
      };

      // Unfollow user
      // -------

      this.unfollow = function(username, cb) {
        _request("DELETE", "/user/following/"+username, null, function(err, res) {
          cb(err, res);
        });
      };
    };


    // Repository API
    // =======

    Github.Repository = function(options) {
      var repo = options.name;
      var user = options.user;
      
      var that = this;
      var repoPath = "/repos/" + user + "/" + repo;

      var currentTree = {
        "branch": null,
        "sha": null
      };

      // Uses the cache if branch has not been changed
      // -------

      function updateTree(branch, cb) {
        if (branch === currentTree.branch && currentTree.sha) return cb(null, currentTree.sha);
        that.getRef("heads/"+branch, function(err, sha) {
          currentTree.branch = branch;
          currentTree.sha = sha;
          cb(err, sha);
        });
      }

      // Get a particular reference
      // -------

      this.getRef = function(ref, cb) {
        _request("GET", repoPath + "/git/refs/" + ref, null, function(err, res) {
          if (err) return cb(err);
          cb(null, res.object.sha);
        });
      };

      // Create a new reference
      // --------
      //
      // {
      //   "ref": "refs/heads/my-new-branch-name",
      //   "sha": "827efc6d56897b048c772eb4087f854f46256132"
      // }

      this.createRef = function(options, cb) {
        _request("POST", repoPath + "/git/refs", options, cb);
      };

      // Delete a reference
      // --------
      // 
      // repo.deleteRef('heads/gh-pages')
      // repo.deleteRef('tags/v1.0')

      this.deleteRef = function(ref, cb) {
        _request("DELETE", repoPath + "/git/refs/"+ref, options, cb);
      };

      // List all branches of a repository
      // -------

      this.listBranches = function(cb) {
        _request("GET", repoPath + "/branches", null, function(err, res) {
          if (err) return cb(err);
          cb(null, res);
        });
      };

      // List all tags of a repository
      // -------

      this.listTags = function(cb) {
        _request("GET", repoPath + "/tags", null, function(err, res) {
          if (err) return cb(err);
          cb(null, res);
        });
      };

      // Retrieve the contents of a blob
      // -------

      this.getBlob = function(sha, cb) {
        _request("GET", repoPath + "/git/blobs/" + sha, null, cb, 'raw');
      };

      // For a given file path, get the corresponding sha (blob for files, tree for dirs)
      // -------

      this.getSha = function(branch, path, cb) {
        // Just use head if path is empty
        if (path === "") return that.getRef("heads/"+branch, cb);
        that.getTree(branch+"?recursive=true", function(err, tree) {
          var file = _.select(tree, function(file) {
            return file.path === path;
          })[0];
          cb(null, file ? file.sha : null);
        });
      };

      // Retrieve the tree a commit points to
      // -------

      this.getTree = function(tree, cb) {
        _request("GET", repoPath + "/git/trees/"+tree, null, function(err, res) {
          if (err) return cb(err);
          cb(null, res.tree);
        });
      };

      // Post a new blob object, getting a blob SHA back
      // -------

      this.postBlob = function(content, cb) {
        if (typeof(content) === "string") {
          content = {
            "content": content,
            "encoding": "utf-8"
          };
        }

        _request("POST", repoPath + "/git/blobs", content, function(err, res) {
          if (err) return cb(err);
          cb(null, res.sha);
        });
      };

      // Update an existing tree adding a new blob object getting a tree SHA back
      // -------

      this.updateTree = function(baseTree, path, blob, cb) {
        var data = {
          "base_tree": baseTree,
          "tree": [
            {
              "path": path,
              "mode": "100644",
              "type": "blob",
              "sha": blob
            }
          ]
        };
        _request("POST", repoPath + "/git/trees", data, function(err, res) {
          if (err) return cb(err);
          cb(null, res.sha);
        });
      };

      // Update an existing tree adding a new blob object getting a tree SHA back
      // -------

      this.removeTree = function(baseTree, cb) {
        var data = {
          "tree": baseTree
        };
        _request("POST", repoPath + "/git/trees", data, function(err, res) {
          if (err) return cb(err);
          cb(null, res.sha);
        });

      };


      this.multipleUpdateTree = function(baseTree, blobs, cb) {
        var p, data, hasRemove = false;

        for (p in blobs) {
            if (blobs[p] == null) {
                hasRemove = true;
                break;
            }
        }
        
        if (false) {
            // Extrac all tree recursibly and remove blob(s) from it
            that.getTree(baseTree+"?recursive=true", function(err, tree) {
              var iter;
              var newTree = tree;
              // Update Tree
              for (iter=0; iter<newTree.length; ++iter) {
                // update tree
                if (newTree[iter].type == "tree") {
                  delete newTree[iter]["sha"];
                  continue;
                }
                // remove file
                if (blobs[newTree[iter].path] === null) {
                  delete newTree.splice(iter, 1);
                  delete blobs[newTree[iter].path];
                  --iter;
                  continue;
                }
                if (blobs[newTree[iter].path] != undefined) {
                  newTree[iter].sha = blobs[newTree[iter].path];
                  delete blobs[newTree[iter].path];
                }
              }
              
              // Expand tree with newly created
              // context blobs
              for (iter in blobs) {
                  var magic = "100644";
                  if (blobs[iter].type == "tree") {
                    magic = "040000";
                  }
                  newTree.push({
                    "path": iter,
                    "mode": magic,
                    "type": blobs[iter].type,
                    "sha": blobs[iter]
                  });
              }

              that.postTree(newTree, function(err, res) {
                if (err) return cb(err);
                cb(null, res);
              });
            });
        }
        else {
          data = {
            "base_tree": baseTree,
            "tree": [
            ]
          };

          for (p in blobs) {
            var item;
            // Remove item if content is empty
            if (blobs[p].sha != null) {
              var magic = "100644";
              var treePath = p;
              if (blobs[p].type == "tree") {
                magic = "040000";
                treePath = treePath.substring(0, treePath.lastIndexOf("/")+1);
              }
              item = {
                "path": treePath,
                "mode": magic,
                "type": blobs[p].type,
                "sha": blobs[p].sha
              };
              data["tree"].push(item);
            }
            else {
                for (var xxx in blobs[p].tree) {
                    data["tree"].push(blobs[p].tree[xxx]);
                }
/*              var subspl = p.split("/");
              if (subspl.length > 1) {
               item = {
                "path": subspl[0],
                "type": "tree",
                "mode": "040000",
                "sha":null
                };
                data["tree"].push(item);
              }
              item = {
                "path": p,
                "type": "blob",
                "mode": "100644",
                "content":null,
                "sha": blobs[p].rmsha
              };*/
            }
            
          }
          _request("POST", repoPath + "/git/trees", data, function(err, res) {
            if (err) return cb(err);
            cb(null, res.sha);
          });
        }
      };


      // Post a new tree object having a file path pointer replaced
      // with a new blob SHA getting a tree SHA back
      // -------

      this.postTree = function(tree, cb) {
        _request("POST", repoPath + "/git/trees", { "tree": tree }, function(err, res) {
          if (err) return cb(err);
          cb(null, res.sha);
        });
      };

      // Create a new commit object with the current commit SHA as the parent
      // and the new tree SHA, getting a commit SHA back
      // -------

      this.commit = function(parent, tree, message, cb) {
        var data = {
          "message": message,
          "author": {
            "name": options.username
          },
          "parents": [
            parent
          ],
          "tree": tree
        };

        _request("POST", repoPath + "/git/commits", data, function(err, res) {
          currentTree.sha = res.sha; // update latest commit
          if (err) return cb(err);
          cb(null, res.sha);
        });
      };

      // Update the reference of your head to point to the new commit SHA
      // -------

      this.updateHead = function(head, commit, cb) {
        _request("PATCH", repoPath + "/git/refs/heads/" + head, { "sha": commit }, function(err, res) {
          cb(err);
        });
      };

      // Show repository information
      // -------

      this.show = function(cb) {
        _request("GET", repoPath, null, cb);
      };

      // Get contents
      // --------

      this.contents = function(path, cb) {
        _request("GET", repoPath + "/contents/" + path, null, cb, "json");
      };

      this.deleteContents = function(branch, path, sha, cb) {
        _request("DELETE", repoPath + "/contents/"+path, {"message": "test commit", sha: sha, branch:branch, path:path}, cb, "jsonp");
      };

      // Fork repository
      // -------

      this.fork = function(cb) {
        _request("POST", repoPath + "/forks", null, cb);
      };

      // Create pull request
      // --------

      this.createPullRequest = function(options, cb) {
        _request("POST", repoPath + "/pulls", options, cb);
      };

      // Read file at given path
      // -------

      this.read = function(branch, path, cb) {
        that.getSha(branch, path, function(err, sha) {
          if (!sha) return cb("not found", null);
          that.getBlob(sha, function(err, content) {
            cb(err, content, sha);
          });
        });
      };

      // Remove a file from the tree
      // -------

      this.remove = function(branch, path, cb) {
        updateTree(branch, function(err, latestCommit) {
          that.getTree(latestCommit+"?recursive=true", function(err, tree) {
            // Update Tree
            var newTree = jQuery.reject(tree, function(ref) { return ref.path === path; });
            jQuery.each(newTree, function(ref) {
              if (ref.type === "tree") delete ref.sha;
            });

            that.postTree(newTree, function(err, rootTree) {
              that.commit(latestCommit, rootTree, 'Deleted '+path , function(err, commit) {
                that.updateHead(branch, commit, function(err) {
                  cb(err);
                });
              });
            });
          });
        });
      };

      // Move a file to a new location
      // -------

      this.move = function(branch, path, newPath, cb) {
        updateTree(branch, function(err, latestCommit) {
          that.getTree(latestCommit+"?recursive=true", function(err, tree) {
            // Update Tree
            _.each(tree, function(ref) {
              if (ref.path === path) ref.path = newPath;
              if (ref.type === "tree") delete ref.sha;
            });

            that.postTree(tree, function(err, rootTree) {
              that.commit(latestCommit, rootTree, 'Deleted '+path , function(err, commit) {
                that.updateHead(branch, commit, function(err) {
                  cb(err);
                });
              });
            });
          });
        });
      };

      // Write file contents to a given branch and path
      // -------

      this.write = function(branch, path, content, message, cb) {
        updateTree(branch, function(err, latestCommit) {
          if (err) return cb(err);
          that.postBlob(content, function(err, blob) {
            if (err) return cb(err);
            that.updateTree(latestCommit, path, blob, function(err, tree) {
              if (err) return cb(err);
              that.commit(latestCommit, tree, message, function(err, commit) {
                if (err) return cb(err);
                that.updateHead(branch, commit, cb);
              });
            });
          });
        });
      };

      // Write multiple file contents to a given branch and path
      // -------

      this.multipleCommit = function(branch, mapPathContent, message, cb, statusCallback) {
        statusCallback("Fetch HEAD of the " + branch);
        updateTree(branch, function(err, latestCommit) {
          // Failed to update the head of the branch
          if (err) return cb(err);

          statusCallback("HEAD of the " + branch + " is ok");

          var blobContentList = mapPathContent;
          var blobShaList = {};
          var nextBlob;
          
          function nextBlobOrTree(err, blob, tree) {
              if (err) return cb(err);
              
              if (nextBlob) {
                  statusCallback("Done " + nextBlob.path);
                  if (tree) {
                      blobShaList[nextBlob.path] = {sha:blob, type:'tree'};
                  }
                  else {
                    blobShaList[nextBlob.path] = {sha:blob, type:'blob'};
                  }
              }
              
              nextBlob =  blobContentList.shift();
              if (nextBlob) {
                  if (nextBlob.content) {
                    statusCallback("Transmitting  " + nextBlob.path);
                    that.postBlob(nextBlob.content, nextBlobOrTree);
                  }
                  else {
                    // Remove blob from the tree
                    for (var xxx in nextBlob.tree) {
                      if (nextBlob.tree[xxx].sha == nextBlob.sha) {
                              delete nextBlob.tree[xxx];
                              nextBlob.tree.splice(xxx, 1);
                      }
                    }
                    that.removeTree(nextBlob.tree, function(err, blob) {
                       nextBlobOrTree(err, blob, 'tree');
                    });
                  }
              }
              else {
                  statusCallback("Updating the tree...");
                  that.multipleUpdateTree(latestCommit, blobShaList, function(err, tree) {
                     statusCallback("Done the tree update");
                     // Create a git commit
                     statusCallback("Commit creation ...");
                     that.commit(latestCommit, tree, message, function(err, commit) {
                       if (err) return cb(err);
                       // Move the commit result to the HEAD
                       statusCallback("Commit done");
                       statusCallback("Update the HEAD");
                       that.updateHead(branch, commit, cb);
                     });
                  });
              }
          };
          
          nextBlobOrTree();
        });
      };
    };



    // Gists API
    // =======

    Github.Gist = function(options) {
      var id = options.id;
      var gistPath = "/gists/"+id;

      // Read the gist
      // --------

      this.read = function(cb) {
        _request("GET", gistPath, null, function(err, gist) {
          cb(err, gist);
        });
      };


      // Delete the gist
      // --------

      this.delete = function(cb) {
        _request("DELETE", gistPath, null, function(err,res) {
          cb(err,res);
        });
      };

      // Fork a gist
      // --------

      this.fork = function(cb) {
        _request("POST", gistPath+"/fork", null, function(err,res) {
          cb(err,res);
        });
      };

      // Update a gist with the new stuff
      // --------

      this.update = function(options, cb) {
        _request("PATCH", gistPath, options, function(err,res) {
          cb(err,res);
        });
      };
    };

    // Top Level API
    // -------

    this.getRepo = function(user, repo) {
      return new Github.Repository({user: user, name: repo});
    };

    this.getUser = function() {
      return new Github.User();
    };

    this.getGist = function(id) {
      return new Github.Gist({id: id});
    };

    this.getRemainingLimit = function() {
        return this.xRateLimitRemaining;
    }
  };
}).call(this);
