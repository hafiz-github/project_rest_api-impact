
export default {
  "status": "finished",
  "data": {
    "headers": {
      "status": "200\n200 OK",
      "cache-control": "no-cache, no-store, must-revalidate, pre-check=0, post-check=0",
      "content-encoding": "gzip",
      "content-length": "32379",
      "content-security-policy": "script-src https://connect.facebook.net https://cm.g.doubleclick.net https://ssl.google-analytics.com https://graph.facebook.com https://twitter.com 'unsafe-eval' https://*.twimg.com https://api.twitter.com https://analytics.twitter.com https://publish.twitter.com https://ton.twitter.com https://syndication.twitter.com 'nonce-R/VHJUBAS+GX6DU5pZuA+w==' https://www.google.com https://t.tellapart.com https://platform.twitter.com https://www.google-analytics.com blob: 'self'; frame-ancestors 'self'; font-src https://twitter.com https://*.twimg.com data: https://ton.twitter.com https://fonts.gstatic.com https://maxcdn.bootstrapcdn.com https://netdna.bootstrapcdn.com 'self'; media-src https://rmpdhdsnappytv-vh.akamaihd.net https://prod-video-eu-central-1.pscp.tv https://prod-video-ap-south-1.pscp.tv https://v.cdn.vine.co https://dwo3ckksxlb0v.cloudfront.net https://twitter.com https://prod-video-us-east-2.pscp.tv https://prod-video-cn-north-1.pscp.tv https://amp.twimg.com https://smmdhdsnappytv-vh.akamaihd.net https://*.twimg.com https://prod-video-eu-west-1.pscp.tv https://rmmdhdsnappytv-vh.akamaihd.net https://clips-media-assets.twitch.tv https://prod-video-ap-northeast-2.pscp.tv https://prod-video-us-west-2.pscp.tv https://prod-video-us-west-1.pscp.tv https://prod-video-ap-northeast-1.pscp.tv https://smdhdsnappytv-vh.akamaihd.net https://ton.twitter.com https://prod-video-eu-west-3.pscp.tv https://rmdhdsnappytv-vh.akamaihd.net https://mmdhdsnappytv-vh.akamaihd.net https://prod-video-ca-central-1.pscp.tv https://smpdhdsnappytv-vh.akamaihd.net https://prod-video-sa-east-1.pscp.tv https://mdhdsnappytv-vh.akamaihd.net https://prod-video-ap-southeast-2.pscp.tv https://mtc.cdn.vine.co https://prod-video-cn-northwest-1.pscp.tv https://prod-video-eu-west-2.pscp.tv https://dev-video-us-west-2.pscp.tv https://prod-video-us-east-1.pscp.tv blob: 'self' https://prod-video-ap-northeast-3.pscp.tv https://prod-video-ap-southeast-1.pscp.tv https://mpdhdsnappytv-vh.akamaihd.net https://dev-video-eu-west-1.pscp.tv; connect-src https://rmpdhdsnappytv-vh.akamaihd.net https://prod-video-eu-central-1.pscp.tv https://graph.facebook.com https://prod-video-ap-south-1.pscp.tv https://*.giphy.com https://dwo3ckksxlb0v.cloudfront.net https://prod-video-us-east-2.pscp.tv https://prod-video-cn-north-1.pscp.tv https://vmaprel.snappytv.com https://smmdhdsnappytv-vh.akamaihd.net https://*.twimg.com https://embed.pscp.tv https://api.twitter.com https://prod-video-eu-west-1.pscp.tv https://rmmdhdsnappytv-vh.akamaihd.net https://clips-media-assets.twitch.tv https://prod-video-ap-northeast-2.pscp.tv https://prod-video-us-west-2.pscp.tv https://pay.twitter.com https://prod-video-us-west-1.pscp.tv https://analytics.twitter.com https://vmap.snappytv.com https://*.twprobe.net https://prod-video-ap-northeast-1.pscp.tv https://smdhdsnappytv-vh.akamaihd.net https://prod-video-eu-west-3.pscp.tv https://syndication.twitter.com https://sentry.io https://rmdhdsnappytv-vh.akamaihd.net https://media.riffsy.com https://mmdhdsnappytv-vh.akamaihd.net https://prod-video-ca-central-1.pscp.tv https://embed.periscope.tv https://smpdhdsnappytv-vh.akamaihd.net https://prod-video-sa-east-1.pscp.tv https://vmapstage.snappytv.com https://upload.twitter.com https://proxsee.pscp.tv https://mdhdsnappytv-vh.akamaihd.net https://prod-video-ap-southeast-2.pscp.tv https://prod-video-cn-northwest-1.pscp.tv https://prod-video-eu-west-2.pscp.tv https://dev-video-us-west-2.pscp.tv https://prod-video-us-east-1.pscp.tv 'self' https://prod-video-ap-northeast-3.pscp.tv https://vmap.grabyo.com https://prod-video-ap-southeast-1.pscp.tv https://mpdhdsnappytv-vh.akamaihd.net https://dev-video-eu-west-1.pscp.tv; style-src https://fonts.googleapis.com https://twitter.com https://*.twimg.com https://translate.googleapis.com https://ton.twitter.com 'unsafe-inline' https://platform.twitter.com https://maxcdn.bootstrapcdn.com https://netdna.bootstrapcdn.com 'self'; object-src https://twitter.com https://pbs.twimg.com; default-src 'self' blob:; frame-src https://staticxx.facebook.com https://twitter.com https://*.twimg.com https://5415703.fls.doubleclick.net https://player.vimeo.com https://pay.twitter.com https://www.facebook.com https://ton.twitter.com https://syndication.twitter.com https://vine.co twitter: https://www.youtube.com https://platform.twitter.com https://upload.twitter.com https://s-static.ak.facebook.com https://4337974.fls.doubleclick.net https://8122179.fls.doubleclick.net 'self' https://donate.twitter.com; img-src https://graph.facebook.com https://*.giphy.com https://*.pscp.tv https://twitter.com https://*.twimg.com https://ad.doubleclick.net data: https://clips-media-assets.twitch.tv https://lumiere-a.akamaihd.net https://fbcdn-profile-a.akamaihd.net https://www.facebook.com https://ton.twitter.com https://*.fbcdn.net https://syndication.twitter.com https://media.riffsy.com https://www.google.com https://stats.g.doubleclick.net https://platform.twitter.com https://api.mapbox.com https://www.google-analytics.com blob: https://*.periscope.tv 'self'; report-uri https://twitter.com/i/csp_report?a=NVQWGYLXFVZXO2LGOQ%3D%3D%3D%3D%3D%3D&ro=false;",
      "content-type": "text/html;charset=utf-8",
      "date": "Wed, 04 Jul 2018 15:03:07 GMT",
      "expires": "Tue, 31 Mar 1981 05:00:00 GMT",
      "last-modified": "Wed, 04 Jul 2018 15:03:07 GMT",
      "pragma": "no-cache",
      "server": "tsa_f",
      "set-cookie": "fm=0; Expires=Wed, 04 Jul 2018 15:02:58 GMT; Path=/; Domain=.twitter.com; Secure; HTTPOnly\n_twitter_sess=BAh7CSIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCOaD0WVkAToMY3NyZl9p%250AZCIlMzgzMmU0OGZmY2ZmMmFlZWI3NTEwYzA1OWY2ZjViOTc6B2lkIiVlYTgz%250ANWY1Y2YwMzhiYjdjMDc4MWI2NmI1ZWMxMWI4OA%253D%253D--904b1ee5d2753c28956b13d836433b8b013b96db; Path=/; Domain=.twitter.com; Secure; HTTPOnly\npersonalization_id=\"v1_UIwSKjilXyGGo7g/h85kpg==\"; Expires=Fri, 03 Jul 2020 15:03:07 GMT; Path=/; Domain=.twitter.com\nguest_id=v1%3A153071658697800112; Expires=Fri, 03 Jul 2020 15:03:07 GMT; Path=/; Domain=.twitter.com\nct0=030646e0a5314ee01739fdd0e4b90630; Expires=Wed, 04 Jul 2018 21:03:07 GMT; Path=/; Domain=.twitter.com; Secure",
      "strict-transport-security": "max-age=631138519",
      "x-connection-hash": "f0cef776337fbfe2c9b2f21b9f27ab6d",
      "x-content-type-options": "nosniff",
      "x-frame-options": "SAMEORIGIN",
      "x-response-time": "190",
      "x-transaction": "0096b31e0098a9fb",
      "x-twitter-response-tags": "BouncerCompliant",
      "x-ua-compatible": "IE=edge,chrome=1",
      "x-xss-protection": "1; mode=block; report=https://twitter.com/i/xss_report"
    },
    "security": {
      "name": "twitter.com",
      "protocol": "TLS 1.2",
      "issuer": "DigiCert SHA2 Extended Validation Server CA"
    },
    "cookies": [
      {
        "name": "_gat",
        "value": "1",
        "domain": ".twitter.com",
        "path": "/",
        "expires": 1530716649,
        "size": 5,
        "httpOnly": false,
        "secure": false,
        "session": false
      },
      {
        "name": "_gid",
        "value": "GA1.2.2076532622.1530716589",
        "domain": ".twitter.com",
        "path": "/",
        "expires": 1530802989,
        "size": 31,
        "httpOnly": false,
        "secure": false,
        "session": false
      },
      {
        "name": "ct0",
        "value": "030646e0a5314ee01739fdd0e4b90630",
        "domain": ".twitter.com",
        "path": "/",
        "expires": 1530738187.271112,
        "size": 35,
        "httpOnly": false,
        "secure": true,
        "session": false
      },
      {
        "name": "guest_id",
        "value": "v1%3A153071658697800112",
        "domain": ".twitter.com",
        "path": "/",
        "expires": 1593788587.271081,
        "size": 31,
        "httpOnly": false,
        "secure": false,
        "session": false
      },
      {
        "name": "_ga",
        "value": "GA1.2.1342760267.1530716589",
        "domain": ".twitter.com",
        "path": "/",
        "expires": 1593788589,
        "size": 30,
        "httpOnly": false,
        "secure": false,
        "session": false
      },
      {
        "name": "personalization_id",
        "value": "\"v1_UIwSKjilXyGGo7g/h85kpg==\"",
        "domain": ".twitter.com",
        "path": "/",
        "expires": 1593788587.271027,
        "size": 47,
        "httpOnly": false,
        "secure": false,
        "session": false
      },
      {
        "name": "_twitter_sess",
        "value": "BAh7CSIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCOaD0WVkAToMY3NyZl9p%250AZCIlMzgzMmU0OGZmY2ZmMmFlZWI3NTEwYzA1OWY2ZjViOTc6B2lkIiVlYTgz%250ANWY1Y2YwMzhiYjdjMDc4MWI2NmI1ZWMxMWI4OA%253D%253D--904b1ee5d2753c28956b13d836433b8b013b96db",
        "domain": ".twitter.com",
        "path": "/",
        "expires": -1,
        "size": 298,
        "httpOnly": true,
        "secure": true,
        "session": true
      }
    ],
    "body": "<!DOCTYPE html><html lang=\"sv\" data-scribe-reduced-action-queue=\"true\"><head>\n    \n    \n    \n    \n    \n    \n    \n    <meta charset=\"utf-8\">\n      <script async=\"\" src=\"//www.google-analytics.com/analytics.js\"></script><script nonce=\"\">\n        !function(){window.initErrorstack||(window.initErrorstack=[]),window.onerror=function(r,i,n,o,t){r.indexOf(\"Script error.\")>-1||window.initErrorstack.push({errorMsg:r,url:i,lineNumber:n,column:o,errorObj:t})}}();\n      </script>\n    \n    \n  \n  <script id=\"bouncer_terminate_iframe\" nonce=\"\">\n    if (window.top != window) {\n  window.top.postMessage({'bouncer': true, 'event': 'complete'}, '*');\n}\n  </script>\n  <script id=\"resolve_inline_redirects\" nonce=\"\">\n    !function(){function n(){var n=window.location.href.match(/#(.)(.*)$/);return n&&\"!\"==n[1]&&n[2].replace(/^\\//,\"\")}function t(){var t=n();t&&window.location.replace(\"//\"+window.location.host+\"/\"+t)}t(),window.addEventListener?window.addEventListener(\"hashchange\",t,!1):window.attachEvent&&window.attachEvent(\"onhashchange\",t)}();\n  </script>\n  <script id=\"ttft_boot_data\" nonce=\"\">\n    window.ttftData={\"transaction_id\":\"0096b31e0098a9fb.d74e1b93200240c8\\u003c:00ebcd720059e76d\",\"server_request_start_time\":1530716586981,\"user_id\":null,\"is_ssl\":true,\"rendered_on_server\":true,\"is_tfe\":true,\"client\":\"macaw-swift\",\"tfe_version\":\"tsa_f\\/1.0.1\\/20180606.1803.b14e74d\",\"ttft_browser\":\"chrome\"};!function(){function t(t,n){window.ttftData&&!window.ttftData[t]&&(window.ttftData[t]=n)}function n(){return o?Math.round(w.now()+w.timing.navigationStart):(new Date).getTime()}var w=window.performance,o=w&&w.now;window.ttft||(window.ttft={}),window.ttft.recordMilestone||(window.ttft.recordMilestone=t),window.ttft.now||(window.ttft.now=n)}();\n  </script>\n  <script id=\"swift_action_queue\" nonce=\"\">\n    !function(){function e(e){if(e||(e=window.event),!e)return!1;if(e.timestamp=(new Date).getTime(),!e.target&&e.srcElement&&(e.target=e.srcElement),document.documentElement.getAttribute(\"data-scribe-reduced-action-queue\"))for(var t=e.target;t&&t!=document.body;){if(\"A\"==t.tagName)return;t=t.parentNode}return i(\"all\",o(e)),a(e)?(document.addEventListener||(e=o(e)),e.preventDefault=e.stopPropagation=e.stopImmediatePropagation=function(){},y?(v.push(e),i(\"captured\",e)):i(\"ignored\",e),!1):(i(\"direct\",e),!0)}function t(e){n();for(var t,r=0;t=v[r];r++){var a=e(t.target),i=a.closest(\"a\")[0];if(\"click\"==t.type&&i){var o=e.data(i,\"events\"),u=o&&o.click,c=!i.hostname.match(g)||!i.href.match(/#$/);if(!u&&c){window.location=i.href;continue}}a.trigger(e.event.fix(t))}window.swiftActionQueue.wasFlushed=!0}function r(){for(var e in b)if(\"all\"!=e)for(var t=b[e],r=0;r<t.length;r++)console.log(\"actionQueue\",c(t[r]))}function n(){clearTimeout(w);for(var e,t=0;e=h[t];t++)document[\"on\"+e]=null}function a(e){if(!e.target)return!1;var t=e.target,r=(t.tagName||\"\").toLowerCase();if(e.metaKey)return!1;if(e.shiftKey&&\"a\"==r)return!1;if(t.hostname&&!t.hostname.match(g))return!1;if(e.type.match(p)&&s(t))return!1;if(\"label\"==r){var n=t.getAttribute(\"for\");if(n){var a=document.getElementById(n);if(a&&f(a))return!1}else for(var i,o=0;i=t.childNodes[o];o++)if(f(i))return!1}return!0}function i(e,t){t.bucket=e,b[e].push(t)}function o(e){var t={};for(var r in e)t[r]=e[r];return t}function u(e){for(;e&&e!=document.body;){if(\"A\"==e.tagName)return e;e=e.parentNode}}function c(e){var t=[];e.bucket&&t.push(\"[\"+e.bucket+\"]\"),t.push(e.type);var r,n,a=e.target,i=u(a),o=\"\",c=e.timestamp&&e.timestamp-d;return\"click\"===e.type&&i?(r=i.className.trim().replace(/\\s+/g,\".\"),n=i.id.trim(),o=/[^#]$/.test(i.href)?\" (\"+i.href+\")\":\"\",a='\"'+i.innerText.replace(/\\n+/g,\" \").trim()+'\"'):(r=a.className.trim().replace(/\\s+/g,\".\"),n=a.id.trim(),a=a.tagName.toLowerCase(),e.keyCode&&(a=String.fromCharCode(e.keyCode)+\" : \"+a)),t.push(a+o+(n&&\"#\"+n)+(!n&&r?\".\"+r:\"\")),c&&t.push(c),t.join(\" \")}function f(e){var t=(e.tagName||\"\").toLowerCase();return\"input\"==t&&\"checkbox\"==e.getAttribute(\"type\")}function s(e){var t=(e.tagName||\"\").toLowerCase();return\"textarea\"==t||\"input\"==t&&\"text\"==e.getAttribute(\"type\")||\"true\"==e.getAttribute(\"contenteditable\")}for(var m,d=(new Date).getTime(),l=1e4,g=/^([^\\.]+\\.)*twitter\\.com$/,p=/^key/,h=[\"click\",\"keydown\",\"keypress\",\"keyup\"],v=[],w=null,y=!0,b={captured:[],ignored:[],direct:[],all:[]},k=0;m=h[k];k++)document[\"on\"+m]=e;w=setTimeout(function(){y=!1},l),window.swiftActionQueue={buckets:b,flush:t,logActions:r,wasFlushed:!1}}();\n  </script>\n  <script id=\"composition_state\" nonce=\"\">\n    !function(){function t(t){t.target.setAttribute(\"data-in-composition\",\"true\")}function n(t){t.target.removeAttribute(\"data-in-composition\")}document.addEventListener&&(document.addEventListener(\"compositionstart\",t,!1),document.addEventListener(\"compositionend\",n,!1))}();\n  </script>\n\n    <link rel=\"stylesheet\" href=\"https://abs.twimg.com/a/1530627074/css/t1/twitter_core.bundle.css\" class=\"coreCSSBundles\">\n  <link rel=\"stylesheet\" class=\"moreCSSBundles\" href=\"https://abs.twimg.com/a/1530627074/css/t1/twitter_more_1.bundle.css\">\n  <link rel=\"stylesheet\" class=\"moreCSSBundles\" href=\"https://abs.twimg.com/a/1530627074/css/t1/twitter_more_2.bundle.css\">\n\n    <link rel=\"dns-prefetch\" href=\"https://pbs.twimg.com\">\n    <link rel=\"dns-prefetch\" href=\"https://t.co\">\n      <link rel=\"preload\" href=\"https://abs.twimg.com/k/sv/init.sv.02a09a2e9b2265e88255.js\" as=\"script\">\n      <link rel=\"preload\" href=\"https://abs.twimg.com/k/sv/0.commons.sv.a1253fe48f768b150023.js\" as=\"script\">\n\n      <title>Twitter. Det är det som händer.</title>\n      <meta name=\"robots\" content=\"NOODP\">\n  <meta name=\"description\" content=\"Allt från de senaste nyheterna och underhållningen till sport och politik: du får veta allt med livekommentarer.\">\n\n\n\n<meta name=\"msapplication-TileImage\" content=\"//abs.twimg.com/favicons/win8-tile-144.png\">\n<meta name=\"msapplication-TileColor\" content=\"#00aced\">\n\n\n\n<link rel=\"mask-icon\" sizes=\"any\" href=\"https://abs.twimg.com/a/1530627074/icons/favicon.svg\" color=\"#1da1f2\">\n\n<link rel=\"shortcut icon\" href=\"//abs.twimg.com/favicons/favicon.ico\" type=\"image/x-icon\">\n<link rel=\"apple-touch-icon\" href=\"https://abs.twimg.com/icons/apple-touch-icon-192x192.png\" sizes=\"192x192\">\n\n<link rel=\"manifest\" href=\"/manifest.json\">\n\n\n  <meta name=\"swift-page-name\" id=\"swift-page-name\" content=\"front\">\n  <meta name=\"swift-page-section\" id=\"swift-section-name\" content=\"front\">\n\n    <link rel=\"canonical\" href=\"https://twitter.com/\">\n  <link rel=\"alternate\" hreflang=\"x-default\" href=\"https://twitter.com/\">\n  <link rel=\"alternate\" hreflang=\"fr\" href=\"https://twitter.com/?lang=fr\"><link rel=\"alternate\" hreflang=\"en\" href=\"https://twitter.com/?lang=en\"><link rel=\"alternate\" hreflang=\"ar\" href=\"https://twitter.com/?lang=ar\"><link rel=\"alternate\" hreflang=\"ja\" href=\"https://twitter.com/?lang=ja\"><link rel=\"alternate\" hreflang=\"es\" href=\"https://twitter.com/?lang=es\"><link rel=\"alternate\" hreflang=\"de\" href=\"https://twitter.com/?lang=de\"><link rel=\"alternate\" hreflang=\"it\" href=\"https://twitter.com/?lang=it\"><link rel=\"alternate\" hreflang=\"id\" href=\"https://twitter.com/?lang=id\"><link rel=\"alternate\" hreflang=\"pt\" href=\"https://twitter.com/?lang=pt\"><link rel=\"alternate\" hreflang=\"ko\" href=\"https://twitter.com/?lang=ko\"><link rel=\"alternate\" hreflang=\"tr\" href=\"https://twitter.com/?lang=tr\"><link rel=\"alternate\" hreflang=\"ru\" href=\"https://twitter.com/?lang=ru\"><link rel=\"alternate\" hreflang=\"nl\" href=\"https://twitter.com/?lang=nl\"><link rel=\"alternate\" hreflang=\"fil\" href=\"https://twitter.com/?lang=fil\"><link rel=\"alternate\" hreflang=\"ms\" href=\"https://twitter.com/?lang=ms\"><link rel=\"alternate\" hreflang=\"zh-tw\" href=\"https://twitter.com/?lang=zh-tw\"><link rel=\"alternate\" hreflang=\"zh-cn\" href=\"https://twitter.com/?lang=zh-cn\"><link rel=\"alternate\" hreflang=\"hi\" href=\"https://twitter.com/?lang=hi\"><link rel=\"alternate\" hreflang=\"no\" href=\"https://twitter.com/?lang=no\"><link rel=\"alternate\" hreflang=\"sv\" href=\"https://twitter.com/?lang=sv\"><link rel=\"alternate\" hreflang=\"fi\" href=\"https://twitter.com/?lang=fi\"><link rel=\"alternate\" hreflang=\"da\" href=\"https://twitter.com/?lang=da\"><link rel=\"alternate\" hreflang=\"pl\" href=\"https://twitter.com/?lang=pl\"><link rel=\"alternate\" hreflang=\"hu\" href=\"https://twitter.com/?lang=hu\"><link rel=\"alternate\" hreflang=\"fa\" href=\"https://twitter.com/?lang=fa\"><link rel=\"alternate\" hreflang=\"he\" href=\"https://twitter.com/?lang=he\"><link rel=\"alternate\" hreflang=\"ur\" href=\"https://twitter.com/?lang=ur\"><link rel=\"alternate\" hreflang=\"th\" href=\"https://twitter.com/?lang=th\"><link rel=\"alternate\" hreflang=\"uk\" href=\"https://twitter.com/?lang=uk\"><link rel=\"alternate\" hreflang=\"ca\" href=\"https://twitter.com/?lang=ca\"><link rel=\"alternate\" hreflang=\"ga\" href=\"https://twitter.com/?lang=ga\"><link rel=\"alternate\" hreflang=\"el\" href=\"https://twitter.com/?lang=el\"><link rel=\"alternate\" hreflang=\"eu\" href=\"https://twitter.com/?lang=eu\"><link rel=\"alternate\" hreflang=\"cs\" href=\"https://twitter.com/?lang=cs\"><link rel=\"alternate\" hreflang=\"gl\" href=\"https://twitter.com/?lang=gl\"><link rel=\"alternate\" hreflang=\"ro\" href=\"https://twitter.com/?lang=ro\"><link rel=\"alternate\" hreflang=\"hr\" href=\"https://twitter.com/?lang=hr\"><link rel=\"alternate\" hreflang=\"en-gb\" href=\"https://twitter.com/?lang=en-gb\"><link rel=\"alternate\" hreflang=\"vi\" href=\"https://twitter.com/?lang=vi\"><link rel=\"alternate\" hreflang=\"bn\" href=\"https://twitter.com/?lang=bn\"><link rel=\"alternate\" hreflang=\"bg\" href=\"https://twitter.com/?lang=bg\"><link rel=\"alternate\" hreflang=\"sr\" href=\"https://twitter.com/?lang=sr\"><link rel=\"alternate\" hreflang=\"sk\" href=\"https://twitter.com/?lang=sk\"><link rel=\"alternate\" hreflang=\"gu\" href=\"https://twitter.com/?lang=gu\"><link rel=\"alternate\" hreflang=\"mr\" href=\"https://twitter.com/?lang=mr\"><link rel=\"alternate\" hreflang=\"ta\" href=\"https://twitter.com/?lang=ta\"><link rel=\"alternate\" hreflang=\"kn\" href=\"https://twitter.com/?lang=kn\">\n\n  \n\n  <link rel=\"alternate\" media=\"handheld, only screen and (max-width: 640px)\" href=\"https://mobile.twitter.com/\">\n\n      <link rel=\"alternate\" href=\"android-app://com.twitter.android/twitter/front?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eandroidseo%7Ctwgr%5Ehome\">\n\n<link rel=\"search\" type=\"application/opensearchdescription+xml\" href=\"/opensearch.xml\" title=\"Twitter\">\n\n    <link id=\"async-css-placeholder\">\n\n    \n  <script type=\"text/javascript\" charset=\"utf-8\" async=\"\" src=\"https://abs.twimg.com/k/sv/0.commons.sv.a1253fe48f768b150023.js\"></script><script type=\"text/javascript\" charset=\"utf-8\" async=\"\" src=\"https://abs.twimg.com/k/sv/7.pages_signup.sv.7330e1273291203bfb1e.js\"></script></head>\n  <body class=\"three-col logged-out western sv static-logged-out-home-page\" data-fouc-class-names=\"swift-loading\" dir=\"ltr\">\n      <script id=\"swift_loading_indicator\" nonce=\"\">\n        document.body.className=document.body.className+\" \"+document.body.getAttribute(\"data-fouc-class-names\");\n      </script>\n\n    \n    <noscript>\n      <form action=\"https://mobile.twitter.com/i/nojs_router?path=%2F\" method=\"POST\" class=\"NoScriptForm\">\n        <input type=\"hidden\" value=\"742399c8223e1e6dd4dcb9293528a1721f67a538\" name=\"authenticity_token\">\n\n        <div class=\"NoScriptForm-content\">\n          <span class=\"NoScriptForm-logo Icon Icon--logo Icon--extraLarge\"></span>\n          <p>JavaScript är inaktiverat i webbläsaren. Vill du använda gamla Twitter?</p>\n          <p class=\"NoScriptForm-buttonContainer\"><button type=\"submit\" class=\"EdgeButton EdgeButton--primary\">Ja</button></p>\n        </div>\n      </form>\n    </noscript>\n\n    <a href=\"#timeline\" class=\"u-hiddenVisually focusable\">Gå vidare till innehållet</a>\n\n    \n    \n    \n    \n    \n    \n    \n    \n    \n    <div id=\"doc\" data-at-shortcutkeys=\"{&quot;Enter&quot;:&quot;Detaljer&quot;,&quot;o&quot;:&quot;F\\u00f6rstora foto&quot;,&quot;/&quot;:&quot;S\\u00f6k&quot;,&quot;?&quot;:&quot;Denna meny&quot;,&quot;j&quot;:&quot;N\\u00e4sta tweet&quot;,&quot;k&quot;:&quot;F\\u00f6reg\\u00e5ende tweet&quot;,&quot;Space&quot;:&quot;Scrolla ner&quot;,&quot;.&quot;:&quot;Ladda nya Tweets&quot;,&quot;gu&quot;:&quot;G\\u00e5 till anv\\u00e4ndare\\u2026&quot;}\" class=\"\">\n        <div class=\"StaticLoggedOutHomePage\">\n  <div class=\"StaticLoggedOutHomePage-content\">\n    <div class=\"StaticLoggedOutHomePage-cell StaticLoggedOutHomePage-utilityBlock\">\n      <div class=\"StaticLoggedOutHomePage-login\">\n<form action=\"https://twitter.com/sessions\" class=\"LoginForm js-front-signin\" method=\"post\" data-component=\"login_callout\" data-element=\"form\">\n  <div class=\"LoginForm-input LoginForm-username\">\n    <input type=\"text\" class=\"text-input email-input js-signin-email\" name=\"session[username_or_email]\" autocomplete=\"username\" placeholder=\"Telefon, e-postadress eller användarnamn\">\n  </div>\n\n  <div class=\"LoginForm-input LoginForm-password\">\n    <input type=\"password\" class=\"text-input\" name=\"session[password]\" placeholder=\"Lösenord\" autocomplete=\"current-password\">\n                <div class=\"LoginForm-staticForgot\">\n              <a class=\"forgot\" href=\"/account/begin_password_reset\" rel=\"noopener\">Glömt lösenordet?</a>\n            </div>\n\n  </div>\n\n\n  <input type=\"submit\" class=\"EdgeButton EdgeButton--secondary EdgeButton--medium submit js-submit\" value=\"Logga in\">\n\n    <input type=\"hidden\" name=\"return_to_ssl\" value=\"true\">\n\n  <input type=\"hidden\" name=\"scribe_log\">\n  <input type=\"hidden\" name=\"redirect_after_login\" value=\"/\">\n  <input type=\"hidden\" value=\"742399c8223e1e6dd4dcb9293528a1721f67a538\" name=\"authenticity_token\">\n      <input type=\"hidden\" name=\"ui_metrics\" autocomplete=\"off\" value=\"{&quot;rf&quot;:{&quot;bcc2d31fe91a568bbfb2ee12dcf3ce444f041d58125a82180b51bd68596b636d&quot;:70,&quot;f9bff0d513291f854d57b950347c38b78558be1e9c7552db00a7fc11b3d8dda2&quot;:-5,&quot;a201be65a2f0c129f107e809a6d215b7aeb501139cfeccb055cd30753f685648&quot;:0,&quot;f6a8db7051e3fec1e3e8e15ea073e040add06c90e70d7fef1a3078ec9e902ebc&quot;:-5},&quot;s&quot;:&quot;SQZALXlpAF4GCrDSe2gbjCEXj9IxiIBDQoCS4u_6WFYZqEJZp9O-j8nsrtZ6E4u-yQkCuyRO7YFekMwcS0MtplWUqDFhIU_uiyivdqAvkA0sOCB6c2nCV2f-kd9yV3QDCvc5TpGd9AHPgcfDq7GNDf8aytfQYT5M85N0t-WyI1Ub08xhGwbKvIe4cBK3A7wWr-ajkhGoNcrPRvzG-hBxA3wDyJvCmTnBzzwrJI_ovjixbWHWk2lQ__ut2DL9fuiEM-aGjf5aLelr0V7mEcNAKOnFZ4I3Tow3aD-0cgAtL8AuryJkwW4q8r7x7WofNvl08LizBASXRBEgHmRkBibxywAAAWRl0YhB&quot;}\">\n      <script src=\"/i/js_inst?c_name=ui_metrics\" async=\"\"></script>\n</form>\n      </div>\n      <div class=\"StaticLoggedOutHomePage-signupBlock\">\n        <div class=\"StaticLoggedOutHomePage-signupHeader\">\n          <span class=\"Icon Icon--bird\"></span>\n          <a class=\"StaticLoggedOutHomePage-input StaticLoggedOutHomePage-narrowLoginButton EdgeButton EdgeButton--secondary EdgeButton--small u-floatRight\" href=\"/login\">\n            Logga in\n          </a>\n        </div>\n        <h1 class=\"StaticLoggedOutHomePage-signupTitle\">Se vad som händer i världen just nu</h1>\n          <div class=\"StaticLoggedOutHomePage-noSignupForm\">\n            <h2 class=\"StaticLoggedOutHomePage-signupSubtitle\">Registrera dig på Twitter idag.</h2>\n            <div class=\"StaticLoggedOutHomePage-buttons\">\n              <a class=\"js-nav EdgeButton EdgeButton--medium EdgeButton--primary StaticLoggedOutHomePage-buttonSignup\" href=\"https://twitter.com/signup\">\n                Registrera dig\n              </a>\n              <a class=\"js-nav EdgeButton EdgeButton--medium EdgeButton--secondary StaticLoggedOutHomePage-buttonLogin\" href=\"/login\">\n                Logga in\n              </a>\n            </div>\n          </div>\n      </div>\n    </div>\n\n    <div class=\"StaticLoggedOutHomePage-cell StaticLoggedOutHomePage-communicationBlock\">\n      <!--?xml version=\"1.0\" encoding=\"UTF-8\"?-->\n<svg class=\"twitterIcon-bird\" viewBox=\"0 0 1208 982\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n    <!-- Generator: Sketch 45.2 (43514) - http://www.bohemiancoding.com/sketch -->\n    <title>bird</title>\n    <desc>Created with Sketch.</desc>\n    <defs></defs>\n    <g id=\"Final-Horizon\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\n        <g id=\"Artboard\" transform=\"translate(-286.000000, -117.000000)\" fill-rule=\"nonzero\" fill=\"#1B95E0\">\n            <path d=\"M1493.75308,233.195911 C1449.31783,252.922544 1401.56126,266.207828 1351.43951,272.19627 C1402.61804,241.549536 1441.92034,192.987798 1460.3889,135.116296 C1412.53168,163.498493 1359.49119,184.130942 1303.02874,195.252335 C1257.88897,147.093181 1193.42514,117 1122.16771,117 C962.190754,117 844.636121,266.258151 880.768067,421.202806 C674.896491,410.886582 492.324484,312.253414 370.089808,162.341063 C305.17308,273.705962 336.423691,419.391176 446.731805,493.16476 C406.171431,491.856361 367.925917,480.734968 334.561738,462.165765 C331.844294,576.95263 414.122472,684.342008 533.287442,708.245454 C498.413572,717.706186 460.218381,719.9204 421.368991,712.47259 C452.871217,810.904465 544.358512,882.514158 652.854997,884.52708 C548.686294,966.201382 417.443793,1002.68559 286,987.186091 C395.653915,1057.48739 525.940278,1098.50067 665.838342,1098.50067 C1125.89162,1098.50067 1385.81015,709.956437 1370.10936,361.469352 C1418.52012,326.494836 1460.53987,282.864756 1493.75308,233.195911 Z\" id=\"bird\"></path>\n        </g>\n    </g>\n</svg>\n      <div class=\"StaticLoggedOutHomePage-communicationContent\">\n        <div class=\"StaticLoggedOutHomePage-communicationItem\">\n          <span class=\"Icon Icon--search\"></span> Följ dina intressen.\n        </div>\n        <div class=\"StaticLoggedOutHomePage-communicationItem\">\n          <span class=\"Icon Icon--people\"></span> Hör vad folk pratar om.\n        </div>\n        <div class=\"StaticLoggedOutHomePage-communicationItem\">\n          <span class=\"Icon Icon--reply\"></span> Delta i samtalet.\n        </div>\n      </div>\n    </div>\n  </div>\n\n      <div id=\"banners\" class=\"js-banners\">\n            <div class=\"Banner Banner--aboveNav eu-cookie-notice\">\n  <div class=\"Banner-contentContainer\">\n    <div class=\"Banner-textContent\">\n      Genom att använda Twitters tjänster godkänner du att vi <a href=\"https://help.twitter.com/rules-and-policies/twitter-cookies\" rel=\"noopener\">använder cookies</a>. Vi och våra partner verkar globalt och använder cookies bland annat för statistik, personanpassning och annonser.\n    </div>\n    <div class=\"Banner-actions\">\n      <button type=\"button\"><span class=\"Icon Icon--close\"><span class=\"visuallyhidden\">Stäng</span></span></button>\n    </div>\n  </div>\n</div>\n\n      </div>\n\n  <noscript>\n  <div class=\"front-warning\">\n    <h3>Twitter.com använder mycket JavaScript</h3>\n    <p>Om du inte kan aktivera det i dina webläsarinställningar kanske det fungerar bättre på vår <a href=\"http://m.twitter.com\" rel=\"noopener\">mobilsida</a>.</p>\n  </div>\n</noscript>\n\n<div class=\"front-warning\" id=\"front-no-cookies-warn\">\n  <h3>Twitter.com använder mycket webbläsarcookies</h3>\n  <p>Vänligen aktivera cookies i din webbläsares inställningar innan du loggar in.</p>\n</div>\n  <div class=\"StreamsFooter StreamsFooter--fixed\">\n  <ul class=\"StreamsFooter-list u-cf\">\n    <li class=\"StreamsFooter-item\"><a href=\"/about\" rel=\"noopener\">Om</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"//support.twitter.com\" rel=\"noopener\">Hjälpcenter</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"https://blog.twitter.com\" rel=\"noopener\">Blogg</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"http://status.twitter.com\" rel=\"noopener\">Status</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"https://about.twitter.com/careers\" rel=\"noopener\">Jobb</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"/tos\" rel=\"noopener\">Regler</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"/privacy\" rel=\"noopener\">Integritetspolicy</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"//support.twitter.com/articles/20170514\" rel=\"noopener\">Cookies</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"//support.twitter.com/articles/20170451\" rel=\"noopener\">Annonsinformation</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"//about.twitter.com/press/brand-assets\" rel=\"noopener\">Varumärke</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"https://about.twitter.com/products\" rel=\"noopener\">Appar</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"//ads.twitter.com/?ref=gl-tw-tw-twitter-advertise\" rel=\"noopener\">Annonsera</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"https://marketing.twitter.com\" rel=\"noopener\">Marknadsföring</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"https://business.twitter.com\" rel=\"noopener\">Företag</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"//dev.twitter.com\" rel=\"noopener\">Utvecklare</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"/i/directory/profiles\" rel=\"noopener\">Register</a></li>\n    <li class=\"StreamsFooter-item\"><a href=\"/settings/personalization\" rel=\"noopener\">Inställningar</a></li>\n    <li class=\"StreamsFooter-item StreamsFooter-copyright\">© 2018 Twitter</li>\n  </ul>\n</div>\n\n</div>\n\n    </div>\n    <div class=\"alert-messages hidden\" id=\"message-drawer\" style=\"top: -40px;\">\n    <div class=\"message \">\n  <div class=\"message-inside\">\n    <span class=\"message-text\"></span>\n      <a role=\"button\" class=\"Icon Icon--close Icon--medium dismiss\" href=\"#\">\n        <span class=\"visuallyhidden\">Dölj</span>\n      </a>\n  </div>\n</div>\n</div>\n\n    \n\n\n<div class=\"gallery-overlay\"></div>\n<div class=\"Gallery with-tweet\">\n  <style class=\"Gallery-styles\"></style>\n  <div class=\"Gallery-closeTarget\"></div>\n  <div class=\"Gallery-content\">\n    <button type=\"button\" class=\"modal-btn modal-close modal-close-fixed js-close\">\n  <span class=\"Icon Icon--close Icon--large\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n    <div class=\"Gallery-media\"></div>\n    <div class=\"GalleryNav GalleryNav--prev\">\n      <span class=\"GalleryNav-handle GalleryNav-handle--prev\">\n        <span class=\"Icon Icon--caretLeft Icon--large\">\n          <span class=\"u-hiddenVisually\">\n            Föregående\n          </span>\n        </span>\n      </span>\n    </div>\n    <div class=\"GalleryNav GalleryNav--next\">\n      <span class=\"GalleryNav-handle GalleryNav-handle--next\">\n        <span class=\"Icon Icon--caretRight Icon--large\">\n          <span class=\"u-hiddenVisually\">\n            Nästa\n          </span>\n        </span>\n      </span>\n    </div>\n    <div class=\"GalleryTweet\"></div>\n  </div>\n</div>\n\n\n<div class=\"modal-overlay\"></div>\n\n<div id=\"profile-hover-container\"></div>\n\n\n<div id=\"goto-user-dialog\" class=\"modal-container\">\n  <div class=\"modal modal-small draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Gå till en användares profil.</h3>\n      </div>\n\n      <div class=\"modal-body\">\n        <div class=\"modal-inner\">\n          <form class=\"t1-form goto-user-form\">\n            <input class=\"input-block username-input\" type=\"text\" placeholder=\"Börja skriva ett namn för att komma till en profil\" aria-label=\"Användare\">\n            \n\n\n<div role=\"listbox\" class=\"dropdown-menu typeahead\">\n  <div aria-hidden=\"true\" class=\"dropdown-caret\">\n    <div class=\"caret-outer\"></div>\n    <div class=\"caret-inner\"></div>\n  </div>\n  <div role=\"presentation\" class=\"dropdown-inner js-typeahead-results\">\n    <div role=\"presentation\" class=\"typeahead-saved-searches\">\n  <h3 id=\"saved-searches-heading\" class=\"typeahead-category-title saved-searches-title\">Sparade sökningar</h3>\n  <ul role=\"presentation\" class=\"typeahead-items saved-searches-list\">\n    \n    <li role=\"presentation\" class=\"typeahead-item typeahead-saved-search-item\">\n      <span class=\"Icon Icon--close\" aria-hidden=\"true\"><span class=\"visuallyhidden\">Ta bort</span></span>\n      <a role=\"option\" aria-describedby=\"saved-searches-heading\" class=\"js-nav\" href=\"\" data-search-query=\"\" data-query-source=\"\" data-ds=\"saved_search\" tabindex=\"-1\"></a>\n    </li>\n  </ul>\n</div>\n\n    <ul role=\"presentation\" class=\"typeahead-items typeahead-topics\">\n  \n  <li role=\"presentation\" class=\"typeahead-item typeahead-topic-item\">\n    <a role=\"option\" class=\"js-nav\" href=\"\" data-search-query=\"\" data-query-source=\"typeahead_click\" data-ds=\"topics\" tabindex=\"-1\"></a>\n  </li>\n</ul>\n    <ul role=\"presentation\" class=\"typeahead-items typeahead-accounts social-context js-typeahead-accounts\">\n  \n  <li role=\"presentation\" data-user-id=\"\" data-user-screenname=\"\" data-remote=\"true\" data-score=\"\" class=\"typeahead-item typeahead-account-item js-selectable\">\n    \n    <a role=\"option\" class=\"js-nav\" data-query-source=\"typeahead_click\" data-search-query=\"\" data-ds=\"account\">\n      <div class=\"js-selectable typeahead-in-conversation hidden\">\n        <span class=\"Icon Icon--follower Icon--small\"></span>\n        <span class=\"typeahead-in-conversation-text\">I denna konversation</span>\n      </div>\n      <img class=\"avatar size32\" alt=\"\">\n      <span class=\"typeahead-user-item-info account-group\">\n        <span class=\"fullname\"></span><span class=\"UserBadges\"><span class=\"Icon Icon--verified js-verified hidden\"><span class=\"u-hiddenVisually\">Verifierat konto</span></span><span class=\"Icon Icon--protected js-protected hidden\"><span class=\"u-hiddenVisually\">Skyddade tweets</span></span></span><span class=\"UserNameBreak\">&nbsp;</span><span class=\"username u-dir\" dir=\"ltr\">@<b></b></span>\n      </span>\n      <span class=\"typeahead-social-context\"></span>\n    </a>\n  </li>\n  <li role=\"presentation\" class=\"js-selectable typeahead-accounts-shortcut js-shortcut\"><a role=\"option\" class=\"js-nav\" href=\"\" data-search-query=\"\" data-query-source=\"typeahead_click\" data-shortcut=\"true\" data-ds=\"account_search\"></a></li>\n</ul>\n\n    <ul role=\"presentation\" class=\"typeahead-items typeahead-trend-locations-list\">\n  \n  <li role=\"presentation\" class=\"typeahead-item typeahead-trend-locations-item\"><a role=\"option\" class=\"js-nav\" href=\"\" data-ds=\"trend_location\" data-search-query=\"\" tabindex=\"-1\"></a></li>\n</ul>\n    \n<div role=\"presentation\" class=\"typeahead-user-select\">\n  <div role=\"presentation\" class=\"typeahead-empty-suggestions\">\n    Föreslagna användare\n  </div>\n  <ul role=\"presentation\" class=\"typeahead-items typeahead-selected js-typeahead-selected\">\n    \n    <li role=\"presentation\" data-user-id=\"\" data-user-screenname=\"\" data-remote=\"true\" data-score=\"\" class=\"typeahead-item typeahead-selected-item js-selectable\">\n      \n      <a role=\"option\" class=\"js-nav\" data-query-source=\"typeahead_click\" data-search-query=\"\" data-ds=\"account\">\n        <img class=\"avatar size32\" alt=\"\">\n        <span class=\"typeahead-user-item-info account-group\">\n          <span class=\"select-status deselect-user js-deselect-user Icon Icon--check\"></span>\n          <span class=\"select-status select-disabled Icon Icon--unfollow\"></span>\n          <span class=\"fullname\"></span><span class=\"UserBadges\"><span class=\"Icon Icon--verified js-verified hidden\"><span class=\"u-hiddenVisually\">Verifierat konto</span></span><span class=\"Icon Icon--protected js-protected hidden\"><span class=\"u-hiddenVisually\">Skyddade tweets</span></span></span><span class=\"UserNameBreak\">&nbsp;</span><span class=\"username u-dir\" dir=\"ltr\">@<b></b></span>\n        </span>\n      </a>\n    </li>\n    <li role=\"presentation\" class=\"typeahead-selected-end\"></li>\n  </ul>\n\n  <ul role=\"presentation\" class=\"typeahead-items typeahead-accounts js-typeahead-accounts\">\n    \n    <li role=\"presentation\" data-user-id=\"\" data-user-screenname=\"\" data-remote=\"true\" data-score=\"\" class=\"typeahead-item typeahead-account-item js-selectable\">\n      \n      <a role=\"option\" class=\"js-nav\" data-query-source=\"typeahead_click\" data-search-query=\"\" data-ds=\"account\">\n        <img class=\"avatar size32\" alt=\"\">\n        <span class=\"typeahead-user-item-info account-group\">\n          <span class=\"select-status deselect-user js-deselect-user Icon Icon--check\"></span>\n          <span class=\"select-status select-disabled Icon Icon--unfollow\"></span>\n          <span class=\"fullname\"></span><span class=\"UserBadges\"><span class=\"Icon Icon--verified js-verified hidden\"><span class=\"u-hiddenVisually\">Verifierat konto</span></span><span class=\"Icon Icon--protected js-protected hidden\"><span class=\"u-hiddenVisually\">Skyddade tweets</span></span></span><span class=\"UserNameBreak\">&nbsp;</span><span class=\"username u-dir\" dir=\"ltr\">@<b></b></span>\n        </span>\n      </a>\n    </li>\n    <li role=\"presentation\" class=\"typeahead-accounts-end\"></li>\n  </ul>\n</div>\n\n    <div role=\"presentation\" class=\"typeahead-dm-conversations\">\n  <ul role=\"presentation\" class=\"typeahead-items typeahead-dm-conversation-items\">\n    <li role=\"presentation\" class=\"typeahead-item typeahead-dm-conversation-item\">\n      <a role=\"option\" tabindex=\"-1\"></a>\n    </li>\n  </ul>\n</div>\n  </div>\n</div>\n\n          </form>\n        </div>\n      </div>\n\n    </div>\n  </div>\n</div>\n\n<div id=\"quick-promote-dialog\" class=\"QuickPromoteDialog modal-container\">\n  <div class=\"modal draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close modal-close-fixed js-close\">\n  <span class=\"Icon Icon--close Icon--large\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Sponsra denna Tweet</h3>\n      </div>\n      <div class=\"modal-body\">\n        <div class=\"quick-promote-view-container\">\n          <div class=\"media\">\n            <iframe class=\"quick-promote-iframe js-initial-focus\" scrolling=\"no\" frameborder=\"0\" src=\"\">\n            </iframe>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n<div id=\"block-user-dialog\" class=\"modal-container\">\n  <div class=\"modal draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Blockera</h3>\n      </div>\n\n      <div class=\"tweet-loading\">\n  <div class=\"spinner-bigger\"></div>\n</div>\n\n      <div class=\"modal-body modal-tweet\"></div>\n\n      <div class=\"modal-footer\">\n        <button class=\"EdgeButton EdgeButton--tertiary cancel-action js-close\">Avbryt</button>\n        <button class=\"EdgeButton EdgeButton--danger block-action\">Blockera</button>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n\n\n\n\n   <div id=\"geo-disabled-dropdown\">\n    <div tabindex=\"-1\">\n  <div class=\"dropdown-caret\">\n    <span class=\"caret-outer\"></span>\n    <span class=\"caret-inner\"></span>\n  </div>\n  <ul>\n    <li class=\"geo-not-enabled-yet\">\n      <h2>Tweeta med en position</h2>\n      <p>\n        Du kan lägga till platsinformation i dina Tweets, t.ex. din ort eller exakta position, från webben och via externa applikationer. Du kan alltid radera platshistoriken för dina Tweets.\n        <a href=\"http://support.twitter.com/forums/26810/entries/78525\" target=\"_blank\" rel=\"noopener\">Läs mer</a>\n      </p>\n      <div>\n        <button type=\"button\" class=\"geo-turn-on EdgeButton EdgeButton--primary\">Aktivera</button>\n        <button type=\"button\" class=\"geo-not-now EdgeButton EdgeButton--secondary\">Inte nu</button>\n      </div>\n    </li>\n  </ul>\n</div>\n\n  </div>\n\n<div id=\"geo-enabled-dropdown\">\n  <div tabindex=\"-1\">\n  <div class=\"dropdown-caret\">\n    <span class=\"caret-outer\"></span>\n    <span class=\"caret-inner\"></span>\n  </div>\n  <div>\n    <div class=\"geo-query-location\">\n      <input class=\"GeoSearch-queryInput\" type=\"text\" autocomplete=\"off\" placeholder=\"Sök efter en stadsdel eller stad\">\n      <span class=\"Icon Icon--search\"></span>\n    </div>\n    <div class=\"geo-dropdown-status\"></div>\n    <ul class=\"GeoSearch-dropdownMenu\"></ul>\n  </div>\n</div>\n\n</div>\n\n\n\n  <div id=\"list-membership-dialog\" class=\"modal-container\">\n  <div class=\"modal modal-small draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Dina listor</h3>\n      </div>\n      <div class=\"modal-body\">\n        <div class=\"list-membership-content\"></div>\n        <span class=\"spinner lists-spinner\" title=\"Laddar…\"></span>\n      </div>\n    </div>\n  </div>\n</div>\n  <div id=\"list-operations-dialog\" class=\"modal-container\">\n  <div class=\"modal modal-medium draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Skapa en ny lista</h3>\n      </div>\n      <div class=\"modal-body\">\n        <div class=\"list-editor\">\n  <div class=\"field\">\n    <label class=\"t1-label\" for=\"list-name\">Listnamn</label>\n    <input id=\"list-name\" type=\"text\" class=\"text\" name=\"name\" value=\"\">\n  </div>\n  <hr>\n\n  <div class=\"field\">\n    <label class=\"t1-label\" for=\"list-description\">Beskrivning</label>\n    <textarea id=\"list-description\" name=\"description\"></textarea>\n    <span class=\"help-text\">Under 100 tecken, frivillig</span>\n  </div>\n  <hr>\n\n  <fieldset class=\"field\">\n    <legend class=\"t1-legend\">Integritet</legend>\n    <div class=\"options\">\n      <label class=\"t1-label\" for=\"list-public-radio\">\n        <input class=\"radio\" type=\"radio\" name=\"mode\" id=\"list-public-radio\" value=\"public\" checked=\"checked\">\n        <b>Offentlig</b> · Vem som helst kan följa den här listan\n      </label>\n      <label class=\"t1-label\" for=\"list-private-radio\">\n        <input class=\"radio\" type=\"radio\" name=\"mode\" id=\"list-private-radio\" value=\"private\">\n        <b>Privat</b> · Endast du har åtkomst till denna lista\n      </label>\n    </div>\n  </fieldset>\n  <hr>\n\n  <div class=\"list-editor-save\">\n    <button type=\"button\" class=\"EdgeButton EdgeButton--secondary update-list-button\" data-list-id=\"\">Spara lista</button>\n  </div>\n</div>\n\n      </div>\n    </div>\n  </div>\n</div>\n\n<div id=\"activity-popup-dialog\" class=\"modal-container\">\n  <div class=\"modal draggable\">\n    <div class=\"modal-content clearfix\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\"></h3>\n      </div>\n\n      <div class=\"modal-body\">\n        <div class=\"tweet-loading\">\n  <div class=\"spinner-bigger\"></div>\n</div>\n\n        <div class=\"activity-popup-dialog-content modal-tweet clearfix\"></div>\n        <div class=\"loading\">\n          <span class=\"spinner-bigger\"></span>\n        </div>\n        <div class=\"activity-popup-dialog-users clearfix\"></div>\n        <div class=\"activity-popup-dialog-footer\"></div>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n\n\n<div id=\"copy-link-to-tweet-dialog\" class=\"modal-container\">\n  <div class=\"modal modal-medium draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Kopiera länk till Tweet</h3>\n      </div>\n      <div class=\"modal-body\">\n        <div class=\"copy-link-to-tweet-container\">\n          <label class=\"t1-label\">\n            <p class=\"copy-link-to-tweet-instructions\">URL till denna Tweet finns nedan. Kopiera det för att enkelt dela det med vänner.</p>\n            <textarea class=\"link-to-tweet-destination js-initial-focus u-dir\" dir=\"ltr\" readonly=\"\"></textarea>\n          </label>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n<div id=\"embed-tweet-dialog\" class=\"modal-container\">\n  <div class=\"modal modal-medium draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title embed-tweet-title\">Bädda in denna Tweet</h3>\n        <h3 class=\"modal-title embed-video-title\">Embed this Video</h3>\n      </div>\n      <div class=\"modal-body\">\n        <div class=\"embed-code-container\">\n  <p class=\"embed-tweet-instructions\">Lägg till denna Tweet på din webbplats genom att kopiera koden nedan. <a href=\"https://dev.twitter.com/web/embedded-tweets\" target=\"_blank\" rel=\"noopener\">Läs mer</a></p>\n  <p class=\"embed-video-instructions\">Lägg till denna video på din webbplats genom att kopiera koden nedan. <a href=\"https://dev.twitter.com/web/embedded-tweets\" target=\"_blank\" rel=\"noopener\">Läs mer</a></p>\n  <form class=\"t1-form\">\n\n    <div class=\"embed-destination-wrapper\">\n      <div class=\"embed-overlay embed-overlay-spinner\"><div class=\"embed-overlay-content\"></div></div>\n      <div class=\"embed-overlay embed-overlay-error\">\n        <p class=\"embed-overlay-content\">Hmm, det uppstod ett problem att nå servern. <button type=\"button\" class=\"btn-link retry-embed\">Försöka igen?</button></p>\n      </div>\n      <textarea class=\"embed-destination js-initial-focus\"></textarea>\n      <div class=\"embed-options\">\n        <div class=\"embed-include-parent-tweet\">\n          <label class=\"t1-label\" for=\"include-parent-tweet\">\n            <input type=\"checkbox\" id=\"include-parent-tweet\" class=\"include-parent-tweet\" checked=\"\">\n            Inkludera den överordnade tweeten\n          </label>\n        </div>\n        <div class=\"embed-include-card\">\n          <label class=\"t1-label\" for=\"include-card\">\n            <input type=\"checkbox\" id=\"include-card\" class=\"include-card\" checked=\"\">\n            Inkludera media\n          </label>\n        </div>\n      </div>\n    </div>\n  </form>\n  <p class=\"embed-tweet-description\">Genom att bädda in innehåll från Twitter på din webbplats eller i din app godkänner du Twitters <a href=\"https://dev.twitter.com/overview/terms/agreement\" rel=\"noopener\">villkor för utvecklare</a> och <a href=\"https://dev.twitter.com/overview/terms/policy\" rel=\"noopener\">utvecklarpolicy</a>.</p>\n  <h3 class=\"embed-preview-header\">Förhandsgranskning</h3>\n  <div class=\"embed-preview\">\n  </div>\n</div>\n\n      </div>\n    </div>\n  </div>\n</div>\n\n\n<div id=\"why-this-ad-dialog\" class=\"modal-container why-this-ad-dialog\">\n  <div class=\"modal modal-large draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title why-this-ad-title\">Varför du ser denna annons</h3>\n      </div>\n      <div class=\"why-this-ad-content\">\n        <div class=\"why-this-ad-spinner\">\n          <div class=\"spinner-bigger\"></div>\n        </div>\n        <iframe id=\"why-this-ad-frame\" class=\"hidden\" aria-hidden=\"true\" scrolling=\"auto\">\n        </iframe>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n\n  <div id=\"login-dialog\" class=\"LoginDialog modal-container u-textCenter\">\n  <div class=\"modal modal-large draggable\">\n    <div class=\"LoginDialog-content modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Logga in på Twitter</h3>\n      </div>\n      <div class=\"LoginDialog-body modal-body\">\n        <div class=\"LoginDialog-bird\">\n          <span class=\"Icon Icon--bird Icon--large\"></span>\n        </div>\n        <div class=\"LoginDialog-form\">\n<form action=\"https://twitter.com/sessions\" class=\"LoginForm js-front-signin\" method=\"post\" data-component=\"dialog\" data-element=\"login\">\n  <div class=\"LoginForm-input LoginForm-username\">\n    <input type=\"text\" class=\"text-input email-input js-signin-email\" name=\"session[username_or_email]\" autocomplete=\"username\" placeholder=\"Telefon, e-postadress eller användarnamn\">\n  </div>\n\n  <div class=\"LoginForm-input LoginForm-password\">\n    <input type=\"password\" class=\"text-input\" name=\"session[password]\" placeholder=\"Lösenord\" autocomplete=\"current-password\">\n    \n  </div>\n\n    <div class=\"LoginForm-rememberForgot\">\n      <label>\n        <input type=\"checkbox\" value=\"1\" name=\"remember_me\" checked=\"checked\">\n        <span>Kom ihåg mig</span>\n      </label>\n      <span class=\"separator\">·</span>\n      <a class=\"forgot\" href=\"/account/begin_password_reset\" rel=\"noopener\">Glömt lösenordet?</a>\n    </div>\n\n  <input type=\"submit\" class=\"EdgeButton EdgeButton--primary EdgeButton--medium submit js-submit\" value=\"Logga in\">\n\n    <input type=\"hidden\" name=\"return_to_ssl\" value=\"true\">\n\n  <input type=\"hidden\" name=\"scribe_log\">\n  <input type=\"hidden\" name=\"redirect_after_login\" value=\"/\">\n  <input type=\"hidden\" value=\"742399c8223e1e6dd4dcb9293528a1721f67a538\" name=\"authenticity_token\">\n      <input type=\"hidden\" name=\"ui_metrics\" autocomplete=\"off\" value=\"{&quot;rf&quot;:{&quot;bcc2d31fe91a568bbfb2ee12dcf3ce444f041d58125a82180b51bd68596b636d&quot;:70,&quot;f9bff0d513291f854d57b950347c38b78558be1e9c7552db00a7fc11b3d8dda2&quot;:-5,&quot;a201be65a2f0c129f107e809a6d215b7aeb501139cfeccb055cd30753f685648&quot;:0,&quot;f6a8db7051e3fec1e3e8e15ea073e040add06c90e70d7fef1a3078ec9e902ebc&quot;:-5},&quot;s&quot;:&quot;SQZALXlpAF4GCrDSe2gbjCEXj9IxiIBDQoCS4u_6WFYZqEJZp9O-j8nsrtZ6E4u-yQkCuyRO7YFekMwcS0MtplWUqDFhIU_uiyivdqAvkA0sOCB6c2nCV2f-kd9yV3QDCvc5TpGd9AHPgcfDq7GNDf8aytfQYT5M85N0t-WyI1Ub08xhGwbKvIe4cBK3A7wWr-ajkhGoNcrPRvzG-hBxA3wDyJvCmTnBzzwrJI_ovjixbWHWk2lQ__ut2DL9fuiEM-aGjf5aLelr0V7mEcNAKOnFZ4I3Tow3aD-0cgAtL8AuryJkwW4q8r7x7WofNvl08LizBASXRBEgHmRkBibxywAAAWRl0YhB&quot;}\">\n      <script src=\"/i/js_inst?c_name=ui_metrics\" async=\"\"></script>\n</form>\n        </div>\n      </div>\n      <div class=\"LoginDialog-footer modal-footer u-textCenter\">\n        Har du inget konto? <a class=\"LoginDialog-signupLink\" href=\"https://twitter.com/signup\" rel=\"noopener\">Registrera dig »</a>\n      </div>\n    </div>\n  </div>\n</div>\n\n  <div id=\"signup-dialog\" class=\"SignupDialog modal-container u-textCenter\">\n  <div class=\"modal modal-large draggable\">\n    <div class=\"SignupDialog-content modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Registrera dig på Twitter</h3>\n      </div>\n      <div class=\"SignupDialog-body modal-body\">\n        <div class=\"SignupDialog-icon\">\n          <span class=\"Icon Icon--bird Icon--extraLarge\"></span>\n        </div>\n        <h2 class=\"SignupDialog-heading\">Har du inte Twitter? Registrera dig, ta del av de saker du bryr dig om och få omedelbara uppdateringar i realtid.</h2>\n        <div class=\"SignupDialog-form\">\n<div class=\"signup SignupForm\n  \">\n  <a href=\"https://twitter.com/signup\" role=\"button\" class=\"EdgeButton EdgeButton--large EdgeButton--primary SignupForm-submit u-block js-signup \" data-component=\"dialog\" data-element=\"signup\">Registrera dig</a>\n</div>\n        </div>\n      </div>\n      <div class=\"SignupDialog-footer modal-footer u-textCenter\">\n        Har du ett konto? <a class=\"SignupDialog-signinLink\" href=\"/login\" rel=\"noopener\">Logga in »</a>\n      </div>\n    </div>\n  </div>\n</div>\n\n  <div id=\"sms-codes-dialog\" class=\"modal-container\">\n  <div class=\"modal modal-medium draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Tvåvägskoder för att sända och ta emot</h3>\n      </div>\n      <div class=\"modal-body\">\n        \n<table id=\"sms_codes\" cellpadding=\"0\" cellspacing=\"0\">\n  <thead>\n    <tr>\n      <th>Land</th>\n      <th>Kod</th>\n      <th>För kunder hos</th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr>\n      <td>USA</td>\n      <td>40404</td>\n      <td>(vilken som helst)</td>\n    </tr>\n    <tr>\n      <td>Kanada</td>\n      <td>21212</td>\n      <td>(vilken som helst)</td>\n    </tr>\n    <tr>\n      <td>Storbritannien</td>\n      <td>86444</td>\n      <td>Vodafone, Orange, 3, O2</td>\n    </tr>\n    <tr>\n      <td>Brasilien</td>\n      <td>40404</td>\n      <td>Nextel, TIM</td>\n    </tr>\n    <tr>\n      <td>Haiti</td>\n      <td>40404</td>\n      <td>Digicel, Voila</td>\n    </tr>\n    <tr>\n      <td>Irland</td>\n      <td>51210</td>\n      <td>Vodafone, O2</td>\n    </tr>\n    <tr>\n      <td>Indien</td>\n      <td>53000</td>\n      <td>Bharti Airtel, Videocon, Reliance</td>\n    </tr>\n    <tr>\n      <td>Indonesien</td>\n      <td>89887</td>\n      <td>AXIS, 3, Telkomsel, Indosat, XL Axiata</td>\n    </tr>\n    <tr>\n      <td rowspan=\"2\">Italien</td>\n      <td>4880804</td>\n      <td>Wind</td>\n    </tr>\n    <tr>\n      <td>3424486444</td>\n      <td>Vodafone</td>\n    </tr>\n  </tbody>\n  <tfoot>\n    <tr>\n      <td colspan=\"3\">\n        » <a class=\"js-initial-focus\" target=\"_blank\" href=\"http://support.twitter.com/articles/14226-how-to-find-your-twitter-short-code-or-long-code\" rel=\"noopener\">Se SMS-kortnummer för andra länder</a>\n      </td>\n    </tr>\n  </tfoot>\n</table>\n      </div>\n    </div>\n  </div>\n</div>\n\n<div id=\"leadgen-confirm-dialog\" class=\"modal-container\">\n  <div class=\"modal draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close js-close\">\n  <span class=\"Icon Icon--close Icon--medium\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">Bekräftelse</h3>\n      </div>\n      <div class=\"modal-body\">\n        <div class=\"leadgen-card-container\">\n          <div class=\"media\">\n            <iframe class=\"cards2-promotion-iframe\" scrolling=\"no\" frameborder=\"0\" src=\"\">\n            </iframe>\n          </div>\n        </div>\n        <div class=\"js-macaw-cards-iframe-container\" data-card-name=\"promotion\">\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n<div id=\"auth-webview-dialog\" class=\"AuthWebViewDialog modal-container\">\n  <div class=\"modal draggable\">\n    <div class=\"modal-content\">\n      <button type=\"button\" class=\"modal-btn modal-close modal-close-fixed js-close\">\n  <span class=\"Icon Icon--close Icon--large\">\n    <span class=\"visuallyhidden\">Stäng</span>\n  </span>\n</button>\n\n      <div class=\"modal-header\">\n        <h3 class=\"modal-title\">&nbsp;</h3>\n      </div>\n      <div class=\"modal-body\">\n        <div class=\"auth-webview-view-container\">\n          <div class=\"media\">\n            <iframe class=\"auth-webview-card-iframe js-initial-focus\" scrolling=\"no\" frameborder=\"0\" width=\"590px\" height=\"500px\" src=\"\">\n            </iframe>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n\n<div id=\"promptbird-modal-prompt\" class=\"modal-container\">\n  <div class=\"modal\">\n    \n    <button type=\"button\" class=\"modal-btn js-promptDismiss modal-close js-close\">\n      <span class=\"Icon Icon--close Icon--medium\">\n        <span class=\"visuallyhidden\">Stäng</span>\n      </span>\n    </button>\n    <div class=\"modal-content\"></div>\n  </div>\n</div>\n\n\n<div id=\"ui-walkthrough-dialog\" class=\"modal-container UIWalkthrough\">\n  <div class=\"UIWalkthrough-clickBlocker\"></div>\n  <div class=\"modal modal-small\">\n    <div class=\"UIWalkthrough-caret\"></div>\n    <div class=\"modal-content\">\n      <div class=\"modal-body\">\n        <div class=\"UIWalkthrough-header\">\n          <span class=\"UIWalkthrough-stepProgress\"></span>\n          <button class=\"UIWalkthrough-skip js-close\">\n            Hoppa över alla\n          </button>\n        </div>\n        \n\n\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--welcome\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--home UIWalkthrough-icon\"></span>\n    Välkommen hem!\n  </h3>\n  <p class=\"UIWalkthrough-message\">Tidslinjen är den vy du kommer att använda mest. Här visas den senaste informationen om det du tycker är viktigt.</p>\n</div>\n\n\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--unfollow\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--smileRating1Fill UIWalkthrough-icon\"></span>\n    Fungerar inga Tweets för dig?\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Håll pekaren över profilbilden och klicka på knappen Följer om du vill avfölja ett konto.\n  </p>\n</div>\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--like\">\n\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--heart UIWalkthrough-icon\"></span>\n    Säg mycket med små medel\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Om du ser en Tweet som du blir stormförtjust i kan du trycka på hjärtat, så får användaren som skrev den veta att du gillade den.\n  </p>\n</div>\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--retweet\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--retweet UIWalkthrough-icon\"></span>\n    Sprid ordet\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Det snabbaste sättet att dela någons Tweet med dina följare är genom att Retweeta. Tryck på ikonen om du vill skicka direkt.\n  </p>\n</div>\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--reply\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--reply UIWalkthrough-icon\"></span>\n    Delta i konversationen\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Berätta vad du tycker om en Tweet genom att svara. Hitta ett ämne du känner starkt för och ge dig in i samtalet.\n  </p>\n</div>\n\n\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--trends\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--discover UIWalkthrough-icon\"></span>\n    Ta reda på mer om senaste nytt\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Få omedelbar insikt i vad alla pratar om just nu.\n  </p>\n</div>\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--wtf\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--follow UIWalkthrough-icon\"></span>\n    Få mer av det du gillar\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Följ fler konton och få direktuppdateringar om ämnen du bryr dig om.\n  </p>\n</div>\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--search\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--search UIWalkthrough-icon\"></span>\n    Ta reda på vad som händer\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Läs de senaste konversationerna om valfritt ämne på en gång.\n  </p>\n</div>\n\n<div class=\"UIWalkthrough-step UIWalkthrough-step--moments\">\n  <h3 class=\"UIWalkthrough-title\">\n    <span class=\"Icon Icon--lightning UIWalkthrough-icon\"></span>\n    Missa inte ett enda ögonblick\n  </h3>\n  <p class=\"UIWalkthrough-message\">\n    Håll dig ajour med de intressantaste händelserna medan de händer.\n  </p>\n</div>\n      </div>\n\n      <div class=\"modal-footer\">\n        <button class=\"EdgeButton EdgeButton--tertiary u-floatLeft plain-btn UIWalkthrough-button js-previous-step\">Tillbaka</button>\n        <button class=\"EdgeButton EdgeButton--secondary UIWalkthrough-button js-next-step js-initial-focus\">Nästa</button>\n      </div>\n    </div>\n  </div>\n</div>\n\n\n\n\n\n<div id=\"create-custom-timeline-dialog\" class=\"modal-container\"></div>\n<div id=\"edit-custom-timeline-dialog\" class=\"modal-container\"></div>\n<div id=\"curate-dialog\" class=\"modal-container\"></div>\n<div id=\"media-edit-dialog\" class=\"modal-container\"></div>\n\n\n      <div class=\"PermalinkOverlay PermalinkOverlay-with-background \" id=\"permalink-overlay\">\n  <div class=\"PermalinkProfile-dismiss modal-close-fixed\">\n    <span class=\"Icon Icon--close\"></span>\n  </div>\n  <button class=\"PermalinkOverlay-next PermalinkOverlay-button u-posFixed js-next\" type=\"button\">\n    <span class=\"Icon Icon--caretLeft Icon--large\"></span>\n    <span class=\"u-hiddenVisually\">Nästa Tweet från användaren</span>\n  </button>\n  <div class=\"PermalinkOverlay-modal\">\n    <div class=\"PermalinkOverlay-spinnerContainer u-hidden\">\n      <div class=\"PermalinkOverlay-spinner\"></div>\n    </div>\n    <div class=\"PermalinkOverlay-content\">\n      <div class=\"PermalinkOverlay-body\">\n      </div>\n    </div>\n  </div>\n</div>\n\n    <div class=\"hidden\" id=\"hidden-content\">\n  <iframe aria-hidden=\"true\" class=\"tweet-post-iframe\" name=\"tweet-post-iframe\"></iframe>\n  <iframe aria-hidden=\"true\" class=\"dm-post-iframe\" name=\"dm-post-iframe\"></iframe>\n\n</div>\n\n    <script nonce=\"\" id=\"track-ttft-body-script\">\n  if(window.ttft){\n    window.ttft.recordMilestone('page', document.getElementById('swift-page-name').getAttribute('content'));\n    window.ttft.recordMilestone('section', document.getElementById('swift-section-name').getAttribute('content'));\n    window.ttft.recordMilestone('client_record_time', window.ttft.now());\n  }\n</script>\n\n    \n      <input type=\"hidden\" id=\"init-data\" class=\"json-data\" value=\"{&quot;keyboardShortcuts&quot;:[{&quot;name&quot;:&quot;Handlingar&quot;,&quot;description&quot;:&quot;Genv\\u00e4gar f\\u00f6r vanliga handlingar.&quot;,&quot;shortcuts&quot;:[{&quot;keys&quot;:[&quot;Enter&quot;],&quot;description&quot;:&quot;Detaljer&quot;},{&quot;keys&quot;:[&quot;o&quot;],&quot;description&quot;:&quot;F\\u00f6rstora foto&quot;},{&quot;keys&quot;:[&quot;\\/&quot;],&quot;description&quot;:&quot;S\\u00f6k&quot;}]},{&quot;name&quot;:&quot;Navigering&quot;,&quot;description&quot;:&quot;Genv\\u00e4gar f\\u00f6r navigering mellan objekt i tidslinjer.&quot;,&quot;shortcuts&quot;:[{&quot;keys&quot;:[&quot;?&quot;],&quot;description&quot;:&quot;Denna meny&quot;},{&quot;keys&quot;:[&quot;j&quot;],&quot;description&quot;:&quot;N\\u00e4sta tweet&quot;},{&quot;keys&quot;:[&quot;k&quot;],&quot;description&quot;:&quot;F\\u00f6reg\\u00e5ende tweet&quot;},{&quot;keys&quot;:[&quot;Space&quot;],&quot;description&quot;:&quot;Scrolla ner&quot;},{&quot;keys&quot;:[&quot;.&quot;],&quot;description&quot;:&quot;Ladda nya Tweets&quot;}]},{&quot;name&quot;:&quot;Tidslinjer&quot;,&quot;description&quot;:&quot;Genv\\u00e4gar f\\u00f6r navigering till olika tidslinjer eller sidor.&quot;,&quot;shortcuts&quot;:[{&quot;keys&quot;:[&quot;g&quot;,&quot;u&quot;],&quot;description&quot;:&quot;G\\u00e5 till anv\\u00e4ndare\\u2026&quot;}]}],&quot;baseFoucClass&quot;:&quot;swift-loading&quot;,&quot;bodyFoucClassNames&quot;:&quot;swift-loading&quot;,&quot;assetsBasePath&quot;:&quot;https:\\/\\/abs.twimg.com\\/a\\/1530627074\\/&quot;,&quot;assetVersionKey&quot;:&quot;e860c9&quot;,&quot;emojiAssetsPath&quot;:&quot;https:\\/\\/abs.twimg.com\\/emoji\\/v2\\/72x72\\/&quot;,&quot;environment&quot;:&quot;production&quot;,&quot;formAuthenticityToken&quot;:&quot;742399c8223e1e6dd4dcb9293528a1721f67a538&quot;,&quot;loggedIn&quot;:false,&quot;screenName&quot;:null,&quot;fullName&quot;:null,&quot;userId&quot;:null,&quot;guestId&quot;:&quot;153071658697800112&quot;,&quot;createdAt&quot;:null,&quot;needsPhoneVerification&quot;:false,&quot;allowAdsPersonalization&quot;:true,&quot;scribeBufferSize&quot;:3,&quot;pageName&quot;:&quot;front&quot;,&quot;sectionName&quot;:&quot;front&quot;,&quot;scribeParameters&quot;:{},&quot;recaptchaApiUrl&quot;:&quot;https:\\/\\/www.google.com\\/recaptcha\\/api\\/js\\/recaptcha_ajax.js&quot;,&quot;internalReferer&quot;:null,&quot;geoEnabled&quot;:false,&quot;typeaheadData&quot;:{&quot;accounts&quot;:{&quot;enabled&quot;:true,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:true,&quot;limit&quot;:6},&quot;trendLocations&quot;:{&quot;enabled&quot;:true},&quot;dmConversations&quot;:{&quot;enabled&quot;:false},&quot;followedSearches&quot;:{&quot;enabled&quot;:false},&quot;savedSearches&quot;:{&quot;enabled&quot;:false,&quot;items&quot;:[]},&quot;dmAccounts&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:false,&quot;onlyDMable&quot;:true},&quot;mediaTagAccounts&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:false,&quot;onlyShowUsersWithCanMediaTag&quot;:false,&quot;currentUserId&quot;:-1},&quot;selectedUsers&quot;:{&quot;enabled&quot;:false},&quot;prefillUsers&quot;:{&quot;enabled&quot;:false},&quot;topics&quot;:{&quot;enabled&quot;:true,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:true,&quot;prefetchLimit&quot;:500,&quot;limit&quot;:4},&quot;concierge&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:false,&quot;prefetchLimit&quot;:500,&quot;limit&quot;:6},&quot;recentSearches&quot;:{&quot;enabled&quot;:false},&quot;hashtags&quot;:{&quot;enabled&quot;:false,&quot;localQueriesEnabled&quot;:false,&quot;remoteQueriesEnabled&quot;:true,&quot;prefetchLimit&quot;:500},&quot;useIndexedDB&quot;:false,&quot;showSearchAccountSocialContext&quot;:false,&quot;showDebugInfo&quot;:false,&quot;useThrottle&quot;:true,&quot;accountsOnTop&quot;:false,&quot;remoteDebounceInterval&quot;:300,&quot;remoteThrottleInterval&quot;:300,&quot;tweetContextEnabled&quot;:false,&quot;fullNameMatchingInCompose&quot;:true,&quot;topicsWithFiltersEnabled&quot;:false},&quot;shellReferrer&quot;:null,&quot;dm&quot;:{&quot;notifications&quot;:false,&quot;usePushForNotifications&quot;:true,&quot;participant_max&quot;:50,&quot;welcome_message_add_to_conversation_enabled&quot;:true,&quot;poll_options&quot;:{&quot;foreground_poll_interval&quot;:3000,&quot;burst_poll_interval&quot;:3000,&quot;burst_poll_duration&quot;:300000,&quot;max_poll_interval&quot;:60000},&quot;card_prefetch&quot;:true,&quot;card_prefetch_interval_in_seconds&quot;:2000,&quot;dm_quick_reply_options_panel_dismiss_in_ms&quot;:2000,&quot;open_dm_enabled&quot;:false},&quot;autoplayDisabled&quot;:false,&quot;pushStatePageLimit&quot;:500000,&quot;routes&quot;:{&quot;profile&quot;:&quot;\\/&quot;},&quot;pushState&quot;:true,&quot;viewContainer&quot;:&quot;#doc&quot;,&quot;href&quot;:&quot;\\/&quot;,&quot;searchPathWithQuery&quot;:&quot;\\/search?q=query&amp;src=typd&quot;,&quot;composeAltText&quot;:false,&quot;night_mode_activated&quot;:false,&quot;user_color&quot;:null,&quot;deciders&quot;:{&quot;gdprAgeGateDialog&quot;:true,&quot;gdprSoftBounceDialog&quot;:true,&quot;geo_picker_incident_reset&quot;:true,&quot;custom_timeline_curation&quot;:false,&quot;native_notifications&quot;:true,&quot;disable_ajax_datatype_default_to_text&quot;:false,&quot;dm_polling_frequency_in_seconds&quot;:3000,&quot;dm_granular_mute_controls&quot;:true,&quot;enable_media_tag_prefetch&quot;:true,&quot;enableMacawNymizerConversionLanding&quot;:false,&quot;hqImageUploads&quot;:false,&quot;live_pipeline_consume&quot;:true,&quot;mqImageUploads&quot;:false,&quot;partnerIdSyncEnabled&quot;:true,&quot;sruMediaCategory&quot;:true,&quot;photoSruGifLimitMb&quot;:15,&quot;promoted_logging_force_post&quot;:true,&quot;promoted_video_logging_enabled&quot;:true,&quot;pushState&quot;:true,&quot;emojiNewCategory&quot;:false,&quot;contentEditablePlainTextOnly&quot;:false,&quot;web_client_api_stats&quot;:false,&quot;web_perftown_stats&quot;:true,&quot;web_perftown_ttft&quot;:false,&quot;web_client_events_ttft&quot;:true,&quot;log_push_state_ttft_metrics&quot;:true,&quot;web_sru_stats&quot;:false,&quot;web_upload_video&quot;:true,&quot;web_upload_video_advanced&quot;:false,&quot;upload_video_size&quot;:500,&quot;useVmapVariants&quot;:false,&quot;autoplayPreviewPreroll&quot;:true,&quot;moments_home_module&quot;:false,&quot;moments_lohp_enabled&quot;:true,&quot;enableNativePush&quot;:true,&quot;autoSubscribeNativePush&quot;:false,&quot;allowWebPushVapidUpgrade&quot;:true,&quot;stickersInteractivity&quot;:true,&quot;stickersInteractivityDuringLoading&quot;:true,&quot;stickersExperience&quot;:true,&quot;dynamic_video_ads_include_long_videos&quot;:true,&quot;push_state_size&quot;:1000,&quot;live_video_media_control_enabled&quot;:false,&quot;cards2_enable_periscope_card_transition&quot;:true,&quot;use_api_for_retweet_and_unretweet&quot;:false,&quot;use_api_for_follow_and_unfollow&quot;:true,&quot;edge_probe_enabled&quot;:false,&quot;like_over_http_client&quot;:true,&quot;enable_inline_location&quot;:true,&quot;enable_tweetstorm_creation&quot;:true,&quot;enable_tweetstorm_drafts&quot;:false,&quot;enable_tweetstorm_tooltip&quot;:true,&quot;text_length_for_tweetstorm_tooltip&quot;:50,&quot;dm_report_webview_macaw_swift_enabled&quot;:true,&quot;page_title_unread_notification_count&quot;:false,&quot;page_title_badge_after_unread_tweets&quot;:20},&quot;experiments&quot;:{},&quot;toasts_dm&quot;:false,&quot;toasts_timeline&quot;:false,&quot;toasts_dm_poll_scale&quot;:60,&quot;defaultNotificationIcon&quot;:&quot;https:\\/\\/abs.twimg.com\\/a\\/1530627074\\/img\\/t1\\/mobile\\/wp7_app_icon.png&quot;,&quot;promptbirdData&quot;:{&quot;promptbirdEnabled&quot;:false,&quot;immediateTriggers&quot;:[&quot;PullToRefresh&quot;,&quot;Navigate&quot;],&quot;format&quot;:null},&quot;passwordResetAdvancedLoginForm&quot;:true,&quot;skipAutoSignupDialog&quot;:false,&quot;shouldReplaceSignupWithLogin&quot;:false,&quot;hashflagBaseUrl&quot;:&quot;https:\\/\\/abs.twimg.com\\/hashflags\\/&quot;,&quot;activeHashflags&quot;:{&quot;growtogether&quot;:&quot;GrowTogether_v4\\/GrowTogether_v4.png&quot;,&quot;loveisland&quot;:&quot;LoveIsland2018_Flight1\\/LoveIsland2018_Flight1.png&quot;,&quot;payecommezlatan&quot;:&quot;Visa_WorldCup2018_v2\\/Visa_WorldCup2018_v2.png&quot;,&quot;beashinboner&quot;:&quot;BeAShinboner\\/BeAShinboner.png&quot;,&quot;مسابقة_العربية_للعود&quot;:&quot;ArabianOud2018\\/ArabianOud2018.png&quot;,&quot;jurassicworldfallenkingdom&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;michaelmyersmondays&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;nuestracopa&quot;:&quot;Cruzcampo_2018\\/Cruzcampo_2018.png&quot;,&quot;स्वाभिमान_जुलूस&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;cmtmusicawards&quot;:&quot;CMTAwards2018_v2\\/CMTAwards2018_v2.png&quot;,&quot;mymammamia&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;cabelopantene&quot;:&quot;CabeloPanten\\/CabeloPanten.png&quot;,&quot;magicinsandiego&quot;:&quot;fantasticbeasts_v4\\/fantasticbeasts_v4.png&quot;,&quot;megatubarão&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;nycfireworks&quot;:&quot;Macys_Fireworks_2018\\/Macys_Fireworks_2018.png&quot;,&quot;incrediblesevent&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;kathnielforvivo&quot;:&quot;Kathniel\\/Kathniel.png&quot;,&quot;roséwine&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;samsungaddwash&quot;:&quot;SpainSamsungAddwash\\/SpainSamsungAddwash.png&quot;,&quot;blindal&quot;:&quot;Deadpool2_BlindAl\\/Deadpool2_BlindAl.png&quot;,&quot;thewasp&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;バチェラージャパン&quot;:&quot;BachelorJapanS2_v2\\/BachelorJapanS2_v2.png&quot;,&quot;freesmurf&quot;:&quot;TNTAnimalKingdomS3\\/TNTAnimalKingdomS3.png&quot;,&quot;abrazodegoles&quot;:&quot;ClaroPeru2018_v2\\/ClaroPeru2018_v2.png&quot;,&quot;giveadam&quot;:&quot;Skittles_GIVEaDAM\\/Skittles_GIVEaDAM.png&quot;,&quot;प्यार_की_जीत&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;ger&quot;:&quot;WorldCup_Germany_v2\\/WorldCup_Germany_v2.png&quot;,&quot;cmgngmtoddy&quot;:&quot;ToddyBrasil_2018\\/ToddyBrasil_2018.png&quot;,&quot;informeddelivery&quot;:&quot;USPSInformedDelivery\\/USPSInformedDelivery.png&quot;,&quot;worldcup&quot;:&quot;WorldCup_2018\\/WorldCup_2018.png&quot;,&quot;teamjurassic&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;انت_بطل&quot;:&quot;BeYourOwnChampion_WorldCup\\/BeYourOwnChampion_WorldCup.png&quot;,&quot;frozone&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;츄바카&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;micheladaclamato&quot;:&quot;Clamato_2018\\/Clamato_2018.png&quot;,&quot;porcinet&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;okuldışarıdagünü&quot;:&quot;DirtIsGood_Persil\\/DirtIsGood_Persil.png&quot;,&quot;desfileorgullo&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;ballparkburger&quot;:&quot;BallparkHotDog2018\\/BallparkHotDog2018.png&quot;,&quot;エアアジア&quot;:&quot;AirAsia2018_v2\\/AirAsia2018_v2.png&quot;,&quot;ballparkhotdog&quot;:&quot;BallparkHotDog2018\\/BallparkHotDog2018.png&quot;,&quot;에드나모드&quot;:&quot;Ednamode_v3\\/Ednamode_v3.png&quot;,&quot;nadanosdetiene&quot;:&quot;WorldCup_Mexico_v3\\/WorldCup_Mexico_v3.png&quot;,&quot;timesup&quot;:&quot;TimesUp_v2\\/TimesUp_v2.png&quot;,&quot;thealienist&quot;:&quot;TNT-Alienist\\/TNT-Alienist.png&quot;,&quot;labarramaspower&quot;:&quot;Entel_Mundial_Peru_v2\\/Entel_Mundial_Peru_v2.png&quot;,&quot;ハンソロ&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;روسيا2018&quot;:&quot;WorldCup_2018\\/WorldCup_2018.png&quot;,&quot;nacaradogol&quot;:&quot;UberWorldCup_2018\\/UberWorldCup_2018.png&quot;,&quot;日野社長&quot;:&quot;YokaiWatchWorld_Komasan_v2\\/YokaiWatchWorld_Komasan_v2.png&quot;,&quot;монстрглубины&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;totalbedlam&quot;:&quot;Deadpool2_Bedlam\\/Deadpool2_Bedlam.png&quot;,&quot;sanhok&quot;:&quot;PubGEmoji_v3\\/PubGEmoji_v3.png&quot;,&quot;イーヨー&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;juegueargentina&quot;:&quot;Naranja_Argentina_WorldCup\\/Naranja_Argentina_WorldCup.png&quot;,&quot;프라이드2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;dirtywater&quot;:&quot;redsox2018_v2\\/redsox2018_v2.png&quot;,&quot;suncoastproud&quot;:&quot;SuperNetball_SunCoastProud\\/SuperNetball_SunCoastProud.png&quot;,&quot;flickertourlive&quot;:&quot;NiallHoran2018\\/NiallHoran2018.png&quot;,&quot;بصمة&quot;:&quot;ArabianOud2018\\/ArabianOud2018.png&quot;,&quot;animalkingdomtnt&quot;:&quot;TNTAnimalKingdomS3\\/TNTAnimalKingdomS3.png&quot;,&quot;hereditary&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;mntwins&quot;:&quot;MinnesotaTwins2018\\/MinnesotaTwins2018.png&quot;,&quot;インクレディブルファミリー&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;yanohayexcusas&quot;:&quot;SpainSamsungAddwash\\/SpainSamsungAddwash.png&quot;,&quot;itaipavapremium&quot;:&quot;ItaipavaMasterchefAmadores\\/ItaipavaMasterchefAmadores.png&quot;,&quot;نصيحة_ناس&quot;:&quot;Flynas2018_v2\\/Flynas2018_v2.png&quot;,&quot;pridemonth&quot;:&quot;TwitterOpen_Pride2018_PrideMonth\\/TwitterOpen_Pride2018_PrideMonth.png&quot;,&quot;プーさん&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;superflymovie&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;ió&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;maisémais&quot;:&quot;BrazilNaturaAquarela\\/BrazilNaturaAquarela.png&quot;,&quot;dopinder&quot;:&quot;Deadpool2_Dopinder\\/Deadpool2_Dopinder.png&quot;,&quot;thenunpt&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;moveforward&quot;:&quot;MoveForward_UberIndia_v2\\/MoveForward_UberIndia_v2.png&quot;,&quot;amoréamor&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;volvióel3x10&quot;:&quot;CristalPeruMundial\\/CristalPeruMundial.png&quot;,&quot;myersmonday&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;frose&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;hinchasincondicionales&quot;:&quot;MundialMovistar2018_v2\\/MundialMovistar2018_v2.png&quot;,&quot;drunkhistory&quot;:&quot;DrunkHistory_2018\\/DrunkHistory_2018.png&quot;,&quot;wnba&quot;:&quot;WNBALeagueEmoji\\/WNBALeagueEmoji.png&quot;,&quot;notepierdasnada&quot;:&quot;Visa_LatinAmerica_WorldCup\\/Visa_LatinAmerica_WorldCup.png&quot;,&quot;juegaméxico&quot;:&quot;coronafutbol2018\\/coronafutbol2018.png&quot;,&quot;themeg&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;halloweenmovie&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;periscope&quot;:&quot;Periscope\\/Periscope.png&quot;,&quot;jurassiclondon&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;naopercanada&quot;:&quot;Visa_LatinAmerica_WorldCup_naopercanada\\/Visa_LatinAmerica_WorldCup_naopercanada.png&quot;,&quot;wantafanta&quot;:&quot;FantaSummer2018_WantaFanta\\/FantaSummer2018_WantaFanta.png&quot;,&quot;dashparr&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;marchforourlivesspotlight&quot;:&quot;MarchforOurLivesSpotlight\\/MarchforOurLivesSpotlight.png&quot;,&quot;macysfireworks&quot;:&quot;Macys_Fireworks_2018\\/Macys_Fireworks_2018.png&quot;,&quot;roséallday&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;chewbacca&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;ifeelprettyfilm&quot;:&quot;feelpretty_v2\\/feelpretty_v2.png&quot;,&quot;orgullo&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;violetaparr&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;experimentojun&quot;:&quot;SpainSamsungAddwash\\/SpainSamsungAddwash.png&quot;,&quot;bestoftweets&quot;:&quot;BestofTweets2018\\/BestofTweets2018.png&quot;,&quot;whatisfly&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;nialllive&quot;:&quot;NiallHoran2018\\/NiallHoran2018.png&quot;,&quot;superflylook&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;animalifantastici&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;jackjackparr&quot;:&quot;JackJack_2\\/JackJack_2.png&quot;,&quot;animauxfantastiques&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;真爱无敌&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;theantman&quot;:&quot;Disney_AntManMovie_2018\\/Disney_AntManMovie_2018.png&quot;,&quot;rolltide&quot;:&quot;Alabama_CFBPlayoff_Teamv3\\/Alabama_CFBPlayoff_Teamv3.png&quot;,&quot;lovetwitter&quot;:&quot;LoveTwitter\\/LoveTwitter.png&quot;,&quot;もしもマンガが全巻無料なら&quot;:&quot;NTTSolmare2018_v2\\/NTTSolmare2018_v2.png&quot;,&quot;суперсемейка2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;endalz&quot;:&quot;AlzheimersAssociation2018_v2\\/AlzheimersAssociation2018_v2.png&quot;,&quot;тигруля&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;demuestraquecrees&quot;:&quot;CocaColaMXWorldCup2018\\/CocaColaMXWorldCup2018.png&quot;,&quot;rootedinoakland&quot;:&quot;OaklandAthletics2018\\/OaklandAthletics2018.png&quot;,&quot;texasrangers&quot;:&quot;TexasRangers2018\\/TexasRangers2018.png&quot;,&quot;volvooceanrace&quot;:&quot;VolvoOceanRace\\/VolvoOceanRace.png&quot;,&quot;macys4thofjulyfireworks&quot;:&quot;Macys_Fireworks_2018\\/Macys_Fireworks_2018.png&quot;,&quot;dimamaghreb&quot;:&quot;WorldCup_Morocco_v2\\/WorldCup_Morocco_v2.png&quot;,&quot;tebancamosselección&quot;:&quot;Naranja_Argentina_WorldCup\\/Naranja_Argentina_WorldCup.png&quot;,&quot;mammamia&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;ungolunpotrero&quot;:&quot;Naranja_Argentina_WorldCup\\/Naranja_Argentina_WorldCup.png&quot;,&quot;인크레더블2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;آية_وقيمة&quot;:&quot;MiskValues2018\\/MiskValues2018.png&quot;,&quot;espejopublico&quot;:&quot;EspejoPublico_2017_2018\\/EspejoPublico_2017_2018.png&quot;,&quot;骄傲游行&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;badisbred&quot;:&quot;TNTAnimalKingdomS3\\/TNTAnimalKingdomS3.png&quot;,&quot;losincreíbles2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;lajugadaganadora&quot;:&quot;MundialClaro_2018\\/MundialClaro_2018.png&quot;,&quot;chewie&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;soloastarwarsstory&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;rockies25th&quot;:&quot;ColoradoRockies2018\\/ColoradoRockies2018.png&quot;,&quot;よまにゃ&quot;:&quot;ShueishaBrand_2018_v4\\/ShueishaBrand_2018_v4.png&quot;,&quot;медвежоноквинни&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;nocapes&quot;:&quot;Ednamode_v3\\/Ednamode_v3.png&quot;,&quot;bethechange&quot;:&quot;BeTheChange_v2\\/BeTheChange_v2.png&quot;,&quot;лэндо&quot;:&quot;StarWarsSolo_Lando\\/StarWarsSolo_Lando.png&quot;,&quot;canadiandream&quot;:&quot;ChevroletCanadianDream2018\\/ChevroletCanadianDream2018.png&quot;,&quot;tun&quot;:&quot;WorldCup_Tunisia_v2\\/WorldCup_Tunisia_v2.png&quot;,&quot;followtheball&quot;:&quot;waltdisneyoscars2018\\/waltdisneyoscars2018.png&quot;,&quot;valla&quot;:&quot;FranceBlizzardOWL_LAValiant\\/FranceBlizzardOWL_LAValiant.png&quot;,&quot;comigoninguémtoddy&quot;:&quot;ToddyBrasil_ComigoNinguemToddy\\/ToddyBrasil_ComigoNinguemToddy.png&quot;,&quot;avec3millions&quot;:&quot;FDJWorldCup2018\\/FDJWorldCup2018.png&quot;,&quot;tigro&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;crimesofgrindelwald&quot;:&quot;fantasticbeasts_v4\\/fantasticbeasts_v4.png&quot;,&quot;출동준비완료&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;shieldsup&quot;:&quot;FranceBlizzardOWL_LAGladiators\\/FranceBlizzardOWL_LAGladiators.png&quot;,&quot;thechevroletrace&quot;:&quot;TheChevroletRace_2018\\/TheChevroletRace_2018.png&quot;,&quot;millenniumfalcon&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;senhorincrível&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;صقورنا_قدها&quot;:&quot;SaudiAirline_2018\\/SaudiAirline_2018.png&quot;,&quot;elastigirl&quot;:&quot;MrsIncredible\\/MrsIncredible.png&quot;,&quot;loveislandaftersun&quot;:&quot;LoveIsland2018_Flight1\\/LoveIsland2018_Flight1.png&quot;,&quot;wannasprite&quot;:&quot;Sprite_summer2018\\/Sprite_summer2018.png&quot;,&quot;unmomentoespecial&quot;:&quot;ABIMexico_ModeloCafe\\/ABIMexico_ModeloCafe.png&quot;,&quot;ダブルウェア&quot;:&quot;EsteeLauder_DoubleWear\\/EsteeLauder_DoubleWear.png&quot;,&quot;somosnuevaraza&quot;:&quot;Bancolombia_SomosNuevaRaza\\/Bancolombia_SomosNuevaRaza.png&quot;,&quot;onurhaftası&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;mercwithamouth&quot;:&quot;Deadpool2_Deadpool\\/Deadpool2_Deadpool.png&quot;,&quot;labarramáspower&quot;:&quot;Entel_Mundial_Peru_v2\\/Entel_Mundial_Peru_v2.png&quot;,&quot;7afl&quot;:&quot;AFL2018\\/AFL2018.png&quot;,&quot;michelada&quot;:&quot;Clamato_2018\\/Clamato_2018.png&quot;,&quot;amtodmbfn&quot;:&quot;BuzzFeedMorning_v3\\/BuzzFeedMorning_v3.png&quot;,&quot;bachelorjapan&quot;:&quot;BachelorJapanS2_v2\\/BachelorJapanS2_v2.png&quot;,&quot;torcidan1&quot;:&quot;brahma_flight2\\/brahma_flight2.png&quot;,&quot;asksweetbitter&quot;:&quot;STARZSweetbitter18\\/STARZSweetbitter18.png&quot;,&quot;ナツイチの日&quot;:&quot;ShueishaBrand_2018_v4\\/ShueishaBrand_2018_v4.png&quot;,&quot;mammamia2movie&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;juntosmiami&quot;:&quot;MiamiMarlins2018\\/MiamiMarlins2018.png&quot;,&quot;爱就是爱&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;myxmusicawards2018&quot;:&quot;MYXMusicAwards2018\\/MYXMusicAwards2018.png&quot;,&quot;toystoryland&quot;:&quot;waltdisneyoscars2018\\/waltdisneyoscars2018.png&quot;,&quot;onthebus&quot;:&quot;NRLTigers2018\\/NRLTigers2018.png&quot;,&quot;allontheline&quot;:&quot;SuperNetball_Allontheline\\/SuperNetball_Allontheline.png&quot;,&quot;btsxspotify&quot;:&quot;SpotifyBTS2018_v2\\/SpotifyBTS2018_v2.png&quot;,&quot;fallenkingdom&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;onurhaftası2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;마이베스트일레븐&quot;:&quot;MyBestEleven2018\\/MyBestEleven2018.png&quot;,&quot;jurassicnight&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;flamingpride&quot;:&quot;WorldCup_Croatia_v2\\/WorldCup_Croatia_v2.png&quot;,&quot;アントマン&quot;:&quot;Disney_Antman_2018\\/Disney_Antman_2018.png&quot;,&quot;letsgobucs&quot;:&quot;PittsburghPirates2018\\/PittsburghPirates2018.png&quot;,&quot;١٠٠_متعة_في_القيادة&quot;:&quot;VW_JoysofDriving\\/VW_JoysofDriving.png&quot;,&quot;مسابقة_طيران_ناس&quot;:&quot;Flynas2018_v2\\/Flynas2018_v2.png&quot;,&quot;фиалкапарр&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;جمعية_زمزم_لجسد_واحد&quot;:&quot;ZamzamSociety2018\\/ZamzamSociety2018.png&quot;,&quot;comicstaan&quot;:&quot;APVIndiaComicstaan\\/APVIndiaComicstaan.png&quot;,&quot;nestleextreme&quot;:&quot;NestleExtreme_2018\\/NestleExtreme_2018.png&quot;,&quot;rosé&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;waspwings&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;ワスプ&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;स्वाभिमान&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;aus&quot;:&quot;WorldCup_Australia_v2\\/WorldCup_Australia_v2.png&quot;,&quot;mammamiaherewegoagain&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;gliincredibili2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;оса&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;3lionsroar&quot;:&quot;WilliamHillWorldCup2018\\/WilliamHillWorldCup2018.png&quot;,&quot;smallfoot&quot;:&quot;WM_Smallfoot\\/WM_Smallfoot.png&quot;,&quot;alentadoresseriales&quot;:&quot;YPHArgentina_WorldCup\\/YPHArgentina_WorldCup.png&quot;,&quot;amtodm&quot;:&quot;BuzzFeedMorning_v3\\/BuzzFeedMorning_v3.png&quot;,&quot;maythefourth&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;qira&quot;:&quot;StarWarsSolo_Qira\\/StarWarsSolo_Qira.png&quot;,&quot;got7&quot;:&quot;GOT7WORLDTOUR_2018\\/GOT7WORLDTOUR_2018.png&quot;,&quot;sharpobjectshbo&quot;:&quot;HBOSharpObjects\\/HBOSharpObjects.png&quot;,&quot;thematriline&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;orgulholgbt&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;sienteelsabor&quot;:&quot;CocaColaMXWorldCup2018\\/CocaColaMXWorldCup2018.png&quot;,&quot;iamopl&quot;:&quot;iamopl_v2\\/iamopl_v2.png&quot;,&quot;shocktheworld&quot;:&quot;FranceBlizzardOWL_SanFrancisco\\/FranceBlizzardOWL_SanFrancisco.png&quot;,&quot;amyadams&quot;:&quot;HBOSharpObjects\\/HBOSharpObjects.png&quot;,&quot;redtogether&quot;:&quot;WorldCup_Belgium_v2\\/WorldCup_Belgium_v2.png&quot;,&quot;ラインペイ&quot;:&quot;LinePay_Frenchfries\\/LinePay_Frenchfries.png&quot;,&quot;นักบอลแซ่บ&quot;:&quot;KbankxWorldcup\\/KbankxWorldcup.png&quot;,&quot;winnerwinnerchickendinner&quot;:&quot;PubGEmoji_v3\\/PubGEmoji_v3.png&quot;,&quot;am2dmbf&quot;:&quot;BuzzFeedMorning_v3\\/BuzzFeedMorning_v3.png&quot;,&quot;もんげー&quot;:&quot;YokaiWatchWorld_Komasan_v2\\/YokaiWatchWorld_Komasan_v2.png&quot;,&quot;orlovi&quot;:&quot;WorldCup_Serbia_v2\\/WorldCup_Serbia_v2.png&quot;,&quot;mrincreíble&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;妖怪ウォッチ&quot;:&quot;YokaiWatchWorld_Jibanyan\\/YokaiWatchWorld_Jibanyan.png&quot;,&quot;rêvecanadien&quot;:&quot;ChevroletCanadianDream2018\\/ChevroletCanadianDream2018.png&quot;,&quot;itseeyore&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;дэшпарр&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;nga&quot;:&quot;WorldCup_Nigeria_v2\\/WorldCup_Nigeria_v2.png&quot;,&quot;hansolo&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;tictocnews&quot;:&quot;bloombergtictoc2018\\/bloombergtictoc2018.png&quot;,&quot;thefourfox&quot;:&quot;Fox_TheFour_Season2\\/Fox_TheFour_Season2.png&quot;,&quot;winniepuuh&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;violetparr&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;любовьэтолюбовь&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;ガチ勢応援&quot;:&quot;GatsbyDeo2018\\/GatsbyDeo2018.png&quot;,&quot;manbooker50&quot;:&quot;ManBookerPrize50\\/ManBookerPrize50.png&quot;,&quot;conqueryourdream&quot;:&quot;WorldCup_Portugal_v2\\/WorldCup_Portugal_v2.png&quot;,&quot;rusia2018xmovistarplay&quot;:&quot;Rusia2018xMovistarPlay\\/Rusia2018xMovistarPlay.png&quot;,&quot;hereditarymovie&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;alômãe&quot;:&quot;BrazilWorldCup2018_AloMae_v3\\/BrazilWorldCup2018_AloMae_v3.png&quot;,&quot;amorgana&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;wimbledon&quot;:&quot;Wimbledon2018\\/Wimbledon2018.png&quot;,&quot;sorrytobotheryou&quot;:&quot;SorryToBotherYou2018\\/SorryToBotherYou2018.png&quot;,&quot;amoresamor&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;per&quot;:&quot;WorldCup_Peru_v2\\/WorldCup_Peru_v2.png&quot;,&quot;جرير_توصل&quot;:&quot;Jarir2018\\/Jarir2018.png&quot;,&quot;jurassic&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;addwash&quot;:&quot;SpainSamsungAddwash\\/SpainSamsungAddwash.png&quot;,&quot;supertroopers&quot;:&quot;SuperTroopers2\\/SuperTroopers2.png&quot;,&quot;walk2endalz&quot;:&quot;AlzheimersAssociation2018_v2\\/AlzheimersAssociation2018_v2.png&quot;,&quot;endalzheimers&quot;:&quot;AlzheimersAssociation2018_v2\\/AlzheimersAssociation2018_v2.png&quot;,&quot;sevgikazanır&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;nationaldinoday&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;zeitgeist116&quot;:&quot;Deadpool2_Zeitgeist\\/Deadpool2_Zeitgeist.png&quot;,&quot;thefuturelooksfunny&quot;:&quot;APVIndiaComicstaan\\/APVIndiaComicstaan.png&quot;,&quot;violettaparr&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;incrediblesday&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;アナザーエデン1周年&quot;:&quot;catemoji_v2\\/catemoji_v2.png&quot;,&quot;chaostakescontrol&quot;:&quot;westworldpremiere2018\\/westworldpremiere2018.png&quot;,&quot;fantasticbeasts&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;コマさん&quot;:&quot;YokaiWatchWorld_Komasan_v2\\/YokaiWatchWorld_Komasan_v2.png&quot;,&quot;प्यार_तो_प्यार_है&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;scratchoftheday&quot;:&quot;WilliamHillWorldCup2018\\/WilliamHillWorldCup2018.png&quot;,&quot;bluejays&quot;:&quot;TorontoBlueJays2018_v3\\/TorontoBlueJays2018_v3.png&quot;,&quot;مفاجات_وااو&quot;:&quot;SAIB\\/SAIB.png&quot;,&quot;thatssuperfly&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;adoptadino&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;winniethepooh&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;mammamiafilm&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;iaytsa&quot;:&quot;tecatemundial_v2\\/tecatemundial_v2.png&quot;,&quot;printmeaflight&quot;:&quot;GEAdaptive_2018_v3\\/GEAdaptive_2018_v3.png&quot;,&quot;prixbestoftweets&quot;:&quot;BestofTweets2018\\/BestofTweets2018.png&quot;,&quot;ballparkgrillin&quot;:&quot;BallparkHotDog2018\\/BallparkHotDog2018.png&quot;,&quot;بطاقة_كفاءة_الطاقة&quot;:&quot;SaudiEnergyEfficiencyCenter\\/SaudiEnergyEfficiencyCenter.png&quot;,&quot;maythefourthbewithyou&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;landocalrissian&quot;:&quot;StarWarsSolo_Lando\\/StarWarsSolo_Lando.png&quot;,&quot;みんなでシャンシャン5周年&quot;:&quot;LoveLiveKlab2018\\/LoveLiveKlab2018.png&quot;,&quot;redv&quot;:&quot;NRLRedV2018\\/NRLRedV2018.png&quot;,&quot;прайд2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;앤트맨&quot;:&quot;Disney_Antman_2018\\/Disney_Antman_2018.png&quot;,&quot;tundrapower&quot;:&quot;TundraPower2018_v3\\/TundraPower2018_v3.png&quot;,&quot;sweetbittertv&quot;:&quot;STARZSweetbitter18\\/STARZSweetbitter18.png&quot;,&quot;rallytogether&quot;:&quot;Cleveland2018\\/Cleveland2018.png&quot;,&quot;mentellall&quot;:&quot;TheBachelorette2018\\/TheBachelorette2018.png&quot;,&quot;westworld&quot;:&quot;HBOWestworld_Finale\\/HBOWestworld_Finale.png&quot;,&quot;starwarsday&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;mrindestructible&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;pagacomozlatan&quot;:&quot;Visa_WorldCup2018_v2\\/Visa_WorldCup2018_v2.png&quot;,&quot;bostonup&quot;:&quot;FranceBlizzardOWL_Boston\\/FranceBlizzardOWL_Boston.png&quot;,&quot;everybodyin&quot;:&quot;ChicagoCubs2018\\/ChicagoCubs2018.png&quot;,&quot;antmanmovie&quot;:&quot;Disney_AntManMovie_2018\\/Disney_AntManMovie_2018.png&quot;,&quot;欅坂10円ピンポン&quot;:&quot;LinePay_Frenchfries\\/LinePay_Frenchfries.png&quot;,&quot;bestoftweetsawards&quot;:&quot;BestofTweets2018\\/BestofTweets2018.png&quot;,&quot;avancamos&quot;:&quot;BrazillianFederalGov_Avancamos\\/BrazillianFederalGov_Avancamos.png&quot;,&quot;รักก็คือรัก&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;プリコネ&quot;:&quot;PriconneRedive2018\\/PriconneRedive2018.png&quot;,&quot;myincrediblesreview&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;gotitfrommymom&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;tonicollette&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;flynas&quot;:&quot;Flynas2018_v2\\/Flynas2018_v2.png&quot;,&quot;фреон&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;pubg&quot;:&quot;PubGEmoji_v3\\/PubGEmoji_v3.png&quot;,&quot;прайдпарад&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;jurassicpark&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;100joysofdriving&quot;:&quot;VW_JoysofDriving\\/VW_JoysofDriving.png&quot;,&quot;powertv&quot;:&quot;STARZPower_S5_Ghost\\/STARZPower_S5_Ghost.png&quot;,&quot;إثراء_رمضان&quot;:&quot;ArabLeadersSummit2018_v4\\/ArabLeadersSummit2018_v4.png&quot;,&quot;dominomf&quot;:&quot;Deadpool2_Domino\\/Deadpool2_Domino.png&quot;,&quot;mex&quot;:&quot;WorldCup_Mexico_v3\\/WorldCup_Mexico_v3.png&quot;,&quot;이요르&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;위니더푸&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;เดอะนัน&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;frosé&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;キリンレモントリビュート&quot;:&quot;KirinLemon90thAnniversary_2018\\/KirinLemon90thAnniversary_2018.png&quot;,&quot;kor&quot;:&quot;WorldCup_SouthKorea_v2\\/WorldCup_SouthKorea_v2.png&quot;,&quot;dodgers&quot;:&quot;LADodgers2018\\/LADodgers2018.png&quot;,&quot;avançamos&quot;:&quot;BrazillianFederalGov_Avancamos\\/BrazillianFederalGov_Avancamos.png&quot;,&quot;violetteparr&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;loveislandpodcast&quot;:&quot;LoveIsland2018_Flight2\\/LoveIsland2018_Flight2.png&quot;,&quot;cable&quot;:&quot;Deadpool2_Cable\\/Deadpool2_Cable.png&quot;,&quot;قدام_معنا&quot;:&quot;FordSaudiWomenDrive\\/FordSaudiWomenDrive.png&quot;,&quot;الفراعنة&quot;:&quot;WorldCup_Egypt_arabic\\/WorldCup_Egypt_arabic.png&quot;,&quot;partyroyale&quot;:&quot;ForniteBattleRoyale2018\\/ForniteBattleRoyale2018.png&quot;,&quot;onepursuit&quot;:&quot;WashingtonNationals2018\\/WashingtonNationals2018.png&quot;,&quot;tudopelaselecao&quot;:&quot;GuaranaCopa_2018\\/GuaranaCopa_2018.png&quot;,&quot;wearegeelong&quot;:&quot;WeAreGeelong_v2\\/WeAreGeelong_v2.png&quot;,&quot;proudibmer&quot;:&quot;IBMThink2018_extension\\/IBMThink2018_extension.png&quot;,&quot;nationaldinosaurday&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;ih-oh&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;deadpool2&quot;:&quot;Deadpool2_Deadpool\\/Deadpool2_Deadpool.png&quot;,&quot;line10円ピンポン&quot;:&quot;LinePay_Frenchfries\\/LinePay_Frenchfries.png&quot;,&quot;happymammasday&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;mammamiamovie&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;ڤيمتو&quot;:&quot;Vimto2018\\/Vimto2018.png&quot;,&quot;gorabbitohs&quot;:&quot;NRLsouths2018\\/NRLsouths2018.png&quot;,&quot;põepraforasuascores&quot;:&quot;BrazilNaturaAquarela\\/BrazilNaturaAquarela.png&quot;,&quot;wannafanta&quot;:&quot;FantaSummer2018\\/FantaSummer2018.png&quot;,&quot;чубакка&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;dubnation&quot;:&quot;NBA_2018_19_GSW_extension\\/NBA_2018_19_GSW_extension.png&quot;,&quot;beautyinai&quot;:&quot;HuaweiHonorQ2GlobalLaunch_v2\\/HuaweiHonorQ2GlobalLaunch_v2.png&quot;,&quot;carriebradshaw&quot;:&quot;HBOSexandtheCity2018\\/HBOSexandtheCity2018.png&quot;,&quot;برنامج_أصيل&quot;:&quot;SAIB\\/SAIB.png&quot;,&quot;lovewins&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;teamghost&quot;:&quot;STARZPower_S5_Ghost\\/STARZPower_S5_Ghost.png&quot;,&quot;starwars&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;dejemostodo&quot;:&quot;Naranja_Argentina_WorldCup\\/Naranja_Argentina_WorldCup.png&quot;,&quot;generationdbacks&quot;:&quot;ArizonaDBacks_v2\\/ArizonaDBacks_v2.png&quot;,&quot;thefour&quot;:&quot;Fox_TheFour_Season2\\/Fox_TheFour_Season2.png&quot;,&quot;niallhoranlive&quot;:&quot;NiallHoran2018\\/NiallHoran2018.png&quot;,&quot;summergrilling&quot;:&quot;BallparkHotDog2018\\/BallparkHotDog2018.png&quot;,&quot;sweetbitterstarz&quot;:&quot;STARZSweetbitter18\\/STARZSweetbitter18.png&quot;,&quot;airasia&quot;:&quot;AirAsia2018_v2\\/AirAsia2018_v2.png&quot;,&quot;ifeelprettymovie&quot;:&quot;feelpretty_v2\\/feelpretty_v2.png&quot;,&quot;アントマンとワスプ&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;マイベストイレブン&quot;:&quot;MyBestEleven2018\\/MyBestEleven2018.png&quot;,&quot;проклятиемонахини&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;кира&quot;:&quot;StarWarsSolo_Qira\\/StarWarsSolo_Qira.png&quot;,&quot;juntossomos10&quot;:&quot;MastercardSoccer\\/MastercardSoccer.png&quot;,&quot;ジャックジャック&quot;:&quot;JackJack_2\\/JackJack_2.png&quot;,&quot;megatubarao&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;juegamexico&quot;:&quot;coronafutbol2018\\/coronafutbol2018.png&quot;,&quot;negasonicteenagewarhead&quot;:&quot;Deadpool2_Negasonic\\/Deadpool2_Negasonic.png&quot;,&quot;afl&quot;:&quot;AFL18\\/AFL18.png&quot;,&quot;チューバッカ&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;نقدر_نفرحهم&quot;:&quot;ZamzamSociety2018\\/ZamzamSociety2018.png&quot;,&quot;pdomjnate&quot;:&quot;FranceBlizzardOWL_Philadelphia\\/FranceBlizzardOWL_Philadelphia.png&quot;,&quot;wethereds&quot;:&quot;WorldCup_SouthKorea_v2\\/WorldCup_SouthKorea_v2.png&quot;,&quot;크리스토퍼로빈과곰돌이푸&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;messiwithooredoo&quot;:&quot;Ooredoo_WorldCup\\/Ooredoo_WorldCup.png&quot;,&quot;teamkanan&quot;:&quot;STARZPower_S5_Kanan\\/STARZPower_S5_Kanan.png&quot;,&quot;espiglet&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;pimpi&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;todasascoresdasuabeleza&quot;:&quot;BrazilNaturaAquarela\\/BrazilNaturaAquarela.png&quot;,&quot;thedynastybegins&quot;:&quot;FranceBlizzardOWL_Seoul\\/FranceBlizzardOWL_Seoul.png&quot;,&quot;windgap&quot;:&quot;HBOSharpObjects\\/HBOSharpObjects.png&quot;,&quot;isl&quot;:&quot;WorldCup_Iceland_v2\\/WorldCup_Iceland_v2.png&quot;,&quot;zezé&quot;:&quot;JackJack_2\\/JackJack_2.png&quot;,&quot;ifeelpretty&quot;:&quot;feelpretty_v2\\/feelpretty_v2.png&quot;,&quot;rusiaentusmanosconclaro&quot;:&quot;MundialClaro_2018\\/MundialClaro_2018.png&quot;,&quot;miskvalues&quot;:&quot;MiskValues2018\\/MiskValues2018.png&quot;,&quot;ジバニャン&quot;:&quot;YokaiWatchWorld_Jibanyan\\/YokaiWatchWorld_Jibanyan.png&quot;,&quot;nowruz&quot;:&quot;nowruz2018_v4\\/nowruz2018_v4.png&quot;,&quot;rosewine&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;dinosaurday&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;yetivillage&quot;:&quot;WM_Smallfoot\\/WM_Smallfoot.png&quot;,&quot;mexicanelection&quot;:&quot;mexicanpresidentialelection2018\\/mexicanpresidentialelection2018.png&quot;,&quot;برنامج_وااو&quot;:&quot;SAIB\\/SAIB.png&quot;,&quot;デレステ&quot;:&quot;ImagscgStage2018\\/ImagscgStage2018.png&quot;,&quot;tigrou&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;thisismycrew&quot;:&quot;MilwaukeeBrewers2018\\/MilwaukeeBrewers2018.png&quot;,&quot;cmtawards2018&quot;:&quot;CMTAwards2018_v2\\/CMTAwards2018_v2.png&quot;,&quot;shatterstar&quot;:&quot;Deadpool2_Shatterstar\\/Deadpool2_Shatterstar.png&quot;,&quot;firetvcube&quot;:&quot;FireTVLaunch2018\\/FireTVLaunch2018.png&quot;,&quot;teampeter&quot;:&quot;Deadpool2_PeterW\\/Deadpool2_PeterW.png&quot;,&quot;sui&quot;:&quot;WorldCup_Switzerland_v3\\/WorldCup_Switzerland_v3.png&quot;,&quot;conquistaosonho&quot;:&quot;WorldCup_Portugal_v2\\/WorldCup_Portugal_v2.png&quot;,&quot;앤트맨과와스프&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;laavispa&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;alentemosunidos&quot;:&quot;CristalPeruMundial\\/CristalPeruMundial.png&quot;,&quot;cm2018&quot;:&quot;WorldCup_2018\\/WorldCup_2018.png&quot;,&quot;codyboys&quot;:&quot;TNTAnimalKingdomS3\\/TNTAnimalKingdomS3.png&quot;,&quot;antman&quot;:&quot;Disney_Antman_2018\\/Disney_Antman_2018.png&quot;,&quot;zahlewiezlatan&quot;:&quot;Visa_WorldCup2018_v2\\/Visa_WorldCup2018_v2.png&quot;,&quot;eeyore&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;satc20&quot;:&quot;HBOSexandtheCity2018\\/HBOSexandtheCity2018.png&quot;,&quot;프로존&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;energíaargentina&quot;:&quot;YPHArgentina_WorldCup\\/YPHArgentina_WorldCup.png&quot;,&quot;theshape&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;blackanda&quot;:&quot;BETAwards2018\\/BETAwards2018.png&quot;,&quot;solostarwars&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;govixens&quot;:&quot;SuperNetball_GoVixens\\/SuperNetball_GoVixens.png&quot;,&quot;ariaster&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;mytwitteranniversary&quot;:&quot;MyTwitterAnniversary\\/MyTwitterAnniversary.png&quot;,&quot;thrunthru&quot;:&quot;NRLtitans2018\\/NRLtitans2018.png&quot;,&quot;pride2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;สวัสดีบอลโลก&quot;:&quot;TrueCorp_WorldCup_2018\\/TrueCorp_WorldCup_2018.png&quot;,&quot;مسك_القيم&quot;:&quot;MiskValues2018\\/MiskValues2018.png&quot;,&quot;iaah&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;betawards2018&quot;:&quot;BETAwards2018\\/BETAwards2018.png&quot;,&quot;fordanmark&quot;:&quot;WorldCup_Denmark_v3\\/WorldCup_Denmark_v3.png&quot;,&quot;yaytza&quot;:&quot;tecatemundial_v2\\/tecatemundial_v2.png&quot;,&quot;comicstaantrailer&quot;:&quot;APVIndiaComicstaan\\/APVIndiaComicstaan.png&quot;,&quot;hatsoff4heroes&quot;:&quot;TMobile_HatsOff4Heroes_v2\\/TMobile_HatsOff4Heroes_v2.png&quot;,&quot;cheddarlive&quot;:&quot;Cheddar_Emoji_v4\\/Cheddar_Emoji_v4.png&quot;,&quot;ferkel&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;프라이드퍼레이드&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;それは最悪の一周年&quot;:&quot;Sinoalice2018\\/Sinoalice2018.png&quot;,&quot;prideparade&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;hatsoffforheroes&quot;:&quot;TMobile_HatsOff4Heroes_v2\\/TMobile_HatsOff4Heroes_v2.png&quot;,&quot;フロゾン&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;جمعية_زمزم&quot;:&quot;ZamzamSociety2018\\/ZamzamSociety2018.png&quot;,&quot;エドナ&quot;:&quot;Ednamode_v3\\/Ednamode_v3.png&quot;,&quot;ティガー&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;peterw&quot;:&quot;Deadpool2_PeterW\\/Deadpool2_PeterW.png&quot;,&quot;mundialendirecto&quot;:&quot;MEDIASET_Spain2018\\/MEDIASET_Spain2018.png&quot;,&quot;antmanandthewasp&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;myx21myfifaworldcup&quot;:&quot;Vivo_FIFA_2018\\/Vivo_FIFA_2018.png&quot;,&quot;إثراء&quot;:&quot;ArabLeadersSummit2018_v4\\/ArabLeadersSummit2018_v4.png&quot;,&quot;ksa&quot;:&quot;WorldCup_SaudiArabia_v2\\/WorldCup_SaudiArabia_v2.png&quot;,&quot;hopsuisse&quot;:&quot;WorldCup_Switzerland_v3\\/WorldCup_Switzerland_v3.png&quot;,&quot;tudopronto&quot;:&quot;CocaColaFWC_2018\\/CocaColaFWC_2018.png&quot;,&quot;letsmarchnova&quot;:&quot;VillanovaYearLong\\/VillanovaYearLong.png&quot;,&quot;alomae&quot;:&quot;BrazilWorldCup2018_AloMae_v3\\/BrazilWorldCup2018_AloMae_v3.png&quot;,&quot;чм2018&quot;:&quot;WorldCup_2018\\/WorldCup_2018.png&quot;,&quot;haloson&quot;:&quot;haloson\\/haloson.png&quot;,&quot;綾鷹ほうじ茶&quot;:&quot;cocacolaAyataka3\\/cocacolaAyataka3.png&quot;,&quot;프라이드&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;hinchaincondicional&quot;:&quot;MundialMovistar2018_v2\\/MundialMovistar2018_v2.png&quot;,&quot;fortheloveofhotdogs&quot;:&quot;OscarMayer_Weinermobile\\/OscarMayer_Weinermobile.png&quot;,&quot;tecnomobile&quot;:&quot;TranssionTecno2018\\/TranssionTecno2018.png&quot;,&quot;linepay&quot;:&quot;LinePay_Frenchfries\\/LinePay_Frenchfries.png&quot;,&quot;スターウォーズ&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;hansolostarwars&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;tudopelaseleçao&quot;:&quot;GuaranaCopa_2018\\/GuaranaCopa_2018.png&quot;,&quot;ランドカルリジアン&quot;:&quot;StarWarsSolo_Lando\\/StarWarsSolo_Lando.png&quot;,&quot;clamato&quot;:&quot;Clamato_2018\\/Clamato_2018.png&quot;,&quot;spotifyloveyourself&quot;:&quot;SpotifyBTS2018_v2\\/SpotifyBTS2018_v2.png&quot;,&quot;motog6&quot;:&quot;MotorolaG62018\\/MotorolaG62018.png&quot;,&quot;vivoxkathniel&quot;:&quot;Kathniel\\/Kathniel.png&quot;,&quot;джекджек&quot;:&quot;JackJack_2\\/JackJack_2.png&quot;,&quot;orgullo2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;sexandthecity20&quot;:&quot;HBOSexandtheCity2018\\/HBOSexandtheCity2018.png&quot;,&quot;tvoshortdoc&quot;:&quot;TVOShortDocs\\/TVOShortDocs.png&quot;,&quot;itspiglet&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;homemformiga&quot;:&quot;Disney_Antman_2018\\/Disney_Antman_2018.png&quot;,&quot;weflyasone&quot;:&quot;weflyasone_v2\\/weflyasone_v2.png&quot;,&quot;loveislove&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;familyoftheyear&quot;:&quot;ArrestedDevelopment2018\\/ArrestedDevelopment2018.png&quot;,&quot;flyeaglesfly&quot;:&quot;Eaglesv4\\/Eaglesv4.png&quot;,&quot;patd&quot;:&quot;PanicAtTheDisco_2018\\/PanicAtTheDisco_2018.png&quot;,&quot;podictions&quot;:&quot;LoveIsland2018_Flight2\\/LoveIsland2018_Flight2.png&quot;,&quot;violetapêra&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;티거&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;gigantespornatureza&quot;:&quot;WorldCup_Brazil_v2\\/WorldCup_Brazil_v2.png&quot;,&quot;flywithairasia&quot;:&quot;AirAsia2018_v2\\/AirAsia2018_v2.png&quot;,&quot;человекмуравей&quot;:&quot;Disney_Antman_2018\\/Disney_Antman_2018.png&quot;,&quot;bbklivedesconocido&quot;:&quot;NestleExtreme_2018\\/NestleExtreme_2018.png&quot;,&quot;잭잭&quot;:&quot;JackJack_2\\/JackJack_2.png&quot;,&quot;미스터인크레더블&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;budlighthouseparty&quot;:&quot;BudLight_HouseParty_2018\\/BudLight_HouseParty_2018.png&quot;,&quot;alienisttnt&quot;:&quot;TNT-Alienist\\/TNT-Alienist.png&quot;,&quot;イラスティガール&quot;:&quot;MrsIncredible\\/MrsIncredible.png&quot;,&quot;ウィスパー&quot;:&quot;YokaiWatchWorld_Whisper\\/YokaiWatchWorld_Whisper.png&quot;,&quot;lallavedelmundial&quot;:&quot;ClaroCAM\\/ClaroCAM.png&quot;,&quot;westworldhbo&quot;:&quot;HBOWestworld_Finale\\/HBOWestworld_Finale.png&quot;,&quot;somosargentina&quot;:&quot;WorldCup_Argentina_v2\\/WorldCup_Argentina_v2.png&quot;,&quot;espooh&quot;:&quot;ChristopherRobin_ItsPooh2018\\/ChristopherRobin_ItsPooh2018.png&quot;,&quot;orgullo18&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;energiaquenosune&quot;:&quot;YPHArgentina_WorldCup\\/YPHArgentina_WorldCup.png&quot;,&quot;netneutrality&quot;:&quot;Net_Emoji_v3\\/Net_Emoji_v3.png&quot;,&quot;кристоферробин&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;wheresbaz&quot;:&quot;TNTAnimalKingdomS3\\/TNTAnimalKingdomS3.png&quot;,&quot;prayforthewicked&quot;:&quot;PanicAtTheDisco_2018\\/PanicAtTheDisco_2018.png&quot;,&quot;thealienisttnt&quot;:&quot;TNT-Alienist\\/TNT-Alienist.png&quot;,&quot;paradadoorgulho&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;pridematters&quot;:&quot;PrideInLondon_2018\\/PrideInLondon_2018.png&quot;,&quot;roseallday&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;स्वाभिमान_2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;綾鷹&quot;:&quot;cocacolaAyataka3\\/cocacolaAyataka3.png&quot;,&quot;amtodmbf&quot;:&quot;BuzzFeedMorning_v3\\/BuzzFeedMorning_v3.png&quot;,&quot;llavemundialista&quot;:&quot;ClaroCAM\\/ClaroCAM.png&quot;,&quot;yaytsa&quot;:&quot;tecatemundial_v2\\/tecatemundial_v2.png&quot;,&quot;اداء_الابطال&quot;:&quot;BeYourOwnChampion_WorldCup\\/BeYourOwnChampion_WorldCup.png&quot;,&quot;internetpower&quot;:&quot;Entel_Mundial_Peru_v2\\/Entel_Mundial_Peru_v2.png&quot;,&quot;clawstnt&quot;:&quot;TNTClawsS2\\/TNTClawsS2.png&quot;,&quot;fyririsland&quot;:&quot;WorldCup_Iceland_v2\\/WorldCup_Iceland_v2.png&quot;,&quot;forzasvizzera&quot;:&quot;WorldCup_Switzerland_v3\\/WorldCup_Switzerland_v3.png&quot;,&quot;orgullgai2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;supertroopers420&quot;:&quot;SuperTroopers2\\/SuperTroopers2.png&quot;,&quot;eng&quot;:&quot;WorldCup_England_v2\\/WorldCup_England_v2.png&quot;,&quot;schinnonordestão&quot;:&quot;SchinNordestao2018\\/SchinNordestao2018.png&quot;,&quot;معاك_يالاخضر&quot;:&quot;WorldCup_SaudiArabia_v2\\/WorldCup_SaudiArabia_v2.png&quot;,&quot;レベルファイブ&quot;:&quot;YokaiWatchWorld_Jibanyan\\/YokaiWatchWorld_Jibanyan.png&quot;,&quot;プリ米&quot;:&quot;PriconneRedive2018\\/PriconneRedive2018.png&quot;,&quot;aviationseason&quot;:&quot;GEAdaptive_2018_v3\\/GEAdaptive_2018_v3.png&quot;,&quot;makeamericabluthagain&quot;:&quot;ArrestedDevelopment2018\\/ArrestedDevelopment2018.png&quot;,&quot;любовьпобеждает&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;osincríveis2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;お茶にしましょう綾鷹&quot;:&quot;cocacolaAyataka3\\/cocacolaAyataka3.png&quot;,&quot;fortnite&quot;:&quot;ForniteBattleRoyale2018\\/ForniteBattleRoyale2018.png&quot;,&quot;funaayega&quot;:&quot;APVIndiaComicstaan\\/APVIndiaComicstaan.png&quot;,&quot;nbatwitter&quot;:&quot;NBATwitter_Emoji___v5\\/NBATwitter_Emoji___v5.png&quot;,&quot;gelado&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;flythefuture&quot;:&quot;GEAdaptive_2018_v3\\/GEAdaptive_2018_v3.png&quot;,&quot;upupcronulla&quot;:&quot;NRLsharks2018\\/NRLsharks2018.png&quot;,&quot;inplaywithray&quot;:&quot;bet365RayWinstone_v2\\/bet365RayWinstone_v2.png&quot;,&quot;chelaycafé&quot;:&quot;ABIMexico_ModeloCafe\\/ABIMexico_ModeloCafe.png&quot;,&quot;كفاءة&quot;:&quot;SaudiEnergyEfficiencyCenter\\/SaudiEnergyEfficiencyCenter.png&quot;,&quot;themegza&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;bebold&quot;:&quot;PhiladelphiaPhillies2018\\/PhiladelphiaPhillies2018.png&quot;,&quot;tvoshortdocs&quot;:&quot;TVOShortDocs\\/TVOShortDocs.png&quot;,&quot;poptarts&quot;:&quot;PopTarts_2018\\/PopTarts_2018.png&quot;,&quot;flyfridays&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;torcedorfanatico&quot;:&quot;RexonaWorldCupEmoji\\/RexonaWorldCupEmoji.png&quot;,&quot;lesrugissantsgaïndés&quot;:&quot;WorldCup_Senegal_v2\\/WorldCup_Senegal_v2.png&quot;,&quot;ピグレット&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;vistarapremiumeconomy&quot;:&quot;Vistara_2018\\/Vistara_2018.png&quot;,&quot;rus&quot;:&quot;WorldCup_Russia_v2\\/WorldCup_Russia_v2.png&quot;,&quot;prixbestoftweet&quot;:&quot;BestofTweets2018\\/BestofTweets2018.png&quot;,&quot;flashparr&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;wadewilson&quot;:&quot;Deadpool2_Deadpool\\/Deadpool2_Deadpool.png&quot;,&quot;outdoorclassroomday&quot;:&quot;DirtIsGood_Persil\\/DirtIsGood_Persil.png&quot;,&quot;骄傲&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;diadeaprenderbrincando&quot;:&quot;DirtIsGood_Persil\\/DirtIsGood_Persil.png&quot;,&quot;осликушастик&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;集英社文庫&quot;:&quot;ShueishaBrand_2018_v4\\/ShueishaBrand_2018_v4.png&quot;,&quot;votamexico&quot;:&quot;mexicanpresidentialelection2018\\/mexicanpresidentialelection2018.png&quot;,&quot;مركز_الملك_عبدالعزيز_الثقافي&quot;:&quot;ArabLeadersSummit2018_v4\\/ArabLeadersSummit2018_v4.png&quot;,&quot;eneauxtroubles&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;прайд&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;bobparr&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;orgullgai&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;tigger&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;unbelievablygood&quot;:&quot;Vistara_2018\\/Vistara_2018.png&quot;,&quot;begiant&quot;:&quot;GWSGIANTS\\/GWSGIANTS.png&quot;,&quot;thequeue&quot;:&quot;Wimbledon2018_TheQueue\\/Wimbledon2018_TheQueue.png&quot;,&quot;bourriquet&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;nationalroséday&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;sweetbitter&quot;:&quot;STARZSweetbitter18\\/STARZSweetbitter18.png&quot;,&quot;wcclassics&quot;:&quot;WilliamHillWorldCup2018\\/WilliamHillWorldCup2018.png&quot;,&quot;melbourneproud&quot;:&quot;NRLmelbourne2018\\/NRLmelbourne2018.png&quot;,&quot;siberius&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;ナツイチ&quot;:&quot;ShueishaBrand_2018_v4\\/ShueishaBrand_2018_v4.png&quot;,&quot;sweetbitterpremiere&quot;:&quot;STARZSweetbitter18\\/STARZSweetbitter18.png&quot;,&quot;lamamámáspower&quot;:&quot;Entel_Mundial_Peru_v2\\/Entel_Mundial_Peru_v2.png&quot;,&quot;leitão&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;paradadoorgulholgbt&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;wakandaweekend&quot;:&quot;BlackPantherHomeEnt2018\\/BlackPantherHomeEnt2018.png&quot;,&quot;lamorguanya&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;lesindestructibles2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;sfgiants&quot;:&quot;SFGiants2018\\/SFGiants2018.png&quot;,&quot;incondicionales&quot;:&quot;MundialMovistar2018_v2\\/MundialMovistar2018_v2.png&quot;,&quot;directorx&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;am2dm&quot;:&quot;BuzzFeedMorning_v3\\/BuzzFeedMorning_v3.png&quot;,&quot;骄傲2018&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;jpn&quot;:&quot;WorldCup_Japan_v2\\/WorldCup_Japan_v2.png&quot;,&quot;modelocafé&quot;:&quot;ABIMexico_ModeloCafe\\/ABIMexico_ModeloCafe.png&quot;,&quot;whatblackpanthermeanstome&quot;:&quot;BlackPantherHomeEnt2018\\/BlackPantherHomeEnt2018.png&quot;,&quot;todoestáporver&quot;:&quot;vodafone2018\\/vodafone2018.png&quot;,&quot;egy&quot;:&quot;WorldCup_Egypt_v2\\/WorldCup_Egypt_v2.png&quot;,&quot;megustaelfútbol&quot;:&quot;MEDIASET_Spain2018\\/MEDIASET_Spain2018.png&quot;,&quot;chelaocafé&quot;:&quot;ABIMexico_ModeloCafe\\/ABIMexico_ModeloCafe.png&quot;,&quot;elecciones2018&quot;:&quot;mexicanpresidentialelection2018\\/mexicanpresidentialelection2018.png&quot;,&quot;homemformigaeavespa&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;bachelornation&quot;:&quot;TheBachelorette2018\\/TheBachelorette2018.png&quot;,&quot;wnbatakesastand&quot;:&quot;WNBATakesAStand3\\/WNBATakesAStand3.png&quot;,&quot;vamosticos&quot;:&quot;WorldCup_CostaRica_v2\\/WorldCup_CostaRica_v2.png&quot;,&quot;tuiteratura&quot;:&quot;FeriaDelHilo\\/FeriaDelHilo.png&quot;,&quot;burnblue&quot;:&quot;FranceBlizzardOWL_Dallas\\/FranceBlizzardOWL_Dallas.png&quot;,&quot;aisnextgxpeckbambam&quot;:&quot;PECKBAMBAM_2018\\/PECKBAMBAM_2018.png&quot;,&quot;gotgrit&quot;:&quot;SuperNetball_gotgrit\\/SuperNetball_gotgrit.png&quot;,&quot;lanonne&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;iamfirebird&quot;:&quot;SuperNetball_IAMFIREBIRD\\/SuperNetball_IAMFIREBIRD.png&quot;,&quot;mybesteleven&quot;:&quot;MyBestEleven2018\\/MyBestEleven2018.png&quot;,&quot;mar&quot;:&quot;WorldCup_Morocco_v2\\/WorldCup_Morocco_v2.png&quot;,&quot;キリンレモンのうた&quot;:&quot;KirinLemon90thAnniversary_2018\\/KirinLemon90thAnniversary_2018.png&quot;,&quot;honourthedream&quot;:&quot;WorldCup_Australia_v2\\/WorldCup_Australia_v2.png&quot;,&quot;abrazodegol&quot;:&quot;ClaroPeru2018_v2\\/ClaroPeru2018_v2.png&quot;,&quot;igór&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;powerstarz&quot;:&quot;STARZPower_S5_Ghost\\/STARZPower_S5_Ghost.png&quot;,&quot;wm2018&quot;:&quot;WorldCup_2018\\/WorldCup_2018.png&quot;,&quot;usps&quot;:&quot;USPSInformedDelivery\\/USPSInformedDelivery.png&quot;,&quot;โคตรหลามพันล้านปี&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;energíaquenosune&quot;:&quot;YPHArgentina_EnergiaQueNosUne\\/YPHArgentina_EnergiaQueNosUne.png&quot;,&quot;redscountry&quot;:&quot;CincinnatiReds2018\\/CincinnatiReds2018.png&quot;,&quot;votolibre&quot;:&quot;mexicanpresidentialelection2018\\/mexicanpresidentialelection2018.png&quot;,&quot;jogaoquesabe&quot;:&quot;FOX_JogaOQueSabe\\/FOX_JogaOQueSabe.png&quot;,&quot;mrincredible&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;プリコネ無料10連ガチャ&quot;:&quot;PriconneRedive2018\\/PriconneRedive2018.png&quot;,&quot;superflysoundtrack&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;advancingaviation&quot;:&quot;GEAdaptive_2018_v3\\/GEAdaptive_2018_v3.png&quot;,&quot;powerpremiere&quot;:&quot;STARZPower_S5_Ghost\\/STARZPower_S5_Ghost.png&quot;,&quot;flechapêra&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;loveyourselfxspotify&quot;:&quot;SpotifyBTS2018_v2\\/SpotifyBTS2018_v2.png&quot;,&quot;votebluth&quot;:&quot;ArrestedDevelopment2018\\/ArrestedDevelopment2018.png&quot;,&quot;comessasbolinhasngmtoddy&quot;:&quot;ToddyBrasil_2018\\/ToddyBrasil_2018.png&quot;,&quot;satanicgrandma&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;sousportvnacopa&quot;:&quot;SporTV_WorldCup\\/SporTV_WorldCup.png&quot;,&quot;cmtawards&quot;:&quot;CMTAwards2018_v2\\/CMTAwards2018_v2.png&quot;,&quot;jurassicjune&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;jurassicpark25&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;cmtawards18&quot;:&quot;CMTAwards2018_v2\\/CMTAwards2018_v2.png&quot;,&quot;mrインクレディブル&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;comigoninguemtoddy&quot;:&quot;ToddyBrasil_2018\\/ToddyBrasil_2018.png&quot;,&quot;แพ้ก็พลัสชนะก็พลัส&quot;:&quot;KbankxWorldcup\\/KbankxWorldcup.png&quot;,&quot;listospara&quot;:&quot;CocaColaMXWorldCup2018\\/CocaColaMXWorldCup2018.png&quot;,&quot;avespa&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;13の理由&quot;:&quot;NetflixJapan_13ReasonsWHy\\/NetflixJapan_13ReasonsWHy.png&quot;,&quot;푸&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;gotiges&quot;:&quot;gotiges\\/gotiges.png&quot;,&quot;thesecondcoming&quot;:&quot;Deadpool2_Deadpool\\/Deadpool2_Deadpool.png&quot;,&quot;appetitefordestruction&quot;:&quot;GunsNRoses_2018\\/GunsNRoses_2018.png&quot;,&quot;эднамод&quot;:&quot;Ednamode_v3\\/Ednamode_v3.png&quot;,&quot;mamamia2&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;estigger&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;col&quot;:&quot;WorldCup_Colombia_v2\\/WorldCup_Colombia_v2.png&quot;,&quot;ridemcowboys&quot;:&quot;NRLcowboys2018_v2\\/NRLcowboys2018_v2.png&quot;,&quot;teamforpirlo&quot;:&quot;UberEats_WorldCup\\/UberEats_WorldCup.png&quot;,&quot;hopsvizra&quot;:&quot;WorldCup_Switzerland_v3\\/WorldCup_Switzerland_v3.png&quot;,&quot;طيب_الله_فالك&quot;:&quot;ArabianOud2018\\/ArabianOud2018.png&quot;,&quot;letsgonewarriors&quot;:&quot;LetsGoneWarriors_v2\\/LetsGoneWarriors_v2.png&quot;,&quot;copa2018&quot;:&quot;WorldCup_2018\\/WorldCup_2018.png&quot;,&quot;betawards18&quot;:&quot;BETAwards2018\\/BETAwards2018.png&quot;,&quot;flexweave&quot;:&quot;reebokflexweave_v2\\/reebokflexweave_v2.png&quot;,&quot;myincredibles2review&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;tudopelaselecão&quot;:&quot;GuaranaCopa_2018\\/GuaranaCopa_2018.png&quot;,&quot;mulherelástica&quot;:&quot;MrsIncredible\\/MrsIncredible.png&quot;,&quot;thefouronfox&quot;:&quot;Fox_TheFour_Season2\\/Fox_TheFour_Season2.png&quot;,&quot;nationalroseday&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;takeonhistory&quot;:&quot;Wimbledon2018_TakeOnHistory\\/Wimbledon2018_TakeOnHistory.png&quot;,&quot;피글렛&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;eatlikeapro&quot;:&quot;EatLikeAPro2018V2\\/EatLikeAPro2018V2.png&quot;,&quot;الخطوط_توديك_روسيا&quot;:&quot;SaudiAirline_2018\\/SaudiAirline_2018.png&quot;,&quot;schinnonordestao&quot;:&quot;SchinNordestao2018\\/SchinNordestao2018.png&quot;,&quot;irn&quot;:&quot;WorldCup_Iran_v2\\/WorldCup_Iran_v2.png&quot;,&quot;halloweenmovieofficial&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;preparadosparatodo&quot;:&quot;WorldCup_Peru_v2\\/WorldCup_Peru_v2.png&quot;,&quot;tebancamosseleccion&quot;:&quot;Naranja_Argentina_TeBancamosSeleccion\\/Naranja_Argentina_TeBancamosSeleccion.png&quot;,&quot;한솔로&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;safetyatheart&quot;:&quot;MoveForward_UberIndia_v2\\/MoveForward_UberIndia_v2.png&quot;,&quot;shotenroute&quot;:&quot;MoveForward_UberIndia_v2\\/MoveForward_UberIndia_v2.png&quot;,&quot;christopherrobin&quot;:&quot;ChristopherRobin_ChristopherRobinfix\\/ChristopherRobin_ChristopherRobinfix.png&quot;,&quot;lamamamaspower&quot;:&quot;Entel_Mundial_Peru_v2\\/Entel_Mundial_Peru_v2.png&quot;,&quot;키라&quot;:&quot;StarWarsSolo_Qira\\/StarWarsSolo_Qira.png&quot;,&quot;winnielourson&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;100億円ガチャ&quot;:&quot;Sinoalice2018\\/Sinoalice2018.png&quot;,&quot;luckydomino&quot;:&quot;Deadpool2_Domino\\/Deadpool2_Domino.png&quot;,&quot;marchforourlives&quot;:&quot;marchforourlives\\/marchforourlives.png&quot;,&quot;vivov9kathniel&quot;:&quot;Kathniel\\/Kathniel.png&quot;,&quot;rusianosharáhéroes&quot;:&quot;tecatemundial_v2\\/tecatemundial_v2.png&quot;,&quot;onuryürüyüşü&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;theincredibles&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;vikingclap&quot;:&quot;VikingClap_2018_v2\\/VikingClap_2018_v2.png&quot;,&quot;لتبقى&quot;:&quot;SaudiEnergyEfficiencyCenter\\/SaudiEnergyEfficiencyCenter.png&quot;,&quot;シノアリス一周年&quot;:&quot;Sinoalice2018\\/Sinoalice2018.png&quot;,&quot;okuldisaridagunu&quot;:&quot;DirtIsGood_Persil\\/DirtIsGood_Persil.png&quot;,&quot;loespeciales&quot;:&quot;ABIMexico_ModeloCafe\\/ABIMexico_ModeloCafe.png&quot;,&quot;일라스티걸&quot;:&quot;MrsIncredible\\/MrsIncredible.png&quot;,&quot;jurassicworld&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;emaargoldenhome&quot;:&quot;EmaarGoldenHome\\/EmaarGoldenHome.png&quot;,&quot;welcometosanhok&quot;:&quot;PubGEmoji_v3\\/PubGEmoji_v3.png&quot;,&quot;thebachelorette&quot;:&quot;TheBachelorette2018\\/TheBachelorette2018.png&quot;,&quot;esigor&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;motog6play&quot;:&quot;MotorolaG62018\\/MotorolaG62018.png&quot;,&quot;comicstan&quot;:&quot;APVIndiaComicstaan\\/APVIndiaComicstaan.png&quot;,&quot;เชียร์แบบแมสๆ&quot;:&quot;KbankxWorldcup\\/KbankxWorldcup.png&quot;,&quot;человекмуравейиоса&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;お茶にしましょう&quot;:&quot;cocacolaAyataka3\\/cocacolaAyataka3.png&quot;,&quot;chopon&quot;:&quot;atlantabraves2018\\/atlantabraves2018.png&quot;,&quot;feriadehilos&quot;:&quot;FeriaDelHilo\\/FeriaDelHilo.png&quot;,&quot;misfitsandmonsters&quot;:&quot;truTV_Misfitsandmonsters\\/truTV_Misfitsandmonsters.png&quot;,&quot;ibmer&quot;:&quot;IBMThink2018_extension\\/IBMThink2018_extension.png&quot;,&quot;stateofdecay2&quot;:&quot;StateofDecay2\\/StateofDecay2.png&quot;,&quot;amazonfindsaway&quot;:&quot;JurassicWorld_FallenKingdom_AmazonFindsAWay\\/JurassicWorld_FallenKingdom_AmazonFindsAWay.png&quot;,&quot;halloweenmovies&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;qlder&quot;:&quot;StateofOriginAU_2018_QLDER\\/StateofOriginAU_2018_QLDER.png&quot;,&quot;nyxl&quot;:&quot;FranceBlizzardOWL_NY\\/FranceBlizzardOWL_NY.png&quot;,&quot;halloweenmovie2018&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;manofthematch&quot;:&quot;Budweiser_ManofTheMatch_v2\\/Budweiser_ManofTheMatch_v2.png&quot;,&quot;masterchefbr&quot;:&quot;MasterChefBR2018\\/MasterChefBR2018.png&quot;,&quot;fútbolmediaset&quot;:&quot;MEDIASET_Spain2018\\/MEDIASET_Spain2018.png&quot;,&quot;خلنا_نجتمع&quot;:&quot;Vimto2018\\/Vimto2018.png&quot;,&quot;nhs70&quot;:&quot;NationalHealthService_70thAnniversary_v2\\/NationalHealthService_70thAnniversary_v2.png&quot;,&quot;mmas2018&quot;:&quot;MYXMusicAwards2018\\/MYXMusicAwards2018.png&quot;,&quot;sharpobjects&quot;:&quot;HBOSharpObjects\\/HBOSharpObjects.png&quot;,&quot;バチェラー見てる人と語りたい&quot;:&quot;BachelorJapanS2_v2\\/BachelorJapanS2_v2.png&quot;,&quot;proudtobeabulldog&quot;:&quot;NRLbulldogs2018\\/NRLbulldogs2018.png&quot;,&quot;alomãe&quot;:&quot;BrazilWorldCup2018_AloMae_v3\\/BrazilWorldCup2018_AloMae_v3.png&quot;,&quot;megザモンスター&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;samuraiblue&quot;:&quot;WorldCup_Japan_v2\\/WorldCup_Japan_v2.png&quot;,&quot;فيمتو&quot;:&quot;Vimto2018\\/Vimto2018.png&quot;,&quot;إثراء_الرياضة&quot;:&quot;ArabLeadersSummit2018_v4\\/ArabLeadersSummit2018_v4.png&quot;,&quot;abrazosdegol&quot;:&quot;ClaroPeru2018_v2\\/ClaroPeru2018_v2.png&quot;,&quot;эластика&quot;:&quot;MrsIncredible\\/MrsIncredible.png&quot;,&quot;igor&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;gatsbyロールオン&quot;:&quot;GatsbyDeo2018\\/GatsbyDeo2018.png&quot;,&quot;hammerseries&quot;:&quot;HammerSeries2018\\/HammerSeries2018.png&quot;,&quot;gunsnroses&quot;:&quot;GunsNRoses_2018\\/GunsNRoses_2018.png&quot;,&quot;heforshe&quot;:&quot;HeForShe_fixed\\/HeForShe_fixed.png&quot;,&quot;laczynaspilka&quot;:&quot;WorldCup_Poland_v2\\/WorldCup_Poland_v2.png&quot;,&quot;proudlysydney&quot;:&quot;sydneyswans\\/sydneyswans.png&quot;,&quot;askbtsxspotify&quot;:&quot;SpotifyBTS2018_v2\\/SpotifyBTS2018_v2.png&quot;,&quot;alômae&quot;:&quot;BrazilWorldCup2018_AloMae_v3\\/BrazilWorldCup2018_AloMae_v3.png&quot;,&quot;uberindia&quot;:&quot;MoveForward_UberIndia_v2\\/MoveForward_UberIndia_v2.png&quot;,&quot;綾鷹茶葉のあまみ&quot;:&quot;cocacolaAyataka3\\/cocacolaAyataka3.png&quot;,&quot;hereweare&quot;:&quot;HereWeAre_v3\\/HereWeAre_v3.png&quot;,&quot;heladosextreme&quot;:&quot;NestleExtreme_2018\\/NestleExtreme_2018.png&quot;,&quot;uptheante&quot;:&quot;FranceBlizzardOWL_Houston\\/FranceBlizzardOWL_Houston.png&quot;,&quot;fortnitee3&quot;:&quot;ForniteBattleRoyale2018\\/ForniteBattleRoyale2018.png&quot;,&quot;البنك_السعودي_للاستثمار&quot;:&quot;SAIB\\/SAIB.png&quot;,&quot;vimto&quot;:&quot;Vimto2018\\/Vimto2018.png&quot;,&quot;เชียร์บอลโลก&quot;:&quot;KbankxWorldcup\\/KbankxWorldcup.png&quot;,&quot;poepraforasuascores&quot;:&quot;BrazilNaturaAquarela\\/BrazilNaturaAquarela.png&quot;,&quot;helloyou&quot;:&quot;MotorolaG62018\\/MotorolaG62018.png&quot;,&quot;ガチ勢の日&quot;:&quot;GatsbyDeo2018\\/GatsbyDeo2018.png&quot;,&quot;incrediblespremiere&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;jointhehuddle&quot;:&quot;AFLWestCoast\\/AFLWestCoast.png&quot;,&quot;lasuertenojuega&quot;:&quot;La_Suerte_No_Juega_v2\\/La_Suerte_No_Juega_v2.png&quot;,&quot;powerkanan&quot;:&quot;STARZPower_S5_Kanan\\/STARZPower_S5_Kanan.png&quot;,&quot;crc&quot;:&quot;WorldCup_CostaRica_v2\\/WorldCup_CostaRica_v2.png&quot;,&quot;jeanchristopheetwinnie&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;نسور_قرطاج&quot;:&quot;WorldCup_Tunisia_v2\\/WorldCup_Tunisia_v2.png&quot;,&quot;cruzcampo&quot;:&quot;Cruzcampo_2018\\/Cruzcampo_2018.png&quot;,&quot;welcometowestworld&quot;:&quot;HBOWestworld_Finale\\/HBOWestworld_Finale.png&quot;,&quot;donthesash&quot;:&quot;EssendonFC\\/EssendonFC.png&quot;,&quot;whywewearblack&quot;:&quot;TimesUp_v2\\/TimesUp_v2.png&quot;,&quot;spotifyxbts&quot;:&quot;SpotifyBTS2018_v2\\/SpotifyBTS2018_v2.png&quot;,&quot;eleccionesmexico&quot;:&quot;mexicanpresidentialelection2018\\/mexicanpresidentialelection2018.png&quot;,&quot;lgm&quot;:&quot;NYMets2018\\/NYMets2018.png&quot;,&quot;alienist&quot;:&quot;TNT-Alienist\\/TNT-Alienist.png&quot;,&quot;blackandaforever&quot;:&quot;BETAwards2018\\/BETAwards2018.png&quot;,&quot;den&quot;:&quot;WorldCup_Denmark_v3\\/WorldCup_Denmark_v3.png&quot;,&quot;helenparr&quot;:&quot;MrsIncredible\\/MrsIncredible.png&quot;,&quot;عطر_أبيات&quot;:&quot;ArabianOud2018\\/ArabianOud2018.png&quot;,&quot;beyourownchampion&quot;:&quot;BeYourOwnChampion_WorldCup\\/BeYourOwnChampion_WorldCup.png&quot;,&quot;walkonminks&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;showyouremotions&quot;:&quot;laysshowyouremotions\\/laysshowyouremotions.png&quot;,&quot;snozberries&quot;:&quot;SuperTroopers2\\/SuperTroopers2.png&quot;,&quot;threelions&quot;:&quot;ThreeLions2018\\/ThreeLions2018.png&quot;,&quot;loveislandreunion&quot;:&quot;LoveIsland2018_Flight3\\/LoveIsland2018_Flight3.png&quot;,&quot;女のバトル&quot;:&quot;BachelorJapanS2_v2\\/BachelorJapanS2_v2.png&quot;,&quot;prideinlondon&quot;:&quot;PrideInLondon_2018\\/PrideInLondon_2018.png&quot;,&quot;uru&quot;:&quot;WorldCup_Uruguay_v2\\/WorldCup_Uruguay_v2.png&quot;,&quot;هي_وحدة&quot;:&quot;Vimto2018\\/Vimto2018.png&quot;,&quot;michaelmeyers&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;simplyamazing&quot;:&quot;NissanESLeaf2018\\/NissanESLeaf2018.png&quot;,&quot;colossus&quot;:&quot;Deadpool2_Colossus\\/Deadpool2_Colossus.png&quot;,&quot;キーラ&quot;:&quot;StarWarsSolo_Qira\\/StarWarsSolo_Qira.png&quot;,&quot;beersonus&quot;:&quot;Clamato_2018\\/Clamato_2018.png&quot;,&quot;viärsverige&quot;:&quot;WorldCup_Sweden_v2\\/WorldCup_Sweden_v2.png&quot;,&quot;ناس&quot;:&quot;Flynas2018_v2\\/Flynas2018_v2.png&quot;,&quot;wakandaforever&quot;:&quot;BlackPantherHomeEnt2018\\/BlackPantherHomeEnt2018.png&quot;,&quot;thenun&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;نوروز&quot;:&quot;nowruz2018_v4\\/nowruz2018_v4.png&quot;,&quot;ファンタビ&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;bringthemayhem&quot;:&quot;FranceBlizzardOWL_Florida\\/FranceBlizzardOWL_Florida.png&quot;,&quot;aşkaşktır&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;megtubarãogigante&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;ednamoda&quot;:&quot;Ednamode_v3\\/Ednamode_v3.png&quot;,&quot;blackhistorymonth&quot;:&quot;BlackHistoryMonth\\/BlackHistoryMonth.png&quot;,&quot;クリストファーロビン&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;와스프&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;superflymusic&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;sen&quot;:&quot;WorldCup_Senegal_v2\\/WorldCup_Senegal_v2.png&quot;,&quot;electrifytheworld&quot;:&quot;NissanESLeaf2018\\/NissanESLeaf2018.png&quot;,&quot;thisisbattleroyale&quot;:&quot;PubGEmoji_v3\\/PubGEmoji_v3.png&quot;,&quot;joguejunto&quot;:&quot;BrazilWorldCup_JogueJunto_v3\\/BrazilWorldCup_JogueJunto_v3.png&quot;,&quot;adoptadinosaur&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;vivov9malltour&quot;:&quot;Kathniel\\/Kathniel.png&quot;,&quot;metoo&quot;:&quot;MeToo_v3\\/MeToo_v3.png&quot;,&quot;negasonic&quot;:&quot;Deadpool2_Negasonic\\/Deadpool2_Negasonic.png&quot;,&quot;desfiledelorgullo&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;thebachelorettefinale&quot;:&quot;TheBachelorette2018\\/TheBachelorette2018.png&quot;,&quot;wemetontwitter&quot;:&quot;WeMetOnt_Emoji\\/WeMetOnt_Emoji.png&quot;,&quot;rusiaentusmanos&quot;:&quot;Telcel_RusiaEnTusManos_2018\\/Telcel_RusiaEnTusManos_2018.png&quot;,&quot;jackjack&quot;:&quot;JackJack_2\\/JackJack_2.png&quot;,&quot;maythe4thbewithyou&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;kathnielforvivov9&quot;:&quot;Kathniel\\/Kathniel.png&quot;,&quot;niallhoranflicker&quot;:&quot;NiallHoran2018\\/NiallHoran2018.png&quot;,&quot;bestoftweet&quot;:&quot;BestofTweets2018\\/BestofTweets2018.png&quot;,&quot;championperformance&quot;:&quot;BeYourOwnChampion_WorldCup\\/BeYourOwnChampion_WorldCup.png&quot;,&quot;جيل_الذهب&quot;:&quot;PepsiGoldenBoys_2018\\/PepsiGoldenBoys_2018.png&quot;,&quot;jw2&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;puuh&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;エアアジアチャレンジ2018&quot;:&quot;AirAsia2018_v2\\/AirAsia2018_v2.png&quot;,&quot;arresteddevelopment&quot;:&quot;ArrestedDevelopment2018\\/ArrestedDevelopment2018.png&quot;,&quot;ديما_مغرب&quot;:&quot;WorldCup_Morocco_v2\\/WorldCup_Morocco_v2.png&quot;,&quot;accesomundialista&quot;:&quot;ClaroCAM\\/ClaroCAM.png&quot;,&quot;sexandthecity&quot;:&quot;HBOSexandtheCity2018\\/HBOSexandtheCity2018.png&quot;,&quot;妖怪ウォッチワールド&quot;:&quot;YokaiWatchWorld_Jibanyan\\/YokaiWatchWorld_Jibanyan.png&quot;,&quot;itspooh&quot;:&quot;ChristopherRobin_ItsPooh2018\\/ChristopherRobin_ItsPooh2018.png&quot;,&quot;feelpretty&quot;:&quot;feelpretty_v2\\/feelpretty_v2.png&quot;,&quot;westworlds2&quot;:&quot;HBOWestworld_Finale\\/HBOWestworld_Finale.png&quot;,&quot;deadpool&quot;:&quot;Deadpool2_Deadpool\\/Deadpool2_Deadpool.png&quot;,&quot;animaisfantasticos&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;pepequenofilme&quot;:&quot;WM_Smallfoot\\/WM_Smallfoot.png&quot;,&quot;hoppschwiiz&quot;:&quot;WorldCup_Switzerland_v3\\/WorldCup_Switzerland_v3.png&quot;,&quot;wearemanly&quot;:&quot;NRLmanly2018\\/NRLmanly2018.png&quot;,&quot;вместемыкоманда&quot;:&quot;WorldCup_Russia_v2\\/WorldCup_Russia_v2.png&quot;,&quot;100simplejoysofdriving&quot;:&quot;VW_SimpleJoysofDriving\\/VW_SimpleJoysofDriving.png&quot;,&quot;panamáenrusia&quot;:&quot;WorldCup_Panama_v2\\/WorldCup_Panama_v2.png&quot;,&quot;10円ピンポン&quot;:&quot;LinePay_Frenchfries\\/LinePay_Frenchfries.png&quot;,&quot;antmanandwasp&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;lavidaesunpartido&quot;:&quot;ChevroletMexico_WorldCup\\/ChevroletMexico_WorldCup.png&quot;,&quot;lotmoreforlittlemore&quot;:&quot;Vistara_2018\\/Vistara_2018.png&quot;,&quot;shareacoke&quot;:&quot;ShareACoke2018\\/ShareACoke2018.png&quot;,&quot;jp25&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;canarinho&quot;:&quot;Canarinho_WorldCup\\/Canarinho_WorldCup.png&quot;,&quot;supertroopers2&quot;:&quot;SuperTroopers2\\/SuperTroopers2.png&quot;,&quot;atfr&quot;:&quot;TheBachelorette2018\\/TheBachelorette2018.png&quot;,&quot;신비한동물사전&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;thefourcomeback&quot;:&quot;Fox_TheFour_Season2\\/Fox_TheFour_Season2.png&quot;,&quot;neversettle&quot;:&quot;Astros2018\\/Astros2018.png&quot;,&quot;solomovie&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;ibm&quot;:&quot;IBMThink2018_extension\\/IBMThink2018_extension.png&quot;,&quot;デッドプール&quot;:&quot;deadpooljapan18_v2\\/deadpooljapan18_v2.png&quot;,&quot;rusia2018&quot;:&quot;WorldCup_2018\\/WorldCup_2018.png&quot;,&quot;bhm&quot;:&quot;BlackHistoryMonth\\/BlackHistoryMonth.png&quot;,&quot;powerghost&quot;:&quot;STARZPower_S5_Ghost\\/STARZPower_S5_Ghost.png&quot;,&quot;thewaspmovie&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;eyesonyou&quot;:&quot;GOT7WORLDTOUR_2018\\/GOT7WORLDTOUR_2018.png&quot;,&quot;masterchef&quot;:&quot;spainmasterchef\\/spainmasterchef.png&quot;,&quot;くまのプーさん&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;eleccionesméxico&quot;:&quot;mexicanpresidentialelection2018\\/mexicanpresidentialelection2018.png&quot;,&quot;flècheparr&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;loscrímenesdegrindelwald&quot;:&quot;fantasticbeasts_v4\\/fantasticbeasts_v4.png&quot;,&quot;звёздныевойны&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;elequipoquenosune&quot;:&quot;WorldCup_Uruguay_v2\\/WorldCup_Uruguay_v2.png&quot;,&quot;vistaralove&quot;:&quot;Vistara_2018\\/Vistara_2018.png&quot;,&quot;newmotog&quot;:&quot;MotorolaG62018\\/MotorolaG62018.png&quot;,&quot;dinoday&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;esigór&quot;:&quot;ChristopherRobin_Eeyore2018\\/ChristopherRobin_Eeyore2018.png&quot;,&quot;betawards&quot;:&quot;BETAwards2018\\/BETAwards2018.png&quot;,&quot;بطاقة_السفر&quot;:&quot;SAIB\\/SAIB.png&quot;,&quot;exageranoexagero&quot;:&quot;BrazilNaturaAquarela\\/BrazilNaturaAquarela.png&quot;,&quot;orgull&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;nrl&quot;:&quot;NRL2018\\/NRL2018.png&quot;,&quot;jepa&quot;:&quot;DirtIsGood_Persil\\/DirtIsGood_Persil.png&quot;,&quot;랜도&quot;:&quot;StarWarsSolo_Lando\\/StarWarsSolo_Lando.png&quot;,&quot;pringlesacademy&quot;:&quot;PringlesFrance_2018\\/PringlesFrance_2018.png&quot;,&quot;camillepreaker&quot;:&quot;HBOSharpObjects\\/HBOSharpObjects.png&quot;,&quot;marvelstudiosantmanandthewasp&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;เชียร์ให้สุดหยุดที่บอลโลก&quot;:&quot;KbankxWorldcup\\/KbankxWorldcup.png&quot;,&quot;mammamia2&quot;:&quot;MammaMia2_v3\\/MammaMia2_v3.png&quot;,&quot;micorazóntricolor&quot;:&quot;WorldCup_Colombia_v2\\/WorldCup_Colombia_v2.png&quot;,&quot;womeninfootball&quot;:&quot;WomenInFootball2018_v2\\/WomenInFootball2018_v2.png&quot;,&quot;bel&quot;:&quot;WorldCup_Belgium_v2\\/WorldCup_Belgium_v2.png&quot;,&quot;marchedesfiertés&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;herecomethegiants&quot;:&quot;SuperNetball_HereComeTheGiants\\/SuperNetball_HereComeTheGiants.png&quot;,&quot;fiersdetrebleus&quot;:&quot;WorldCup_France_v2\\/WorldCup_France_v2.png&quot;,&quot;jurassicworld2&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;blacklivesmatter&quot;:&quot;BlackHistoryMonth\\/BlackHistoryMonth.png&quot;,&quot;ad5&quot;:&quot;ArrestedDevelopment2018\\/ArrestedDevelopment2018.png&quot;,&quot;piepequeño&quot;:&quot;WM_Smallfoot\\/WM_Smallfoot.png&quot;,&quot;paylikezlatan&quot;:&quot;Visa_WorldCup2018_v2\\/Visa_WorldCup2018_v2.png&quot;,&quot;pooh&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;fightingforglory&quot;:&quot;FranceBlizzardOWL_Shanghai\\/FranceBlizzardOWL_Shanghai.png&quot;,&quot;jurassicworldnight&quot;:&quot;JurassicWorld_FallenKingdom_DinoDay_v2\\/JurassicWorld_FallenKingdom_DinoDay_v2.png&quot;,&quot;westworldseason2&quot;:&quot;HBOWestworld_Finale\\/HBOWestworld_Finale.png&quot;,&quot;feriadelhilo&quot;:&quot;FeriaDelHilo\\/FeriaDelHilo.png&quot;,&quot;dillydilly&quot;:&quot;BudLightWorldCup_DillyDilly_Flight2\\/BudLightWorldCup_DillyDilly_Flight2.png&quot;,&quot;pol&quot;:&quot;WorldCup_Poland_v2\\/WorldCup_Poland_v2.png&quot;,&quot;العربية_للعود&quot;:&quot;ArabianOud2018\\/ArabianOud2018.png&quot;,&quot;allcaps&quot;:&quot;NHL_2017_2018_Caps_v3\\/NHL_2017_2018_Caps_v3.png&quot;,&quot;gosocceroos&quot;:&quot;WorldCup_Australia_v2\\/WorldCup_Australia_v2.png&quot;,&quot;eaststowin&quot;:&quot;NRLRoosters2018\\/NRLRoosters2018.png&quot;,&quot;tudopelaseleção&quot;:&quot;GuaranaCopa_2018\\/GuaranaCopa_2018.png&quot;,&quot;michaelmyers&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;budiponosan&quot;:&quot;WorldCup_Croatia_v2\\/WorldCup_Croatia_v2.png&quot;,&quot;haypower&quot;:&quot;PoweradeMXWorldCup\\/PoweradeMXWorldCup.png&quot;,&quot;シノアリス&quot;:&quot;Sinoalice2018\\/Sinoalice2018.png&quot;,&quot;thepharaohs&quot;:&quot;WorldCup_Egypt_v2\\/WorldCup_Egypt_v2.png&quot;,&quot;oamorvence&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;じんめん犬&quot;:&quot;YokaiWatchWorld_Jinmenken\\/YokaiWatchWorld_Jinmenken.png&quot;,&quot;tigrão&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;,&quot;fútbolendirecto&quot;:&quot;MEDIASET_Spain2018\\/MEDIASET_Spain2018.png&quot;,&quot;pantini&quot;:&quot;PanteneInfluencer_2018\\/PanteneInfluencer_2018.png&quot;,&quot;pride&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;bronxnation&quot;:&quot;NRLBroncos2018\\/NRLBroncos2018.png&quot;,&quot;votaméxico&quot;:&quot;mexicanpresidentialelection2018\\/mexicanpresidentialelection2018.png&quot;,&quot;exploralodesconocido&quot;:&quot;NestleExtreme_2018\\/NestleExtreme_2018.png&quot;,&quot;zabivaka&quot;:&quot;WorldCup_Zabivaka\\/WorldCup_Zabivaka.png&quot;,&quot;inclusionishappening&quot;:&quot;TwitterTogether_InclusionIsHappening_v2\\/TwitterTogether_InclusionIsHappening_v2.png&quot;,&quot;srb&quot;:&quot;WorldCup_Serbia_v2\\/WorldCup_Serbia_v2.png&quot;,&quot;supersuit&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;animalesfantásticos&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;hilanderos&quot;:&quot;FeriaDelHilo\\/FeriaDelHilo.png&quot;,&quot;suerteono&quot;:&quot;La_Suerte_No_Juega_v2\\/La_Suerte_No_Juega_v2.png&quot;,&quot;ithra&quot;:&quot;ArabLeadersSummit2018_v4\\/ArabLeadersSummit2018_v4.png&quot;,&quot;yétietcompagnie&quot;:&quot;WM_Smallfoot\\/WM_Smallfoot.png&quot;,&quot;satc&quot;:&quot;HBOSexandtheCity2018\\/HBOSexandtheCity2018.png&quot;,&quot;comeonengland&quot;:&quot;WorldCup_England_v2\\/WorldCup_England_v2.png&quot;,&quot;تبرعك_أسهل&quot;:&quot;ZamzamSociety2018\\/ZamzamSociety2018.png&quot;,&quot;اقتصاد_الوقود&quot;:&quot;SaudiEnergyEfficiencyCenter\\/SaudiEnergyEfficiencyCenter.png&quot;,&quot;mundialenmediaset&quot;:&quot;MEDIASET_Spain2018\\/MEDIASET_Spain2018.png&quot;,&quot;хрюня&quot;:&quot;ChristopherRobin_Piglet2018\\/ChristopherRobin_Piglet2018.png&quot;,&quot;lamonja&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;got7worldtour&quot;:&quot;GOT7WORLDTOUR_2018\\/GOT7WORLDTOUR_2018.png&quot;,&quot;كامل_الأوصاف&quot;:&quot;NewChanganCar2018\\/NewChanganCar2018.png&quot;,&quot;letsgopadres&quot;:&quot;SDPadres2018\\/SDPadres2018.png&quot;,&quot;バチェラー&quot;:&quot;BachelorJapanS2_v2\\/BachelorJapanS2_v2.png&quot;,&quot;pan&quot;:&quot;WorldCup_Panama_v2\\/WorldCup_Panama_v2.png&quot;,&quot;antmanetlaguêpe&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;incredibles2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;heretocreate&quot;:&quot;Adidas_HereToCreate_WorldCup2018\\/Adidas_HereToCreate_WorldCup2018.png&quot;,&quot;detroitsummers&quot;:&quot;DetroitTigers2018\\/DetroitTigers2018.png&quot;,&quot;mrincredibile&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;frozono&quot;:&quot;Frozone\\/Frozone.png&quot;,&quot;jarir_deliver&quot;:&quot;Jarir2018\\/Jarir2018.png&quot;,&quot;스타워즈&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;thenunmovie&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;amazonfiretvcube&quot;:&quot;FireTVLaunch2018\\/FireTVLaunch2018.png&quot;,&quot;fastestfeet&quot;:&quot;reebokflexweave_v2\\/reebokflexweave_v2.png&quot;,&quot;handsfreetv&quot;:&quot;FireTVLaunch2018\\/FireTVLaunch2018.png&quot;,&quot;malibugames&quot;:&quot;MalibuGamesSummer2018\\/MalibuGamesSummer2018.png&quot;,&quot;soarsupereagles&quot;:&quot;WorldCup_Nigeria_v2\\/WorldCup_Nigeria_v2.png&quot;,&quot;esp&quot;:&quot;WorldCup_Spain_v2\\/WorldCup_Spain_v2.png&quot;,&quot;ダブルウェアの出番&quot;:&quot;EsteeLauder_DoubleWear\\/EsteeLauder_DoubleWear.png&quot;,&quot;ittakesobsession&quot;:&quot;TranssionTecno2018\\/TranssionTecno2018.png&quot;,&quot;makethefuture&quot;:&quot;Shell_MaketheFuture_2018\\/Shell_MaketheFuture_2018.png&quot;,&quot;cro&quot;:&quot;WorldCup_Croatia_v2\\/WorldCup_Croatia_v2.png&quot;,&quot;cmtaward&quot;:&quot;CMTAwards2018_v2\\/CMTAwards2018_v2.png&quot;,&quot;green_falcons&quot;:&quot;WorldCup_SaudiArabia_v2\\/WorldCup_SaudiArabia_v2.png&quot;,&quot;sheinspiresme&quot;:&quot;HereWeAre_v3\\/HereWeAre_v3.png&quot;,&quot;винни&quot;:&quot;ChristopherRobin_Pooh2018\\/ChristopherRobin_Pooh2018.png&quot;,&quot;discoverwestworld&quot;:&quot;HBOWestworld_Finale\\/HBOWestworld_Finale.png&quot;,&quot;madetofly&quot;:&quot;SuperNetball_MadetoFly\\/SuperNetball_MadetoFly.png&quot;,&quot;uberjourneys&quot;:&quot;MoveForward_UberIndia_v2\\/MoveForward_UberIndia_v2.png&quot;,&quot;askbeebo&quot;:&quot;PanicAtTheDisco_2018\\/PanicAtTheDisco_2018.png&quot;,&quot;gonswswifts&quot;:&quot;SuperNetball_GoNSWSwifts\\/SuperNetball_GoNSWSwifts.png&quot;,&quot;howwillyousurvive&quot;:&quot;StateofDecay2_HowWillYouSurvive\\/StateofDecay2_HowWillYouSurvive.png&quot;,&quot;flywithadditve&quot;:&quot;GEAdaptive_2018_v3\\/GEAdaptive_2018_v3.png&quot;,&quot;powertommy&quot;:&quot;STARZPower_S5_Tommy\\/STARZPower_S5_Tommy.png&quot;,&quot;mrsincredible&quot;:&quot;MrsIncredible\\/MrsIncredible.png&quot;,&quot;torcedorfanático&quot;:&quot;RexonaWorldCupEmoji\\/RexonaWorldCupEmoji.png&quot;,&quot;boundbyblue&quot;:&quot;AFLBoundbyBlue\\/AFLBoundbyBlue.png&quot;,&quot;matriline&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;panicatthedisco&quot;:&quot;PanicAtTheDisco_2018\\/PanicAtTheDisco_2018.png&quot;,&quot;superhotdogger&quot;:&quot;SuperHotdogger_2018\\/SuperHotdogger_2018.png&quot;,&quot;lifefindsaway&quot;:&quot;Jurassic_World_emoji_v3\\/Jurassic_World_emoji_v3.png&quot;,&quot;قيمنا_معا&quot;:&quot;MiskValues2018\\/MiskValues2018.png&quot;,&quot;diemannschaft&quot;:&quot;WorldCup_Germany_v2\\/WorldCup_Germany_v2.png&quot;,&quot;nissanleaf&quot;:&quot;NissanESLeaf2018\\/NissanESLeaf2018.png&quot;,&quot;キリンレモン&quot;:&quot;KirinLemon90thAnniversary_2018\\/KirinLemon90thAnniversary_2018.png&quot;,&quot;갓세븐&quot;:&quot;GOT7WORLDTOUR_2018\\/GOT7WORLDTOUR_2018.png&quot;,&quot;raisedroyal&quot;:&quot;kcroyals2018\\/kcroyals2018.png&quot;,&quot;megderinlerdekidehset&quot;:&quot;TheMeg_2018\\/TheMeg_2018.png&quot;,&quot;raysup&quot;:&quot;TampaBayRays2018\\/TampaBayRays2018.png&quot;,&quot;weareraiders&quot;:&quot;NRLraiders2018\\/NRLraiders2018.png&quot;,&quot;maythe4th&quot;:&quot;StarWarsSolo_Chewie_v2\\/StarWarsSolo_Chewie_v2.png&quot;,&quot;arg&quot;:&quot;WorldCup_Argentina_v2\\/WorldCup_Argentina_v2.png&quot;,&quot;uptheblues&quot;:&quot;StateofOriginAU_2018_uptheblues\\/StateofOriginAU_2018_uptheblues.png&quot;,&quot;truetotheblue&quot;:&quot;SeattleMariners2018\\/SeattleMariners2018.png&quot;,&quot;ednamode&quot;:&quot;Ednamode_v3\\/Ednamode_v3.png&quot;,&quot;オレンジ文庫&quot;:&quot;ShueishaBrand_2018_v4\\/ShueishaBrand_2018_v4.png&quot;,&quot;amorésamor&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;gnfnr&quot;:&quot;GunsNRoses_2018\\/GunsNRoses_2018.png&quot;,&quot;superfly&quot;:&quot;SuperflyMovie2018\\/SuperflyMovie2018.png&quot;,&quot;honor10&quot;:&quot;HuaweiHonorQ2GlobalLaunch_v2\\/HuaweiHonorQ2GlobalLaunch_v2.png&quot;,&quot;lando&quot;:&quot;StarWarsSolo_Lando\\/StarWarsSolo_Lando.png&quot;,&quot;хансоло&quot;:&quot;StarWarsSolo_HanSolo\\/StarWarsSolo_HanSolo.png&quot;,&quot;bestneverrest&quot;:&quot;MercedesGermany_BestNeverRest\\/MercedesGermany_BestNeverRest.png&quot;,&quot;laguêpe&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;aceshigh&quot;:&quot;FranceBlizzardOWL_London\\/FranceBlizzardOWL_London.png&quot;,&quot;لنحياها&quot;:&quot;MiskValues2018\\/MiskValues2018.png&quot;,&quot;brose&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;persiannewyear&quot;:&quot;nowruz2018_v4\\/nowruz2018_v4.png&quot;,&quot;stlcards&quot;:&quot;StLouisCardinals2018\\/StLouisCardinals2018.png&quot;,&quot;itscominghome&quot;:&quot;WilliamHillWorldCup2018\\/WilliamHillWorldCup2018.png&quot;,&quot;satanicgrandmas&quot;:&quot;A24_Hereditary2018\\/A24_Hereditary2018.png&quot;,&quot;brosé&quot;:&quot;NationalRoseDay2018\\/NationalRoseDay2018.png&quot;,&quot;фантастическиетвари&quot;:&quot;fantasticbeasts_v3\\/fantasticbeasts_v3.png&quot;,&quot;flythenewfeeling&quot;:&quot;Vistara_2018\\/Vistara_2018.png&quot;,&quot;clamatomichelada&quot;:&quot;Clamato_2018\\/Clamato_2018.png&quot;,&quot;lauriestrode&quot;:&quot;HalloweenMovie_2018\\/HalloweenMovie_2018.png&quot;,&quot;por&quot;:&quot;WorldCup_Portugal_v2\\/WorldCup_Portugal_v2.png&quot;,&quot;كن_سباقا_لعلاج_المرضى_الفقراء&quot;:&quot;ZamzamSociety2018\\/ZamzamSociety2018.png&quot;,&quot;elamorgana&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;whitesox&quot;:&quot;whitesox2018\\/whitesox2018.png&quot;,&quot;webringthunder&quot;:&quot;SuperNetball_webringthunder\\/SuperNetball_webringthunder.png&quot;,&quot;myvimto&quot;:&quot;Vimto2018\\/Vimto2018.png&quot;,&quot;bra&quot;:&quot;WorldCup_Brazil_v2\\/WorldCup_Brazil_v2.png&quot;,&quot;yourodds&quot;:&quot;WilliamHillWorldCup2018\\/WilliamHillWorldCup2018.png&quot;,&quot;antmanylaavispa&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;birdland&quot;:&quot;orioles2018_v2\\/orioles2018_v2.png&quot;,&quot;アナザーエデン&quot;:&quot;catemoji_v2\\/catemoji_v2.png&quot;,&quot;pinstripepride&quot;:&quot;NYYankees2018\\/NYYankees2018.png&quot;,&quot;hagamosqueocurra&quot;:&quot;WorldCup_Spain_v2\\/WorldCup_Spain_v2.png&quot;,&quot;hilanderas&quot;:&quot;FeriaDelHilo\\/FeriaDelHilo.png&quot;,&quot;swe&quot;:&quot;WorldCup_Sweden_v2\\/WorldCup_Sweden_v2.png&quot;,&quot;prayforthewickedtour&quot;:&quot;PanicAtTheDisco_2018\\/PanicAtTheDisco_2018.png&quot;,&quot;طيران_ناس&quot;:&quot;Flynas2018_v2\\/Flynas2018_v2.png&quot;,&quot;todoestaporver&quot;:&quot;vodafone2018\\/vodafone2018.png&quot;,&quot;studentsstandup&quot;:&quot;Parkland_Extension\\/Parkland_Extension.png&quot;,&quot;megalodónpelícula&quot;:&quot;TheMeg_2018_MegalodonPelicula\\/TheMeg_2018_MegalodonPelicula.png&quot;,&quot;espejopúblico&quot;:&quot;EspejoPublico_2017_2018\\/EspejoPublico_2017_2018.png&quot;,&quot;كفاءة_الطاقة&quot;:&quot;SaudiEnergyEfficiencyCenter\\/SaudiEnergyEfficiencyCenter.png&quot;,&quot;thehaloway&quot;:&quot;LAAngels2018\\/LAAngels2018.png&quot;,&quot;masunidosquenunca&quot;:&quot;CristalPeruMundial\\/CristalPeruMundial.png&quot;,&quot;あなたの思いをそのまま聞かせて&quot;:&quot;Adsforgood_Japan2018_v2\\/Adsforgood_Japan2018_v2.png&quot;,&quot;fra&quot;:&quot;WorldCup_France_v2\\/WorldCup_France_v2.png&quot;,&quot;marvelantmanandthewasp&quot;:&quot;Disney_TheWasp_2018\\/Disney_TheWasp_2018.png&quot;,&quot;dieunglaublichen2&quot;:&quot;incredibles2_v5\\/incredibles2_v5.png&quot;,&quot;allforteammelli&quot;:&quot;WorldCup_Iran_v2\\/WorldCup_Iran_v2.png&quot;,&quot;ความรักชนะ&quot;:&quot;TwitterOpen_Pride2018\\/TwitterOpen_Pride2018.png&quot;,&quot;мистерисключительный&quot;:&quot;MrIncredible\\/MrIncredible.png&quot;,&quot;afreirafilme&quot;:&quot;TheNunMovie_2018\\/TheNunMovie_2018.png&quot;,&quot;itstigger&quot;:&quot;ChristopherRobin_Tigger2018\\/ChristopherRobin_Tigger2018.png&quot;},&quot;initialState&quot;:{&quot;title&quot;:&quot;Twitter. Det \\u00e4r det som h\\u00e4nder.&quot;,&quot;section&quot;:null,&quot;module&quot;:&quot;app\\/pages\\/static_lohp&quot;,&quot;cache_ttl&quot;:300,&quot;body_class_names&quot;:&quot;three-col logged-out western sv static-logged-out-home-page&quot;,&quot;doc_class_names&quot;:null,&quot;route_name&quot;:&quot;&quot;,&quot;page_container_class_names&quot;:&quot;AppContent wrapper wrapper-front&quot;,&quot;ttft_navigation&quot;:false}}\">\n\n  \n\n    <input type=\"hidden\" class=\"swift-boot-module\" value=\"app/pages/static_lohp\">\n  <input type=\"hidden\" id=\"swift-module-path\" value=\"https://abs.twimg.com/k/swift/sv\">\n\n  \n    <script src=\"https://abs.twimg.com/k/sv/init.sv.02a09a2e9b2265e88255.js\" async=\"\"></script>\n\n  \n\n<div id=\"sr-event-log\" class=\"visuallyhidden\" aria-live=\"assertive\"></div></body></html>",
    "MetaTags": [
      {
        "charset": "utf-8"
      },
      {
        "name": "robots",
        "content": "NOODP"
      },
      {
        "name": "description",
        "content": "Allt från de senaste nyheterna och underhållningen till sport och politik: du får veta allt med livekommentarer."
      },
      {
        "name": "msapplication-TileImage",
        "content": "//abs.twimg.com/favicons/win8-tile-144.png"
      },
      {
        "name": "msapplication-TileColor",
        "content": "#00aced"
      },
      {
        "name": "swift-page-name",
        "id": "swift-page-name",
        "content": "front"
      },
      {
        "name": "swift-page-section",
        "id": "swift-section-name",
        "content": "front"
      }
    ],
    "ClassNames": {
      "html": [],
      "body": [
        "three-col",
        "logged-out",
        "western",
        "sv",
        "static-logged-out-home-page"
      ],
      "all": [
        [
          "coreCSSBundles"
        ],
        [
          "moreCSSBundles"
        ],
        [
          "moreCSSBundles"
        ],
        [
          "three-col",
          "logged-out",
          "western",
          "sv",
          "static-logged-out-home-page"
        ],
        [
          "NoScriptForm"
        ],
        [
          "NoScriptForm-content"
        ],
        [
          "NoScriptForm-logo",
          "Icon",
          "Icon--logo",
          "Icon--extraLarge"
        ],
        [
          "NoScriptForm-buttonContainer"
        ],
        [
          "EdgeButton",
          "EdgeButton--primary"
        ],
        [
          "u-hiddenVisually",
          "focusable"
        ],
        [
          "StaticLoggedOutHomePage"
        ],
        [
          "StaticLoggedOutHomePage-content"
        ],
        [
          "StaticLoggedOutHomePage-cell",
          "StaticLoggedOutHomePage-utilityBlock"
        ],
        [
          "StaticLoggedOutHomePage-login"
        ],
        [
          "LoginForm",
          "js-front-signin"
        ],
        [
          "LoginForm-input",
          "LoginForm-username"
        ],
        [
          "text-input",
          "email-input",
          "js-signin-email"
        ],
        [
          "LoginForm-input",
          "LoginForm-password"
        ],
        [
          "text-input"
        ],
        [
          "LoginForm-staticForgot"
        ],
        [
          "forgot"
        ],
        [
          "EdgeButton",
          "EdgeButton--secondary",
          "EdgeButton--medium",
          "submit",
          "js-submit"
        ],
        [
          "StaticLoggedOutHomePage-signupBlock"
        ],
        [
          "StaticLoggedOutHomePage-signupHeader"
        ],
        [
          "Icon",
          "Icon--bird"
        ],
        [
          "StaticLoggedOutHomePage-input",
          "StaticLoggedOutHomePage-narrowLoginButton",
          "EdgeButton",
          "EdgeButton--secondary",
          "EdgeButton--small",
          "u-floatRight"
        ],
        [
          "StaticLoggedOutHomePage-signupTitle"
        ],
        [
          "StaticLoggedOutHomePage-noSignupForm"
        ],
        [
          "StaticLoggedOutHomePage-signupSubtitle"
        ],
        [
          "StaticLoggedOutHomePage-buttons"
        ],
        [
          "js-nav",
          "EdgeButton",
          "EdgeButton--medium",
          "EdgeButton--primary",
          "StaticLoggedOutHomePage-buttonSignup"
        ],
        [
          "js-nav",
          "EdgeButton",
          "EdgeButton--medium",
          "EdgeButton--secondary",
          "StaticLoggedOutHomePage-buttonLogin"
        ],
        [
          "StaticLoggedOutHomePage-cell",
          "StaticLoggedOutHomePage-communicationBlock"
        ],
        [
          "twitterIcon-bird"
        ],
        [
          "StaticLoggedOutHomePage-communicationContent"
        ],
        [
          "StaticLoggedOutHomePage-communicationItem"
        ],
        [
          "Icon",
          "Icon--search"
        ],
        [
          "StaticLoggedOutHomePage-communicationItem"
        ],
        [
          "Icon",
          "Icon--people"
        ],
        [
          "StaticLoggedOutHomePage-communicationItem"
        ],
        [
          "Icon",
          "Icon--reply"
        ],
        [
          "js-banners"
        ],
        [
          "Banner",
          "Banner--aboveNav",
          "eu-cookie-notice"
        ],
        [
          "Banner-contentContainer"
        ],
        [
          "Banner-textContent"
        ],
        [
          "Banner-actions"
        ],
        [
          "Icon",
          "Icon--close"
        ],
        [
          "visuallyhidden"
        ],
        [
          "front-warning"
        ],
        [
          "front-warning"
        ],
        [
          "StreamsFooter",
          "StreamsFooter--fixed"
        ],
        [
          "StreamsFooter-list",
          "u-cf"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item"
        ],
        [
          "StreamsFooter-item",
          "StreamsFooter-copyright"
        ],
        [
          "alert-messages",
          "hidden"
        ],
        [
          "message",
          ""
        ],
        [
          "message-inside"
        ],
        [
          "message-text"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium",
          "dismiss"
        ],
        [
          "visuallyhidden"
        ],
        [
          "gallery-overlay"
        ],
        [
          "Gallery",
          "with-tweet"
        ],
        [
          "Gallery-styles"
        ],
        [
          "Gallery-closeTarget"
        ],
        [
          "Gallery-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "modal-close-fixed",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--large"
        ],
        [
          "visuallyhidden"
        ],
        [
          "Gallery-media"
        ],
        [
          "GalleryNav",
          "GalleryNav--prev"
        ],
        [
          "GalleryNav-handle",
          "GalleryNav-handle--prev"
        ],
        [
          "Icon",
          "Icon--caretLeft",
          "Icon--large"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "GalleryNav",
          "GalleryNav--next"
        ],
        [
          "GalleryNav-handle",
          "GalleryNav-handle--next"
        ],
        [
          "Icon",
          "Icon--caretRight",
          "Icon--large"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "GalleryTweet"
        ],
        [
          "modal-overlay"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "modal-small",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "modal-inner"
        ],
        [
          "t1-form",
          "goto-user-form"
        ],
        [
          "input-block",
          "username-input"
        ],
        [
          "dropdown-menu",
          "typeahead"
        ],
        [
          "dropdown-caret"
        ],
        [
          "caret-outer"
        ],
        [
          "caret-inner"
        ],
        [
          "dropdown-inner",
          "js-typeahead-results"
        ],
        [
          "typeahead-saved-searches"
        ],
        [
          "typeahead-category-title",
          "saved-searches-title"
        ],
        [
          "typeahead-items",
          "saved-searches-list"
        ],
        [
          "typeahead-item",
          "typeahead-saved-search-item"
        ],
        [
          "Icon",
          "Icon--close"
        ],
        [
          "visuallyhidden"
        ],
        [
          "js-nav"
        ],
        [
          "typeahead-items",
          "typeahead-topics"
        ],
        [
          "typeahead-item",
          "typeahead-topic-item"
        ],
        [
          "js-nav"
        ],
        [
          "typeahead-items",
          "typeahead-accounts",
          "social-context",
          "js-typeahead-accounts"
        ],
        [
          "typeahead-item",
          "typeahead-account-item",
          "js-selectable"
        ],
        [
          "js-nav"
        ],
        [
          "js-selectable",
          "typeahead-in-conversation",
          "hidden"
        ],
        [
          "Icon",
          "Icon--follower",
          "Icon--small"
        ],
        [
          "typeahead-in-conversation-text"
        ],
        [
          "avatar",
          "size32"
        ],
        [
          "typeahead-user-item-info",
          "account-group"
        ],
        [
          "fullname"
        ],
        [
          "UserBadges"
        ],
        [
          "Icon",
          "Icon--verified",
          "js-verified",
          "hidden"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "Icon",
          "Icon--protected",
          "js-protected",
          "hidden"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "UserNameBreak"
        ],
        [
          "username",
          "u-dir"
        ],
        [
          "typeahead-social-context"
        ],
        [
          "js-selectable",
          "typeahead-accounts-shortcut",
          "js-shortcut"
        ],
        [
          "js-nav"
        ],
        [
          "typeahead-items",
          "typeahead-trend-locations-list"
        ],
        [
          "typeahead-item",
          "typeahead-trend-locations-item"
        ],
        [
          "js-nav"
        ],
        [
          "typeahead-user-select"
        ],
        [
          "typeahead-empty-suggestions"
        ],
        [
          "typeahead-items",
          "typeahead-selected",
          "js-typeahead-selected"
        ],
        [
          "typeahead-item",
          "typeahead-selected-item",
          "js-selectable"
        ],
        [
          "js-nav"
        ],
        [
          "avatar",
          "size32"
        ],
        [
          "typeahead-user-item-info",
          "account-group"
        ],
        [
          "select-status",
          "deselect-user",
          "js-deselect-user",
          "Icon",
          "Icon--check"
        ],
        [
          "select-status",
          "select-disabled",
          "Icon",
          "Icon--unfollow"
        ],
        [
          "fullname"
        ],
        [
          "UserBadges"
        ],
        [
          "Icon",
          "Icon--verified",
          "js-verified",
          "hidden"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "Icon",
          "Icon--protected",
          "js-protected",
          "hidden"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "UserNameBreak"
        ],
        [
          "username",
          "u-dir"
        ],
        [
          "typeahead-selected-end"
        ],
        [
          "typeahead-items",
          "typeahead-accounts",
          "js-typeahead-accounts"
        ],
        [
          "typeahead-item",
          "typeahead-account-item",
          "js-selectable"
        ],
        [
          "js-nav"
        ],
        [
          "avatar",
          "size32"
        ],
        [
          "typeahead-user-item-info",
          "account-group"
        ],
        [
          "select-status",
          "deselect-user",
          "js-deselect-user",
          "Icon",
          "Icon--check"
        ],
        [
          "select-status",
          "select-disabled",
          "Icon",
          "Icon--unfollow"
        ],
        [
          "fullname"
        ],
        [
          "UserBadges"
        ],
        [
          "Icon",
          "Icon--verified",
          "js-verified",
          "hidden"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "Icon",
          "Icon--protected",
          "js-protected",
          "hidden"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "UserNameBreak"
        ],
        [
          "username",
          "u-dir"
        ],
        [
          "typeahead-accounts-end"
        ],
        [
          "typeahead-dm-conversations"
        ],
        [
          "typeahead-items",
          "typeahead-dm-conversation-items"
        ],
        [
          "typeahead-item",
          "typeahead-dm-conversation-item"
        ],
        [
          "QuickPromoteDialog",
          "modal-container"
        ],
        [
          "modal",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "modal-close-fixed",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--large"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "quick-promote-view-container"
        ],
        [
          "media"
        ],
        [
          "quick-promote-iframe",
          "js-initial-focus"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "tweet-loading"
        ],
        [
          "spinner-bigger"
        ],
        [
          "modal-body",
          "modal-tweet"
        ],
        [
          "modal-footer"
        ],
        [
          "EdgeButton",
          "EdgeButton--tertiary",
          "cancel-action",
          "js-close"
        ],
        [
          "EdgeButton",
          "EdgeButton--danger",
          "block-action"
        ],
        [
          "dropdown-caret"
        ],
        [
          "caret-outer"
        ],
        [
          "caret-inner"
        ],
        [
          "geo-not-enabled-yet"
        ],
        [
          "geo-turn-on",
          "EdgeButton",
          "EdgeButton--primary"
        ],
        [
          "geo-not-now",
          "EdgeButton",
          "EdgeButton--secondary"
        ],
        [
          "dropdown-caret"
        ],
        [
          "caret-outer"
        ],
        [
          "caret-inner"
        ],
        [
          "geo-query-location"
        ],
        [
          "GeoSearch-queryInput"
        ],
        [
          "Icon",
          "Icon--search"
        ],
        [
          "geo-dropdown-status"
        ],
        [
          "GeoSearch-dropdownMenu"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "modal-small",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "list-membership-content"
        ],
        [
          "spinner",
          "lists-spinner"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "modal-medium",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "list-editor"
        ],
        [
          "field"
        ],
        [
          "t1-label"
        ],
        [
          "text"
        ],
        [
          "field"
        ],
        [
          "t1-label"
        ],
        [
          "help-text"
        ],
        [
          "field"
        ],
        [
          "t1-legend"
        ],
        [
          "options"
        ],
        [
          "t1-label"
        ],
        [
          "radio"
        ],
        [
          "t1-label"
        ],
        [
          "radio"
        ],
        [
          "list-editor-save"
        ],
        [
          "EdgeButton",
          "EdgeButton--secondary",
          "update-list-button"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "draggable"
        ],
        [
          "modal-content",
          "clearfix"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "tweet-loading"
        ],
        [
          "spinner-bigger"
        ],
        [
          "activity-popup-dialog-content",
          "modal-tweet",
          "clearfix"
        ],
        [
          "loading"
        ],
        [
          "spinner-bigger"
        ],
        [
          "activity-popup-dialog-users",
          "clearfix"
        ],
        [
          "activity-popup-dialog-footer"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "modal-medium",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "copy-link-to-tweet-container"
        ],
        [
          "t1-label"
        ],
        [
          "copy-link-to-tweet-instructions"
        ],
        [
          "link-to-tweet-destination",
          "js-initial-focus",
          "u-dir"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "modal-medium",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title",
          "embed-tweet-title"
        ],
        [
          "modal-title",
          "embed-video-title"
        ],
        [
          "modal-body"
        ],
        [
          "embed-code-container"
        ],
        [
          "embed-tweet-instructions"
        ],
        [
          "embed-video-instructions"
        ],
        [
          "t1-form"
        ],
        [
          "embed-destination-wrapper"
        ],
        [
          "embed-overlay",
          "embed-overlay-spinner"
        ],
        [
          "embed-overlay-content"
        ],
        [
          "embed-overlay",
          "embed-overlay-error"
        ],
        [
          "embed-overlay-content"
        ],
        [
          "btn-link",
          "retry-embed"
        ],
        [
          "embed-destination",
          "js-initial-focus"
        ],
        [
          "embed-options"
        ],
        [
          "embed-include-parent-tweet"
        ],
        [
          "t1-label"
        ],
        [
          "include-parent-tweet"
        ],
        [
          "embed-include-card"
        ],
        [
          "t1-label"
        ],
        [
          "include-card"
        ],
        [
          "embed-tweet-description"
        ],
        [
          "embed-preview-header"
        ],
        [
          "embed-preview"
        ],
        [
          "modal-container",
          "why-this-ad-dialog"
        ],
        [
          "modal",
          "modal-large",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title",
          "why-this-ad-title"
        ],
        [
          "why-this-ad-content"
        ],
        [
          "why-this-ad-spinner"
        ],
        [
          "spinner-bigger"
        ],
        [
          "hidden"
        ],
        [
          "LoginDialog",
          "modal-container",
          "u-textCenter"
        ],
        [
          "modal",
          "modal-large",
          "draggable"
        ],
        [
          "LoginDialog-content",
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "LoginDialog-body",
          "modal-body"
        ],
        [
          "LoginDialog-bird"
        ],
        [
          "Icon",
          "Icon--bird",
          "Icon--large"
        ],
        [
          "LoginDialog-form"
        ],
        [
          "LoginForm",
          "js-front-signin"
        ],
        [
          "LoginForm-input",
          "LoginForm-username"
        ],
        [
          "text-input",
          "email-input",
          "js-signin-email"
        ],
        [
          "LoginForm-input",
          "LoginForm-password"
        ],
        [
          "text-input"
        ],
        [
          "LoginForm-rememberForgot"
        ],
        [
          "separator"
        ],
        [
          "forgot"
        ],
        [
          "EdgeButton",
          "EdgeButton--primary",
          "EdgeButton--medium",
          "submit",
          "js-submit"
        ],
        [
          "LoginDialog-footer",
          "modal-footer",
          "u-textCenter"
        ],
        [
          "LoginDialog-signupLink"
        ],
        [
          "SignupDialog",
          "modal-container",
          "u-textCenter"
        ],
        [
          "modal",
          "modal-large",
          "draggable"
        ],
        [
          "SignupDialog-content",
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "SignupDialog-body",
          "modal-body"
        ],
        [
          "SignupDialog-icon"
        ],
        [
          "Icon",
          "Icon--bird",
          "Icon--extraLarge"
        ],
        [
          "SignupDialog-heading"
        ],
        [
          "SignupDialog-form"
        ],
        [
          "signup",
          "SignupForm\n",
          "",
          ""
        ],
        [
          "EdgeButton",
          "EdgeButton--large",
          "EdgeButton--primary",
          "SignupForm-submit",
          "u-block",
          "js-signup",
          ""
        ],
        [
          "SignupDialog-footer",
          "modal-footer",
          "u-textCenter"
        ],
        [
          "SignupDialog-signinLink"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "modal-medium",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "js-initial-focus"
        ],
        [
          "modal-container"
        ],
        [
          "modal",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "leadgen-card-container"
        ],
        [
          "media"
        ],
        [
          "cards2-promotion-iframe"
        ],
        [
          "js-macaw-cards-iframe-container"
        ],
        [
          "AuthWebViewDialog",
          "modal-container"
        ],
        [
          "modal",
          "draggable"
        ],
        [
          "modal-content"
        ],
        [
          "modal-btn",
          "modal-close",
          "modal-close-fixed",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--large"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-header"
        ],
        [
          "modal-title"
        ],
        [
          "modal-body"
        ],
        [
          "auth-webview-view-container"
        ],
        [
          "media"
        ],
        [
          "auth-webview-card-iframe",
          "js-initial-focus"
        ],
        [
          "modal-container"
        ],
        [
          "modal"
        ],
        [
          "modal-btn",
          "js-promptDismiss",
          "modal-close",
          "js-close"
        ],
        [
          "Icon",
          "Icon--close",
          "Icon--medium"
        ],
        [
          "visuallyhidden"
        ],
        [
          "modal-content"
        ],
        [
          "modal-container",
          "UIWalkthrough"
        ],
        [
          "UIWalkthrough-clickBlocker"
        ],
        [
          "modal",
          "modal-small"
        ],
        [
          "UIWalkthrough-caret"
        ],
        [
          "modal-content"
        ],
        [
          "modal-body"
        ],
        [
          "UIWalkthrough-header"
        ],
        [
          "UIWalkthrough-stepProgress"
        ],
        [
          "UIWalkthrough-skip",
          "js-close"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--welcome"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--home",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--unfollow"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--smileRating1Fill",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--like"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--heart",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--retweet"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--retweet",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--reply"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--reply",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--trends"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--discover",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--wtf"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--follow",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--search"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--search",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "UIWalkthrough-step",
          "UIWalkthrough-step--moments"
        ],
        [
          "UIWalkthrough-title"
        ],
        [
          "Icon",
          "Icon--lightning",
          "UIWalkthrough-icon"
        ],
        [
          "UIWalkthrough-message"
        ],
        [
          "modal-footer"
        ],
        [
          "EdgeButton",
          "EdgeButton--tertiary",
          "u-floatLeft",
          "plain-btn",
          "UIWalkthrough-button",
          "js-previous-step"
        ],
        [
          "EdgeButton",
          "EdgeButton--secondary",
          "UIWalkthrough-button",
          "js-next-step",
          "js-initial-focus"
        ],
        [
          "modal-container"
        ],
        [
          "modal-container"
        ],
        [
          "modal-container"
        ],
        [
          "modal-container"
        ],
        [
          "PermalinkOverlay",
          "PermalinkOverlay-with-background",
          ""
        ],
        [
          "PermalinkProfile-dismiss",
          "modal-close-fixed"
        ],
        [
          "Icon",
          "Icon--close"
        ],
        [
          "PermalinkOverlay-next",
          "PermalinkOverlay-button",
          "u-posFixed",
          "js-next"
        ],
        [
          "Icon",
          "Icon--caretLeft",
          "Icon--large"
        ],
        [
          "u-hiddenVisually"
        ],
        [
          "PermalinkOverlay-modal"
        ],
        [
          "PermalinkOverlay-spinnerContainer",
          "u-hidden"
        ],
        [
          "PermalinkOverlay-spinner"
        ],
        [
          "PermalinkOverlay-content"
        ],
        [
          "PermalinkOverlay-body"
        ],
        [
          "hidden"
        ],
        [
          "tweet-post-iframe"
        ],
        [
          "dm-post-iframe"
        ],
        [
          "json-data"
        ],
        [
          "swift-boot-module"
        ],
        [
          "visuallyhidden"
        ]
      ]
    },
    "resources": [
      {
        "requestId": "1000028535.7",
        "name": "",
        "url": "https://twitter.com/i/js_inst?c_name=ui_metrics",
        "sameOrigin": true,
        "type": "script",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:07 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "status": "200\n200 OK",
          "x-twitter-response-tags": "BouncerExempt\nBouncerCompliant",
          "x-connection-hash": "f0cef776337fbfe2c9b2f21b9f27ab6d",
          "content-length": "1871",
          "x-xss-protection": "1; mode=block; report=https://twitter.com/i/xss_report",
          "x-response-time": "122",
          "pragma": "no-cache",
          "last-modified": "Wed, 04 Jul 2018 15:03:07 GMT",
          "server": "tsa_f",
          "x-frame-options": "",
          "strict-transport-security": "max-age=631138519",
          "content-type": "text/javascript; charset=utf-8",
          "cache-control": "no-cache, no-store, must-revalidate, pre-check=0, post-check=0",
          "set-cookie": "fm=0; Expires=Wed, 04 Jul 2018 15:02:58 GMT; Path=/; Domain=.twitter.com; Secure; HTTPOnly\n_twitter_sess=BAh7CSIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCOaD0WVkAToMY3NyZl9p%250AZCIlMzgzMmU0OGZmY2ZmMmFlZWI3NTEwYzA1OWY2ZjViOTc6B2lkIiVlYTgz%250ANWY1Y2YwMzhiYjdjMDc4MWI2NmI1ZWMxMWI4OA%253D%253D--904b1ee5d2753c28956b13d836433b8b013b96db; Path=/; Domain=.twitter.com; Secure; HTTPOnly",
          "x-transaction": "0043e3d8006e78d9",
          "expires": "Tue, 31 Mar 1981 05:00:00 GMT"
        },
        "security": {
          "name": "twitter.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 Extended Validation Server CA"
        }
      },
      {
        "requestId": "1000028535.4",
        "name": "twitter_core.bundle.css",
        "url": "https://abs.twimg.com/a/1530627074/css/t1/twitter_core.bundle.css",
        "sameOrigin": false,
        "type": "stylesheet",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:07 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "x-ton-expected-size": "186752",
          "x-cache": "HIT",
          "status": "200",
          "content-length": "35829",
          "x-response-time": "123",
          "surrogate-key": "twitter-assets",
          "last-modified": "Tue, 03 Jul 2018 14:33:02 GMT",
          "server": "ECS (arn/45E1)",
          "etag": "\"lKtj0egTpaQlH8rucskwHQ==\"",
          "vary": "Accept-Encoding",
          "content-type": "text/css",
          "access-control-allow-origin": "*",
          "x-connection-hash": "222126a0254c6d20002eb6e98c48fe0d",
          "accept-ranges": "bytes",
          "expires": "Thu, 04 Jul 2019 15:03:07 GMT"
        },
        "security": {
          "name": "*.twimg.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.5",
        "name": "twitter_more_1.bundle.css",
        "url": "https://abs.twimg.com/a/1530627074/css/t1/twitter_more_1.bundle.css",
        "sameOrigin": false,
        "type": "stylesheet",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:07 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "x-ton-expected-size": "225857",
          "x-cache": "HIT",
          "status": "200",
          "content-length": "43619",
          "x-response-time": "118",
          "surrogate-key": "twitter-assets",
          "last-modified": "Tue, 03 Jul 2018 14:33:02 GMT",
          "server": "ECS (arn/467C)",
          "etag": "\"2oXrRPrONBkdhvUdHayPCQ==\"",
          "vary": "Accept-Encoding",
          "content-type": "text/css",
          "access-control-allow-origin": "*",
          "x-connection-hash": "8ac52f5a879bd530e4fc7fac85953c5a",
          "accept-ranges": "bytes",
          "expires": "Thu, 04 Jul 2019 15:03:07 GMT"
        },
        "security": {
          "name": "*.twimg.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.6",
        "name": "twitter_more_2.bundle.css",
        "url": "https://abs.twimg.com/a/1530627074/css/t1/twitter_more_2.bundle.css",
        "sameOrigin": false,
        "type": "stylesheet",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:07 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "x-ton-expected-size": "231545",
          "x-cache": "HIT",
          "status": "200",
          "content-length": "39401",
          "x-response-time": "125",
          "surrogate-key": "twitter-assets",
          "last-modified": "Tue, 03 Jul 2018 14:33:02 GMT",
          "server": "ECS (arn/467C)",
          "etag": "\"+KuoOiKfIiMnjbBRDlVELQ==\"",
          "vary": "Accept-Encoding",
          "content-type": "text/css",
          "access-control-allow-origin": "*",
          "x-connection-hash": "a1142b6c468bcb428a8ab06aa867a8b2",
          "accept-ranges": "bytes",
          "expires": "Thu, 04 Jul 2019 15:03:07 GMT"
        },
        "security": {
          "name": "*.twimg.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.2",
        "name": "init.sv.02a09a2e9b2265e88255.js",
        "url": "https://abs.twimg.com/k/sv/init.sv.02a09a2e9b2265e88255.js",
        "sameOrigin": false,
        "type": "script",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:07 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "x-ton-expected-size": "517511",
          "x-cache": "HIT",
          "status": "200",
          "content-length": "167416",
          "x-response-time": "131",
          "surrogate-key": "twitter-assets",
          "last-modified": "Tue, 03 Jul 2018 14:33:20 GMT",
          "server": "ECS (arn/46CC)",
          "etag": "\"mOb487A1LSAxSxNQwfqsCg==\"",
          "vary": "Accept-Encoding",
          "content-type": "application/javascript; charset=utf-8",
          "access-control-allow-origin": "*",
          "x-connection-hash": "28aba91bd9fd1d82ffda321edf061567",
          "accept-ranges": "bytes",
          "expires": "Thu, 04 Jul 2019 15:03:07 GMT"
        },
        "security": {
          "name": "*.twimg.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.3",
        "name": "0.commons.sv.a1253fe48f768b150023.js",
        "url": "https://abs.twimg.com/k/sv/0.commons.sv.a1253fe48f768b150023.js",
        "sameOrigin": false,
        "type": "script",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:07 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "x-ton-expected-size": "984809",
          "x-cache": "HIT",
          "status": "200",
          "content-length": "256442",
          "x-response-time": "167",
          "surrogate-key": "twitter-assets",
          "last-modified": "Thu, 21 Jun 2018 18:28:54 GMT",
          "server": "ECS (arn/45C8)",
          "etag": "\"BDoxV2FX9CKjSQqvmySMaA==\"",
          "vary": "Accept-Encoding",
          "content-type": "application/javascript; charset=utf-8",
          "access-control-allow-origin": "*",
          "x-connection-hash": "2362b3155c1088eb75bb69f7cb48aa16",
          "accept-ranges": "bytes",
          "expires": "Thu, 04 Jul 2019 15:03:07 GMT"
        },
        "security": {
          "name": "*.twimg.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.18",
        "name": "",
        "url": "https://twitter.com/i/js_inst?c_name=ui_metrics",
        "sameOrigin": true,
        "type": "script",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:08 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "status": "200\n200 OK",
          "x-twitter-response-tags": "BouncerExempt\nBouncerCompliant",
          "x-connection-hash": "f0cef776337fbfe2c9b2f21b9f27ab6d",
          "content-length": "2475",
          "x-xss-protection": "1; mode=block; report=https://twitter.com/i/xss_report",
          "x-response-time": "124",
          "pragma": "no-cache",
          "last-modified": "Wed, 04 Jul 2018 15:03:08 GMT",
          "server": "tsa_f",
          "x-frame-options": "",
          "strict-transport-security": "max-age=631138519",
          "content-type": "text/javascript; charset=utf-8",
          "cache-control": "no-cache, no-store, must-revalidate, pre-check=0, post-check=0",
          "set-cookie": "fm=0; Expires=Wed, 04 Jul 2018 15:02:59 GMT; Path=/; Domain=.twitter.com; Secure; HTTPOnly\n_twitter_sess=BAh7CSIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCOaD0WVkAToMY3NyZl9p%250AZCIlMzgzMmU0OGZmY2ZmMmFlZWI3NTEwYzA1OWY2ZjViOTc6B2lkIiVlYTgz%250ANWY1Y2YwMzhiYjdjMDc4MWI2NmI1ZWMxMWI4OA%253D%253D--904b1ee5d2753c28956b13d836433b8b013b96db; Path=/; Domain=.twitter.com; Secure; HTTPOnly",
          "x-transaction": "00e711bc003ea7da",
          "expires": "Tue, 31 Mar 1981 05:00:00 GMT"
        },
        "security": {
          "name": "twitter.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 Extended Validation Server CA"
        }
      },
      {
        "requestId": "1000028535.21",
        "name": "7.pages_signup.sv.7330e1273291203bfb1e.js",
        "url": "https://abs.twimg.com/k/sv/7.pages_signup.sv.7330e1273291203bfb1e.js",
        "sameOrigin": false,
        "type": "script",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:08 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "x-ton-expected-size": "88780",
          "x-cache": "HIT",
          "status": "200",
          "content-length": "22086",
          "x-response-time": "127",
          "surrogate-key": "twitter-assets",
          "last-modified": "Fri, 01 Jun 2018 19:30:15 GMT",
          "server": "ECS (arn/46A2)",
          "etag": "\"hDdeNmPepDyy8Njb6CR5Qg==\"",
          "vary": "Accept-Encoding",
          "content-type": "application/javascript; charset=utf-8",
          "access-control-allow-origin": "*",
          "x-connection-hash": "88844ccf3637c15a47f100fea388f91c",
          "accept-ranges": "bytes",
          "expires": "Thu, 04 Jul 2019 15:03:08 GMT"
        },
        "security": {
          "name": "*.twimg.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.16",
        "name": "edge-icons-Regular.woff",
        "url": "https://abs.twimg.com/a/1530627074/font/edge-icons-Regular.woff",
        "sameOrigin": false,
        "type": "font",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:08 GMT",
          "x-content-type-options": "nosniff",
          "x-ton-expected-size": "25368",
          "x-cache": "HIT",
          "status": "200",
          "content-length": "25368",
          "x-response-time": "121",
          "surrogate-key": "twitter-assets",
          "last-modified": "Tue, 03 Jul 2018 14:33:03 GMT",
          "server": "ECS (arn/469E)",
          "etag": "\"CLcOqkPLesGTUv4s7dvoxg==\"",
          "content-type": "application/font-woff",
          "access-control-allow-origin": "*",
          "x-connection-hash": "aa4b32d0aea8acc2c9e78f72e02f9438",
          "accept-ranges": "bytes",
          "expires": "Thu, 04 Jul 2019 15:03:08 GMT"
        },
        "security": {
          "name": "*.twimg.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.23",
        "name": "analytics.js",
        "url": "https://www.google-analytics.com/analytics.js",
        "sameOrigin": false,
        "type": "script",
        "status": 200,
        "method": "GET",
        "headers": {
          "strict-transport-security": "max-age=10886400; includeSubDomains; preload",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "last-modified": "Fri, 18 May 2018 01:10:24 GMT",
          "server": "Golfe2",
          "age": "618",
          "date": "Wed, 04 Jul 2018 14:52:50 GMT",
          "vary": "Accept-Encoding",
          "content-type": "text/javascript",
          "status": "200",
          "cache-control": "public, max-age=7200",
          "timing-allow-origin": "*",
          "alt-svc": "quic=\":443\"; ma=2592000; v=\"43,42,41,39,35\"",
          "content-length": "14386",
          "expires": "Wed, 04 Jul 2018 16:52:50 GMT"
        },
        "security": {
          "name": "*.google-analytics.com",
          "protocol": "TLS 1.2",
          "issuer": "Google Internet Authority G3"
        }
      },
      {
        "requestId": "1000028535.25",
        "name": "",
        "url": "https://www.google-analytics.com/r/collect?v=1&_v=j68&aip=1&a=1639342444&t=pageview&_s=1&dl=https%3A%2F%2Ftwitter.com%2F&dr=&dp=%2Fanon%2Ffront%2Ffront&ul=en-us&de=UTF-8&dt=Twitter.%20Det%20%C3%A4r%20det%20som%20h%C3%A4nder.&sd=24-bit&sr=800x600&vp=1440x900&je=0&_u=YEBAAQAB~&jid=1463883176&gjid=397336507&cid=1342760267.1530716589&tid=UA-30775-6&_gid=2076532622.1530716589&_r=1&z=778564635",
        "sameOrigin": false,
        "type": "image",
        "status": 200,
        "method": "GET",
        "headers": {
          "pragma": "no-cache",
          "date": "Wed, 04 Jul 2018 15:03:09 GMT",
          "x-content-type-options": "nosniff",
          "last-modified": "Sun, 17 May 1998 03:00:00 GMT",
          "server": "Golfe2",
          "status": "200",
          "content-type": "image/gif",
          "access-control-allow-origin": "*",
          "cache-control": "no-cache, no-store, must-revalidate",
          "alt-svc": "quic=\":443\"; ma=2592000; v=\"43,42,41,39,35\"",
          "content-length": "35",
          "expires": "Fri, 01 Jan 1990 00:00:00 GMT"
        },
        "security": {
          "name": "*.google-analytics.com",
          "protocol": "TLS 1.2",
          "issuer": "Google Internet Authority G3"
        }
      },
      {
        "requestId": "1000028535.24",
        "name": "",
        "url": "https://syndication.twitter.com/i/jot/syndication?l=%7B%22_category_%22%3A%22syndicated_impression%22%2C%22event_namespace%22%3A%7B%22client%22%3A%22web%22%2C%22page%22%3A%22front%22%2C%22action%22%3A%22impression%22%7D%2C%22triggered_on%22%3A1530716588549%7D",
        "sameOrigin": false,
        "type": "image",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:09 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "status": "200\n200 OK",
          "x-twitter-response-tags": "BouncerCompliant",
          "content-length": "65",
          "x-xss-protection": "1; mode=block; report=https://twitter.com/i/xss_report",
          "x-response-time": "8",
          "pragma": "no-cache",
          "last-modified": "Wed, 04 Jul 2018 15:03:09 GMT",
          "server": "tsa_b",
          "x-frame-options": "SAMEORIGIN",
          "strict-transport-security": "max-age=631138519",
          "content-type": "image/gif;charset=utf-8",
          "cache-control": "no-cache, no-store, must-revalidate, pre-check=0, post-check=0",
          "x-connection-hash": "abc9aad805f939df542f175f3d427ec0",
          "x-transaction": "0035a0fe004396eb",
          "expires": "Tue, 31 Mar 1981 05:00:00 GMT"
        },
        "security": {
          "name": "syndication.twitter.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      },
      {
        "requestId": "1000028535.22",
        "name": "",
        "url": "https://analytics.twitter.com/tpm/p?_=1530716588148",
        "sameOrigin": false,
        "type": "xhr",
        "status": 200,
        "method": "GET",
        "headers": {
          "date": "Wed, 04 Jul 2018 15:03:09 GMT",
          "content-encoding": "gzip",
          "x-content-type-options": "nosniff",
          "status": "200",
          "content-disposition": "attachment; filename=json.json",
          "vary": "Origin",
          "content-length": "28",
          "x-xss-protection": "1; mode=block",
          "x-response-time": "25",
          "server": "tsa_b",
          "x-frame-options": "SAMEORIGIN",
          "strict-transport-security": "max-age=631138519",
          "content-type": "application/json;charset=utf-8",
          "access-control-allow-origin": "https://twitter.com",
          "access-control-expose-headers": "",
          "access-control-allow-credentials": "true",
          "x-connection-hash": "c27c8dcf62286c3f42743e2b8985806e",
          "x-transaction": "00158b4a0025a035"
        },
        "security": {
          "name": "*.twitter.com",
          "protocol": "TLS 1.2",
          "issuer": "DigiCert SHA2 High Assurance Server CA"
        }
      }
    ],
    "workers": [],
    "DOM": {}
  }
}
