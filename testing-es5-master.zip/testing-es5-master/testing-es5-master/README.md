# testing-es5
A sample repo of ES5 transpilation with Babel


https://www.codebyamir.com/blog/convert-javascript-es6-to-es5-using-babel
https://github.com/SwiftWinds/testing-es5


npm run build