package com.ibm.wala.examples.drivers;

import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices.ObjectVertex;
import com.ibm.wala.cast.js.ipa.callgraph.JSCallGraph;
import com.ibm.wala.cast.js.ipa.callgraph.JSCallGraphUtil;
import com.ibm.wala.cast.js.translator.CAstRhinoTranslatorFactory;
import com.ibm.wala.cast.js.util.CallGraph2JSON;
import com.ibm.wala.cast.js.util.FieldBasedCGUtil;
import com.ibm.wala.examples.analysis.js.JSCallGraphBuilderUtil;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.CallGraphStats;
import com.ibm.wala.ipa.callgraph.propagation.PointerAnalysis;
import com.ibm.wala.util.CancelException;
import com.ibm.wala.util.WalaException;
import com.ibm.wala.util.collections.Pair;

import com.ibm.wala.types.TypeName;
import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.cast.js.ipa.callgraph.JSCallGraphUtil;
import com.ibm.wala.cast.js.translator.CAstRhinoTranslatorFactory;
import com.ibm.wala.classLoader.CallSiteReference;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.examples.analysis.js.JSCallGraphBuilderUtil;
import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.propagation.InstanceKey;
import com.ibm.wala.ipa.callgraph.propagation.PointerAnalysis;
import com.ibm.wala.ipa.callgraph.propagation.PointerKey;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.ISSABasicBlock;
import com.ibm.wala.ssa.SSACFG;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.types.TypeName;
import com.ibm.wala.util.CancelException;
import com.ibm.wala.util.WalaException;
import com.ibm.wala.util.collections.Iterator2Iterable;
import com.ibm.wala.util.graph.dominators.Dominators;
import com.ibm.wala.util.graph.dominators.GenericDominators;
import com.ibm.wala.util.graph.traverse.DFS;
import com.ibm.wala.util.graph.traverse.DFSDiscoverTimeIterator;
import com.ibm.wala.cast.ir.ssa.AstIRFactory;
import com.ibm.wala.cast.ir.translator.TranslatorToCAst.Error;
import com.ibm.wala.cast.js.html.DefaultSourceExtractor;
import com.ibm.wala.cast.js.html.JSSourceExtractor;
import com.ibm.wala.cast.js.html.WebPageLoaderFactory;
import com.ibm.wala.cast.js.html.WebUtil;
import com.ibm.wala.cast.js.ipa.callgraph.*;
import com.ibm.wala.cast.js.ipa.callgraph.correlations.extraction.CorrelatedPairExtractorFactory;
import com.ibm.wala.cast.js.loader.JavaScriptLoader;
import com.ibm.wala.cast.js.loader.JavaScriptLoaderFactory;
import com.ibm.wala.cast.loader.CAstAbstractLoader;
import com.ibm.wala.cast.tree.rewrite.CAstRewriterFactory;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.classLoader.Module;
import com.ibm.wala.classLoader.SourceModule;
import com.ibm.wala.classLoader.SourceURLModule;
import com.ibm.wala.ipa.callgraph.AnalysisScope;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.Entrypoint;
import com.ibm.wala.ipa.callgraph.IAnalysisCacheView;
import com.ibm.wala.ipa.callgraph.propagation.InstanceKey;
import com.ibm.wala.ipa.callgraph.propagation.PointerAnalysis;
import com.ibm.wala.ipa.callgraph.propagation.PropagationCallGraphBuilder;
import com.ibm.wala.ipa.callgraph.propagation.SSAPropagationCallGraphBuilder;
import com.ibm.wala.ipa.callgraph.propagation.cfa.ZeroXInstanceKeys;
import com.ibm.wala.ipa.cha.ClassHierarchyException;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.ssa.IRFactory;
import com.ibm.wala.util.CancelException;
import com.ibm.wala.util.WalaException;
import com.ibm.wala.util.collections.HashSetFactory;
import com.ibm.wala.util.io.FileProvider;

import com.ibm.wala.cast.js.callgraph.fieldbased.FieldBasedCallGraphBuilder;
import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.FlowGraph;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

import com.ibm.wala.classLoader.IClass;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.ipa.callgraph.Entrypoint;
import com.ibm.wala.ipa.callgraph.impl.DefaultEntrypoint;
import com.ibm.wala.cast.js.callgraph.fieldbased.FieldBasedCallGraphBuilder;
import com.ibm.wala.cast.js.callgraph.fieldbased.OptimisticCallgraphBuilder;
import com.ibm.wala.cast.js.callgraph.fieldbased.PessimisticCallGraphBuilder;
import com.ibm.wala.cast.js.callgraph.fieldbased.WorklistBasedOptimisticCallgraphBuilder;

import com.ibm.wala.ipa.callgraph.AnalysisOptions;
import com.ibm.wala.cast.ir.ssa.AstIRFactory;
import com.ibm.wala.cast.types.AstMethodReference;
import com.ibm.wala.ssa.SSAOptions;

import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.FlowGraphBuilder;
import com.ibm.wala.types.TypeReference;
import com.ibm.wala.cast.js.types.JavaScriptTypes;

import com.ibm.wala.cast.ir.ssa.AstGlobalRead;
import com.ibm.wala.cast.ir.ssa.AstGlobalWrite;
import com.ibm.wala.cast.ir.ssa.AstLexicalAccess.Access;
import com.ibm.wala.cast.ir.ssa.AstLexicalRead;
import com.ibm.wala.cast.ir.ssa.AstLexicalWrite;
import com.ibm.wala.cast.ir.ssa.AstPropertyRead;
import com.ibm.wala.cast.ir.ssa.AstPropertyWrite;
import com.ibm.wala.cast.js.callgraph.fieldbased.JSMethodInstructionVisitor;
import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices.CreationSiteVertex;
import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices.FuncVertex;
import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices.VarVertex;
import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices.Vertex;
import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices.VertexFactory;
import com.ibm.wala.cast.js.ipa.callgraph.JSCallGraphUtil;
import com.ibm.wala.cast.js.ipa.callgraph.JSSSAPropagationCallGraphBuilder;
import com.ibm.wala.cast.js.ssa.JavaScriptInvoke;
import com.ibm.wala.cast.js.ssa.PrototypeLookup;
import com.ibm.wala.cast.js.ssa.SetPrototype;
import com.ibm.wala.cast.js.types.JavaScriptMethods;
import com.ibm.wala.cast.js.types.JavaScriptTypes;
import com.ibm.wala.cast.js.util.Util;
import com.ibm.wala.cast.loader.AstMethod;
import com.ibm.wala.cast.loader.AstMethod.LexicalInformation;
import com.ibm.wala.cast.types.AstMethodReference;
import com.ibm.wala.classLoader.IClass;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.ipa.callgraph.IAnalysisCacheView;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.SSAGetCaughtExceptionInstruction;
import com.ibm.wala.ssa.SSAGetInstruction;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.ssa.SSANewInstruction;
import com.ibm.wala.ssa.SSAPhiInstruction;
import com.ibm.wala.ssa.SSAPutInstruction;
import com.ibm.wala.ssa.SSAReturnInstruction;
import com.ibm.wala.ssa.SSAThrowInstruction;
import com.ibm.wala.types.TypeReference;
import com.ibm.wala.util.collections.Iterator2Iterable;
import com.ibm.wala.util.intset.EmptyIntSet;
import com.ibm.wala.util.intset.IntSet;
import com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices.VertexFactory;
import com.ibm.wala.ipa.callgraph.AnalysisCache;
import com.ibm.wala.ipa.callgraph.AnalysisCacheImpl;
import com.ibm.wala.ipa.slicer.SlicerUtil;
import com.ibm.wala.cast.js.ipa.callgraph.JSCallGraphUtil;
import com.ibm.wala.cast.js.translator.CAstRhinoTranslatorFactory;
import com.ibm.wala.classLoader.CallSiteReference;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.examples.analysis.js.JSCallGraphBuilderUtil;
import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.propagation.InstanceKey;
import com.ibm.wala.ipa.callgraph.propagation.PointerAnalysis;
import com.ibm.wala.ipa.callgraph.propagation.PointerKey;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.ISSABasicBlock;
import com.ibm.wala.ssa.SSACFG;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.types.TypeName;
import com.ibm.wala.util.CancelException;
import com.ibm.wala.util.WalaException;
import com.ibm.wala.util.collections.Iterator2Iterable;
import com.ibm.wala.util.graph.dominators.Dominators;
import com.ibm.wala.util.graph.dominators.GenericDominators;
import com.ibm.wala.util.graph.traverse.DFS;
import com.ibm.wala.util.graph.traverse.DFSDiscoverTimeIterator;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.Set;
import java.util.Map;
import java.nio.file.Files;


import com.ibm.wala.examples.analysis.dataflow.ContextSensitiveReachingDefs;  //@tocheck
import com.ibm.wala.ipa.slicer.Slicer;
import com.ibm.wala.ipa.slicer.SlicerUtil;
import com.ibm.wala.ipa.slicer.Statement;
import com.ibm.wala.ipa.slicer.Slicer.DataDependenceOptions;
import com.ibm.wala.ipa.slicer.Slicer.ControlDependenceOptions;
import com.ibm.wala.ipa.slicer.NormalStatement;
import com.ibm.wala.ipa.slicer.SDG;
import com.ibm.wala.cast.js.ipa.modref.JavaScriptModRef;
import com.ibm.wala.ipa.callgraph.propagation.InstanceKey;

import com.ibm.wala.ssa.SymbolTable;

import com.ibm.wala.util.collections.HashMapFactory;
import com.ibm.wala.util.collections.HashSetFactory;


// gradlew compileJava
// gradlew run --args="C:/UNI-MS/projects-java/WALA-start-master/instagram/op4/files/1.js"
// gradlew run --args="C:/UNI-MS/projects-java/WALA-start-master/test.js"
// gradlew run --args="C:/UNI-MS/projects-java/WALA-start-master/test_instagram.js"

// gradlew run --args="C:/UNI-MS/projects-java/WALA-start-master/instagram_3.js"
// https://wala.github.io/javadoc/com/ibm/wala/cast/js/callgraph/fieldbased/FieldBasedCallGraphBuilder.html
// https://wala.github.io/javadoc/com/ibm/wala/cast/js/util/FieldBasedCGUtil.BuilderType.html#fieldBasedCallGraphBuilderFactory-com.ibm.wala.ipa.cha.IClassHierarchy-com.ibm.wala.cast.js.ipa.callgraph.JSAnalysisOptions-com.ibm.wala.ipa.callgraph.IAnalysisCacheView-boolean-
// https://wala.github.io/javadoc/com/ibm/wala/cast/js/ipa/callgraph/JSAnalysisOptions.html#handleCallApply--
public class FieldBasedJSCallGraphDriver {

  /**
   * Usage: JSCallGraphDriver path_to_js_file
   *
   * @param args
   * @throws WalaException
   * @throws CancelException
   * @throws IOException
   * @throws IllegalArgumentException
   */
  public static void main(String[] args) throws IllegalArgumentException, IOException, CancelException, WalaException {
    //Path path = Paths.get(args[0]);
    
    for (int ipath = 1; ipath <= 1; ipath++) {
      //String fileName = "C:/UNI-MS/projects-java/WALA-start-master/complex2/github/op5/files/" + ipath +".js";
      String fileName = "C:/UNI-MS/projects-java/WALA-start-master/test.js";

      Path path = Paths.get(fileName);

      //System.out.println(path.toUri().toURL());
      
      if (Files.exists(path)) {
        try {
          FieldBasedCGUtil f = new FieldBasedCGUtil(new CAstRhinoTranslatorFactory());
          URL url = path.toUri().toURL();
  
          Pair<JSCallGraph, PointerAnalysis<ObjectVertex>> results =
              f.buildScriptCG(url, FieldBasedCGUtil.BuilderType.OPTIMISTIC, null, true);
          CallGraph CG = results.fst;
          PointerAnalysis<ObjectVertex> ptrAnalysis = results.snd;
  
          //IntraprocReachingDefs ip = new IntraprocReachingDefs(cg, null);
          int count = 0;
          String val = "";
          Map<String, Set<String>> nodeNames = HashMapFactory.make();
          Map<String, String> valuesAjax = HashMapFactory.make();
  
          ArrayList listA = new ArrayList();
          getNames(CG, nodeNames, ptrAnalysis, listA);

          //System.out.println(nodeNames);
            
          for (Map.Entry<String, Set<String>> entry : nodeNames.entrySet()) {
            Map<String, String> valuesPair = HashMapFactory.make();  //@todo
            String k = entry.getKey();
            ArrayList valuesInCall = fetchToMapCall(listA, k);
            
            Set<String> v = entry.getValue();
            Iterator<String> setIterator = v.iterator();
            while(setIterator.hasNext()){
              String className = setIterator.next();
            
              //addValuesPair(CG, className, valuesPair);
            }
            //addValuesPair(CG, k, valuesPair);    
            
            // for (Object callInfoObj : valuesInCall) {
            //   Map<String, String> callInfo = (Map<String, String>)callInfoObj;
            //   String urlCalled = callInfo.get("url");
            //   String refToMatch = callInfo.get("fromRef");
            //   String urlToMatch = "";
  
            //   if (urlCalled != null && urlCalled.length()>0) {
            //     urlToMatch = urlCalled;
            //   } else {
            //     urlToMatch = refToMatch + "." + "url";
            //   }
           
            //   String typeToMatch = refToMatch + "." + "type";
            //   for (Map.Entry<String, String> eachPair : valuesPair.entrySet()) {
            //     String key = eachPair.getKey();
            //     String value = eachPair.getValue();
            //     // System.out.println("val:" + value);
            //     // System.out.println("key:" + key);
            //     //https://www.googleapis.com/calendar/v3/calendars/{calendarId}/events/{eventId}/get
            //     //https://api.instagram.com/v1/users/{user-id}/get
            //     if (value.contains("api.instagram.com")) {              
            //       // System.out.println("val:" + value);
            //       // System.out.println("key:" + key);
            //       // System.out.println("matched url:" + ipath + ".js");
            //     }
            //   }   
            // } 
          } 
        } catch (Exception e) {
          System.out.println(e.getMessage());
        }
      }
    } 
  }

  private static void getNames(CallGraph CG, Map<String, Set<String>> valNames,  PointerAnalysis<ObjectVertex> ptrAnalysis, ArrayList listA) {
    Map<String, String> valuesPair = HashMapFactory.make();  //@todo
    int count = 0;

    // ArrayList listA = new ArrayList();
    //list.add(new HashMap());
    

    for (CGNode node : CG) {
      TypeName tempType = node.getMethod().getDeclaringClass().getName();
      String name = tempType.toString();
      if (!name.contains("prologue.js") && !name.contains("LFunction")) {
      //if (!name.contains("prologue.js")) {
        try {
            count = count + 1;
            // Get the IR of a CGNode
            IR ir = node.getIR();

            Map<String, ArrayList> line = ir.getStartEndlinesAjax(name);   
            //System.out.println(line);
            if (line != null) {
              listA.add(line);
            }
            // addValuesPair(CG, tempType.toString(), valuesPair);

            // for (Map.Entry<String, String> eachPair : valuesPair.entrySet()) {
            //   String key = eachPair.getKey();
            //   String value = eachPair.getValue();
            // }
            // System.out.println("line =========== line ========== line");

            // System.out.println(line);
            
            // if (count > 5)
            //   break;
       
            if (line != null) {        
              //System.out.println(line);               
              String valueFound = tempType.toString();
              String[] splitValue = valueFound.split("/");
              String val = splitValue[splitValue.length-1];
              ArrayList<String> targets = new ArrayList<String>();

              final Collection<Statement> ss = findTargetStatement(CG);

              for (Statement s: ss) {
                if (s.toString().contains(val)) {                  
                  Collection<Statement> slice = Slicer.computeBackwardSlice(s, CG, ptrAnalysis, DataDependenceOptions.NONE, ControlDependenceOptions.FULL);
                  
                  for (Statement sc : slice) {
                    String nameClass = sc.getNode().getMethod().getDeclaringClass().getName().toString();
                    if(!targets.contains(nameClass) && !nameClass.contains("LFunction")) {
                      //  System.out.println("nameClass");
                      //  System.out.println(nameClass);

                        targets.add(nameClass);       //@todo: node is also in ss               
                    }
                  }
                }       
              }
              addDep(valueFound, valNames, targets); 
              
              //System.out.println(targets);
            } 
        } catch (Exception e) {
            System.out.println(e);
        }
      }
    }
  }

  private static Collection<Statement> findTargetStatement(CallGraph CG) {
    final Collection<Statement> ss = HashSetFactory.make();
    for (CGNode n : CG) {
      for (CGNode caller : Iterator2Iterable.make(CG.getPredNodes(n))) {
        for (CallSiteReference site : Iterator2Iterable.make(CG.getPossibleSites(caller, n))) {
          caller
              .getIR()
              .getCallInstructionIndices(site)
              .foreach(x -> ss.add(new NormalStatement(caller, x)));
        }
      }
    }
    return ss;
  }

  private static void addDep(String val, Map<String, Set<String>> valNames, ArrayList<String> targets) {
    // if (targets.size() > 0) {
      if (!valNames.containsKey(val)) {
        valNames.put(val, HashSetFactory.<String>make());
      }
      for (String s : targets) {
        valNames.get(val).add(s);
      }
    // }
  }

  private static void addValuesPair(CallGraph CG, String className , Map<String, String> valuesPair) {
    for (CGNode node : CG) {
      TypeName tempType = node.getMethod().getDeclaringClass().getName();
    
			if (!tempType.toString().contains("prologue.js") && tempType.toString().equals(className)) {
 
        try {
            // Get the IR of a 
            IR ir = node.getIR(); 
            //System.out.println(ir.toString());
            ir.fetchValuesPair(valuesPair);
            System.out.println("valuesPair");           

            System.out.println(valuesPair);   
            


        } catch (Exception e) {
            System.out.println(e);
        }
      }
    }
  }

  private static ArrayList fetchToMapCall(ArrayList listA, String name) {
    Map<String, ArrayList> value = HashMapFactory.make();
    
    for (int i = 0; i < listA.size(); i++) {
      Object values = listA.get(i);
      value = (Map<String, ArrayList>) values;

      for (Map.Entry<String, ArrayList> entry : value.entrySet()) {
         String classAsKey = entry.getKey();
         ArrayList info = entry.getValue();

         if (classAsKey.equals(name)) {
           return info;
         }

        //  for (int it = 0; i < info.size(); it++) {
        //   Map<String, String> valuesCall = info.get(it);

        //   for (Map.Entry<String, String> entryValuesCall : valuesCall.entrySet()) {

        //   }
        //  }
      }
    }
    return null;
  }
}