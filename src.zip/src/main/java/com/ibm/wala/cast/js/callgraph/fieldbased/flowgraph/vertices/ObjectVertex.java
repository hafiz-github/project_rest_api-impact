package com.ibm.wala.cast.js.callgraph.fieldbased.flowgraph.vertices;

import com.ibm.wala.ipa.callgraph.propagation.InstanceKey;

public interface ObjectVertex extends InstanceKey {}
