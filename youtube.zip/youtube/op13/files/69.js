import YOUTUBE_API_KEY from '../config/youtube.js';

var handleVideoSearch = (q = null) => {
  //TODO:  Write an asynchronous action to handle a video search!

  // write request to youtube
  // make options with input q
  // success callback: return { type: "VIDEO_SEARCH" , payload: { videos : datafromserver } }
  // failing callback: //no return, no action sent, no reducers triggered?
  //
  return (dispatch) => {
    $.ajax({
      type: 'GET',
      url: 'https://www.googleapis.com/youtube/v3/search',
      data: {
        key: YOUTUBE_API_KEY,
        q,
        maxResults: 3,
        type: 'video',
        videoEmbeddable: true,
        part: 'snippet'
      },
      success: function(data) {
        console.log(data.items);
        dispatch({type: 'CHANGE_VIDEO_LIST', videos: data.items});
      },
      error: function(error) {
        console.log(error);
      }
    });
  };
};

export default handleVideoSearch;
