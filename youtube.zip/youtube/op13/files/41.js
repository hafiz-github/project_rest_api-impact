
var wraper = $(".videos"); 

var inicial=10;

$("#buscador").click(function(e){
  e.preventDefault(); 

  var busqueda = $("#search").val(); 

  $.ajax({
    type: "get",
    url: "https://www.googleapis.com/youtube/v3/search",
    data: {
      part: "id, snippet",
      q: busqueda,
      maxResults:inicial,
      key: "AIzaSyBEfU2wxixjx25FDpYb5dsorO7ARsTHYJ0"
    },
    dataType: "json",
    success: function(data){
      wraper.html("");
      data.items.forEach(video => {
        var idVideo = video.id.videoId;
        var titulo = video.snippet.title;
        var thumb = video.snippet.thumbnails.high.url; 

        var box= `
          <div class="videos" data-id="${idVideo}">
            <h4>${titulo}</h4>
            <div class="all">
              <img src="${thumb}" alt=" new img ">
            </div>
          </div>
        `;
        $("#videoSource").append(box); 
        
      });
    }

  });


});


$("#videoSource").on("click", ".videos", function(){
  console.log("holaa");
  window.open("https://www.youtube.com/watch?v="+$(this).data("id"));
})

$("#more").on("click", function(){
  console.log("un lolcito o que? ");

  inicial += 10;
  console.log(inicial);
  

  var busqueda = $("#search").val(); 

  $.ajax({
    type: "get",
    url: "https://www.googleapis.com/youtube/v3/search",
    data: {
      part: "id, snippet",
      q: busqueda,
      maxResults:inicial,
      key: "AIzaSyBEfU2wxixjx25FDpYb5dsorO7ARsTHYJ0"
    },
    dataType: "json",
    success: function(data){
      wraper.html("");
      data.items.forEach(video => {
        var idVideo = video.id.videoId;
        var titulo = video.snippet.title;
        var thumb = video.snippet.thumbnails.high.url; 

        var box= `
          <div class="videos" data-id="${idVideo}">
            <h4>${titulo}</h4>
            <div class="all">
              <img src="${thumb}" alt=" new img ">
            </div>
          </div>
        `;
        $("#videoSource").append(box); 
        
      });
    }

  });


}); 