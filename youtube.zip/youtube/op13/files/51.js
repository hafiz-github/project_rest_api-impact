﻿var socket = io.connect(window.location.href);
(function(){ //IIFE
		// Variables
		var liste = document.getElementById("chat");
		var votesC;
		var nbC;
		var savedSearch;

		if(document.cookie.indexOf("ido=") === -1){
			//Génère un ID perso (nombre random) si l'utilisateur n'en a pas et le stock dans les cookies
			//Ceci empêche de se connecter plusieurs fois
			xoo = Math.random() +Math.random()*5 + Math.random()*Math.random();
			document.cookie = "ido=" + xoo;
		}
		const sessId = document.cookie.toString();


		instaVid = function(){  //Change la vidéo tout seul si liste vide
			socket.emit('newDuration', pDuration);
		};

		socket.on("goodPass", function(){
			$("#passWord").hide(1000);
		});

		socket.on("passWord", function(pass){
			$("#passWord").show();
			$("#passMess").text(pass);
		});

		$("#sendPass").keypress(function(e){
			if(e.which == 13){
				socket.emit("mdp", $("#sendPass").val());
			}
		});

		$(document).keyup(function(e){
			if(e.keyCode === 27){
				$("#popUp").hide(1000);
				savedSearch = undefined;
				$(".searchR").css("background-color", "white");
			}
		});

		$("#btnPass").click(function(){
				socket.emit("mdp", $("#sendPass").val());
		});

		socket.on("askId", function(){  //Envoyer son ID perso
			socket.emit("sendId", sessId);
		});


		//Recevoir la musique entrain de jouer:
		socket.on('nowPlaying', function(nowPlaying){
			now = nowPlaying;
			});

		//Envoie toutes les raisons pour lesquelles un envoi pourrait être refusé
		socket.on("refused", function(refused){
			alert(refused);
		});

		socket.on("scores", function(scores){
			for(x in scores){
				document.getElementById("dab"+x).innerHTML = scores[x];
			}
		});

		//Réception de la liste de lecture dès la connection et dès qu'elle est modifiée

		socket.on('accepted', function(list){
			var listLen = list.length;
				$("#liste").text("");
				for(var x=0; x< listLen; x++){
					$("#liste").append("<a target='_blank' href='https://www.youtube.com/watch?v=" +list[x]+  "'><p class='vidlist'><img src='http://img.youtube.com/vi/" + list[x] +"/1.jpg'>" + "<span class='aspans' id='a" + x+ "'></span></a>" +"<span class='thumbs'><span onclick='thumbUp(" + x + ")' class='tUp'> &#9650; </span><span id='dab"+ x +"' class='dab'></span><span onclick='thumbDown(" +x + ")' class='tDown'> &#9660; </span></span></p>");
					getname(listLen, list[x], x);
			}
			//Fonctions pour voter pour les vidéos

		});

		thumbUp = function(x){
				socket.emit("scorePlus", {val: x, sess: sessId});
			}

		thumbDown = function(x){
				socket.emit("scoreMoins", {val: x, sess: sessId});
			}

			//Fonction closure qui permet d'utiliser les valeurs de la boucle même avec AJAX
			var getname = function(listLen, list, x){
					$.ajax({
						url: "https://www.googleapis.com/youtube/v3/videos?id=" + list + "&key="+ dataKey + "&fields=items(snippet(title))&part=snippet",
						dataType: "jsonp",
						success: function(data){
							var lid = "a"+x;
							var elem = document.getElementById(lid);
							elem.innerHTML = data.items[0].snippet.title;
					},
				});
			}

		//Envoyer l'information qu'on a voté, ainsi que l'ID pour emêcher un double vote
		$("#voteCount").click(function(){
			socket.emit("chgVote", sessId);
		});


		socket.on('votesVal', function(votesVal){
			votesC = votesVal;
			chgVoteCount();
		});

		socket.on('nbCo', function(nbCo){
			nbC = nbCo;
			chgConnectedCount();
		});

		var chgConnectedCount = function(){
			if(nbC > 1){
				$("#connectedCount").text(nbC + " spectators");
			}
			else{
				$("#connectedCount").text("1 spectator");
			}
		};

		var chgVoteCount = function(){
				$("#voteCount").text(votesC);
		};


			//Change la vidéo en train d'être lue à la réception de chgVid
			socket.on('chgVid', function(newId){
				nowPlay = newId;
				loadVid(nowPlay);
			});


		// Permet d'envoyer un url au serveur (On récupère l'id de la vidéo)
		$("#propose").keypress(function(e){
			if(e.which == 13){
				var newUrl = $("#propose").val();
					socket.emit('propose', newUrl);
					$("#propose").val("");
				}
		});

		//Gère le PopUp qui affiche la recherche YouTube
		$("#showPop").click(function(){
			$("#popUp").show(1000);
	});

	$("#popUp").click(function(){
		$("#popUp").hide(1000);
		$(".searchR").css("background-color", "white");
		savedSearch = undefined;
	}).children().click(function(e) {
		return false;
	});


	//Gèrer la searchbox
	//On récupère d'abord les informations, avant de les afficher avec la fonction res(body)
	var searchAjax = function(){
		$.ajax({
				url: "https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q="+ $("#searchBox").val() +"&safeSearch=moderate&type=video&key=AIzaSyBc1Gq8x8p-U31RRjXzhEwb4vvJIHexLsA",
						dataType: "jsonp",
						success: function(body){
								res(body);
							}
					});
	}

	$("#searchBox").keypress(function(e){
			if(e.which == 13){
				searchAjax();
			}
	});

	//Permet de lancer une requête AJAX à Google pour obtenir le résultat d'une recherche youtube

	function res(body){
		$("#searchResult").text("");
		for(x in body.items){
			$("#searchResult").append("<a href='#'><p class='searchR' id='" + body.items[x].id.videoId + "'><img src='http://img.youtube.com/vi/" + body.items[x].id.videoId +"/1.jpg'>" + "<span class='bspans'>"+ body.items[x].snippet.title +"</span></p></a>");
		}
		$(".searchR").click(function(){
			$(".searchR").css("background-color", "white");
			$(this).css("background-color", "#e0e0eb");
			savedSearch = this.id;
	});
	}


	$("#buttonVal").click(function(){
		if(savedSearch === undefined){
			searchAjax();
		}
		else{
			socket.emit("propose", savedSearch);
			$("#popUp").hide(1000);
			savedSearch = undefined;
			$(".searchR").css("background-color", "white");
		}
	});

}());
